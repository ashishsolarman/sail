<?php

namespace App\Http\Controllers\Collection;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;
use App\Mail\MailNotify;


class CollectionController extends Controller  
{
   public function collection(){
    return view('collection.collection_master');
   }

 public function collection_search(){
    return view('collection.collection_search');
   }

 public function search_mobile(Request $request)
    {

      $data = \DB::table('owner_details');
        // if( $request->name){
        //     $data = $data->where('owner_tenant', 'LIKE', "%".$request->name."%");
        // }
        if( $request->mobile){
            $data = $data->where('mobile', 'LIKE', "%" . $request->mobile . "%");
        }

        // $data = DB::table('owner_details')
        //     ->join('collection_master', 'owner_details.id', '=', 'collection_master.resident_id')
        //     ->select('owner_details.*', 'collection_master.*')
        //     ->get();
        
        $data = $data->paginate(10);
        return view('collection.collection_master', compact('data'));
    }

    public function store_payment(Request $request){
        $request->validate([
          'from_date' => 'required',
          'to_date' => 'required',
          'payment_mode' => 'required',
          'amount' => 'required',
        ]);

        $payment = new Collection;
        $payment->from_date = $request->from_date;
        $payment->to_date = $request->to_date;
        $payment->payment_mode = $request->payment_mode;
        $payment->amount = $request->amount;
        $payment->resident_id = $request->resident_id;
        $payment->save();

        return redirect('collection_list')->withSuccess('Payment Successfully');
    }


   public function collection_list(){
   $users = DB::table('owner_details')
              ->join('collection_master', 'owner_details.id', '=', 'collection_master.resident_id')
              ->orderBy('collection_master.created_at', 'desc')
            ->select('owner_details.*', 'collection_master.*')
            ->get();
    return view('collection.collection_list',compact('users'));
   }
   public function payment_slip(){
      return view('collection.payment_slip');
   }

    public function collection_history($resident_id){
            $resident_id = Crypt::decrypt($resident_id);
         $users = Collection::where('resident_id', $resident_id)->latest()->get();


       
      return view('collection.collection_history',compact('users'));
   }


    public function basic_email() {
      $data = array('name'=>"Amit kumar");
   
      Mail::send(['text'=>'mail'], $data, function($message) {
         $message->to('kumaramit27043@gmail.com', 'Payment alert mail')->subject
            (' Testing Mail');
         $message->from('abc@gmail.com','Amitkumar');
      });
       echo "Basic Email Sent. Check your inbox.";
      // return redirect('collection.collection_history')->withSuccess('Your mail has been successfully sent');
   }
}
