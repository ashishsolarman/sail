<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tenant;
use Illuminate\Support\Facades\Crypt;

class TenantController extends Controller
{
    public function tenant(){
        return view('tenant.add_tenant');
    }

      public function store_tenant(Request $request){

        $request->validate([
         'owner_name'=>'required|max:255',
         'tenant_name'=>'required|max:255',
         'mobile'=>'required|max:10|min:10',
         'aadhar_no'=>'required|max:12|min:12',
         'block'=>'required|max:255',
         'floor'=>'required|max:255',
         'house_no'=>'required|max:255',
         'email'=>'required|email|max:255',
          'status'=>'required|max:255',
          'profession'=>'required|max:255',
          'owner_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048|nullable',
          'aadhar_image' => 'required|max:10000|mimes:doc,docx,pdf,jpeg,png,jpg,gif,svg',
          'vehicle_type'=>'required|max:255',
          'vehicle_name'=>'required|max:255',
          'vehicle_number'=>'required|max:255',
        ]);

       $owner = new Tenant;
       $owner->owner_name = $request->owner_name;
        $owner->tenant_name = $request->tenant_name;
       $owner->mobile = $request->mobile;
       $owner->block = $request->block;
       $owner->floor = $request->floor;
       $owner->house_no = $request->house_no;
       $owner->email = $request->email;
       $owner->status = $request->status;
       $owner->profession = $request->profession;
       $owner->aadhar_no = $request->aadhar_no;
       $owner->vehicle_type = json_encode($request->vehicle_type);
       $owner->vehicle_name = json_encode($request->vehicle_name);
       $owner->vehicle_number = json_encode($request->vehicle_number);



        if($request->file('owner_image')){
            $file= $request->file('owner_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('owner_images'), $filename);
            $owner['owner_image']= $filename;
        }
          if($request->file('aadhar_image')){
            $file= $request->file('aadhar_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('aadhar_images'), $filename);
            $owner['aadhar_image']= $filename;
        }

        $owner->save();
         return redirect('add_tenant')->withSuccess('Great! Data has been successfully uploaded.');

    }
    public function tenant_view(){
        $tenant = Tenant::all();
        return view('tenant.tenant_view',['tenant_details'=>$tenant]);
    }

    public function edit_tenant_details($id){
        $tenant = Tenant::find($id);
        return view('tenant.edit_tenant_details',['tenant_details'=>$tenant]);
    }
     public function tenant_profile_view($id){
        $id = Crypt::decrypt($id);
        $tenant = Tenant::find($id);
        return view('tenant.tenant_profile_view',['tenant_details'=>$tenant]);
    }

    public function delete_tenant_details($id){
         $tenant = Tenant::find($id);
         $tenant->destroy($id);
         return redirect('tenant_view')->withSuccess('Great your Data has been successfully Deleted');
    }

    public function update_tenant_details(Request $request, $id){
      
     $request->validate([
         'owner_name'=>'required|max:255',
         'tenant_name'=>'required|max:255',
         'mobile'=>'required|max:10|min:10',
         'aadhar_no'=>'required|max:12|min:12',
         'block'=>'required|max:255',
         'floor'=>'required|max:255',
         'house_no'=>'required|max:255',
         'email'=>'required|email|max:255',
          'status'=>'required|max:255',
          'profession'=>'required|max:255',
          'owner_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048|nullable',
          'aadhar_image' => 'required|max:10000|mimes:doc,docx,pdf,jpeg,png,jpg,gif,svg',
          'vehicle_type'=>'required|max:255',
          'vehicle_name'=>'required|max:255',
          'vehicle_number'=>'required|max:255',
        ]);

       $owner = Tenant::find($id);
       $owner->owner_name = $request->owner_name;
        $owner->tenant_name = $request->tenant_name;
       $owner->mobile = $request->mobile;
       $owner->block = $request->block;
       $owner->floor = $request->floor;
       $owner->house_no = $request->house_no;
       $owner->email = $request->email;
       $owner->status = $request->status;
       $owner->profession = $request->profession;
       $owner->aadhar_no = $request->aadhar_no;
       $owner->vehicle_type = json_encode($request->vehicle_type);
       $owner->vehicle_name = json_encode($request->vehicle_name);
       $owner->vehicle_number = json_encode($request->vehicle_number);



        if($request->file('owner_image')){
            $file= $request->file('owner_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('owner_images'), $filename);
            $owner['owner_image']= $filename;
        }
          if($request->file('aadhar_image')){
            $file= $request->file('aadhar_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('aadhar_images'), $filename);
            $owner['aadhar_image']= $filename;
        }

        $owner->save();
         return redirect('tenant_view')->withSuccess('Great! Data has been successfully Updated.');

    }
}
