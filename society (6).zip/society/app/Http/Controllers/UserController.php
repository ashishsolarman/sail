<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Sale;
use App\Models\Rent;
use App\Models\Contact;
use App\Models\RentStatus;
use App\Models\Status;
use App\Models\City;

class UserController extends Controller
{
    public function sale_show()
    {
    	$sales = Sale::latest()->get();

    	// dd($sales);

    	 return view('user.sale')->with('sales', $sales);
    }

    public function show_details($id)
    {	
    	// $sale = Sale::get();
    	$sales = Sale::where('id', $id)->get()->last();
    	$amenities = explode(",", $sales->amenity);
      $amenities = str_replace("_"," ", $amenities);
    	// $images = explode(",", $sales->image);
    	// $images = $sales->image;
    	// dd($images);

    	return view('user.details')->with('sales', $sales)->with('amenities', $amenities);

    }

    public function sale_mail_send(Request $request)

    { 

        $request->validate([ 

            'first_name' => 'required', 
            'last_name' => 'required', 
            'email' => 'required|email', 
            'message_details' => 'required',

        ]); 

        $contact = new Contact;

        $contact->first_name = $request->first_name;
        $contact->last_name = $request->last_name;
        $contact->email = $request->email;
        $contact->message_details = $request->message_details;

        $contact->save(); 

        //  Send mail to admin
        \Mail::send('user.contact_email',
             array(
                 'first_name' => $request->get('first_name'),
                 'last_name' => $request->get('last_name'),
                 'email' => $request->get('email'),
                 'message_details' => $request->get('message_details'),
             ), function($message) use ($request)
               {
                  $message->from($request->email);
                  $message->to('vikrant@solarman.in');
                  $message->subject('Enquiry Form');
               }); 

        return back()->with(['success' => 'Enqiry Form Submit Successfully']);

    }

    public function rent_show()
    {
    	$rents = rent::latest()->get();

    	// dd($sales);

    	 return view('user.rent')->with('rents', $rents);
    }

    public function rent_details($id)
    {	
    	// $sale = Sale::get();
    	$rents = Rent::where('id', $id)->get()->last();
      $amenities = explode(",", $rents->amenity);
    	$amenities = str_replace("_"," ", $amenities);
    	// $images = explode(",", $sales->image);
    	// $images = $sales->image;
    	// dd($amenities);

    	return view('user.rent_details')->with('rents', $rents)->with('amenities', $amenities);

    }

    public function rent_mail_send(Request $request) 

    { 

        $request->validate([ 

            'first_name' => 'required', 
            'last_name' => 'required', 
            'email' => 'required|email', 
            'message_details' => 'required',

        ]); 

        $contact = new Contact;

        $contact->first_name = $request->first_name;
        $contact->last_name = $request->last_name;
        $contact->email = $request->email;
        $contact->message_details = $request->message_details;

        $contact->save(); 

        //  Send mail to admin
        \Mail::send('user.contact_email',
             array(
                 'first_name' => $request->get('first_name'),
                 'last_name' => $request->get('last_name'),
                 'email' => $request->get('email'),
                 'message_details' => $request->get('message_details'),
             ), function($message) use ($request)
               {
                  $message->from($request->email);
                  $message->to('vikrantbhargve@gmail.com');
               });

        return back()->with(['success' => 'Enqiry Form Submit Successfully']);

    }

    public function rent_listing(Request $request)
    {

    	$rents = rent::latest()->get();
    	$sales = Sale::latest()->get();
      $rent_status = RentStatus::get();
      $city = City::get();
      $status = Status::get();
      // $rent_filter = 

    	// dd($status);

    	 return view('user.first')->with('rents', $rents)->with('sales', $sales)->with('rent_status', $rent_status)->with('city', $city)->with('status', $status);
    }

    public function rent_search(Request $request)
    {

      $data = \DB::table('rents');
        if( $request->status){
            $data = $data->where('status', 'LIKE', "%".$request->status."%");
        }
        if( $request->city){
            $data = $data->where('city', 'LIKE', "%" . $request->city . "%");
        }
        
        $data = $data->paginate(10);
        return view('user.rent_search', compact('data'));
    }

    public function sale_search(Request $request)
    {
      $data = \DB::table('sales');
        if( $request->status){
            $data = $data->where('status', 'LIKE', "%".$request->status."%");
        }
        if( $request->city){
            $data = $data->where('city', 'LIKE', "%" . $request->city . "%");
        }
        
        $data = $data->paginate(10);
        return view('user.sale_search', compact('data'));
    }


    public function profile(){
        return view('profile.profile');
    }
}
