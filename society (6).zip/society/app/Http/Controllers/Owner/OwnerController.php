<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Owner;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Collection;

class OwnerController extends Controller
{
    public function owner(){
        return view('owner.owner');
    } 

    public function store_owner(Request $request){

        $request->validate([
        'owner_tenant'=>'required|max:255',
         'owner_name'=>'required|max:255',
         'mobile'=>'required|unique:owner_details|max:10|min:10', 
         'aadhar_no'=>'required|max:12|min:12',
         'block'=>'required|max:255',
         'floor'=>'required|max:255',
         'house_no'=>'required|max:255',
         'email'=>'required|email|max:255',
          'status'=>'required|max:255',
          'profession'=>'required|max:255',
          'owner_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048|nullable',
          'aadhar_image' => 'required|max:1000|mimes:doc,docx,pdf,jpeg,png,jpg,gif,svg',
          'vehicle_type'=>'required|max:255',
          'vehicle_name'=>'required|max:255',
          'vehicle_number'=>'required|max:255',
        ]);

       $owner = new Owner;
      $owner->owner_tenant = $request->owner_tenant;
       $owner->owner_name = $request->owner_name;
       $owner->mobile = $request->mobile;
       $owner->block = $request->block;
       $owner->floor = $request->floor;
       $owner->house_no = $request->house_no;
       $owner->email = $request->email;
       $owner->status = $request->status;
       $owner->profession = $request->profession;
       $owner->aadhar_no = $request->aadhar_no;

       $owner->vehicle_type = json_encode($request->vehicle_type);
       $owner->vehicle_name = json_encode($request->vehicle_name);
       $owner->vehicle_number = json_encode($request->vehicle_number);


        if($request->file('owner_image')){
            $file= $request->file('owner_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('owner_images'), $filename);
            $owner['owner_image']= $filename;
        }
          if($request->file('aadhar_image')){
            $file= $request->file('aadhar_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('aadhar_images'), $filename);
            $owner['aadhar_image']= $filename;
        }

        $owner->save();
         return redirect('add_owner')->withSuccess('Great! Data has been successfully uploaded.');

    }

    public function owner_view(){
        $owner_details = Owner::orderBy('id', 'DESC')->paginate(10);
        return view('owner.owner_view',compact('owner_details'));
    }

    public function delete_details($id){
       $owner = Owner::find($id);
       $owner->destroy($id);
       return redirect('owner_view')->withSuccess('Great your Data has been successfully Deleted');
    }


    public function owner_profile_view($id){
         $id = Crypt::decrypt($id);
        $owner = Owner::find($id);
        return view('owner.owner_profile_view',['owner_details'=>$owner]);
    }

    public function edit_owner_details($id){
        $id = Crypt::decrypt($id);
        $owner = Owner::find($id);
        return view('owner.edit_owner_details',['owner_details'=>$owner]);
    }

    public function update_owner_details(Request $request, $id){
       
        $request->validate([
         'owner_name'=>'required|max:255',
         'mobile'=>'required|max:10|min:10',
         'aadhar_no'=>'required|max:12|min:12',
         'block'=>'required|max:255',
         'floor'=>'required|max:255',
         'house_no'=>'required|max:255',
         'email'=>'required|email|max:255',
          'status'=>'required|max:255',
          'profession'=>'required|max:255',
          'owner_image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048|nullable',
          'aadhar_image' => 'mimes:doc,docx,pdf,jpeg,png,jpg,gif,svg',
          'vehicle_type'=>'max:255',
          'vehicle_name'=>'max:255',
          'vehicle_number'=>'max:255',
        ]);

       $owner = Owner::find($id);
       $owner->owner_name = $request->owner_name;
       $owner->mobile = $request->mobile;
       $owner->block = $request->block;
       $owner->floor = $request->floor;
       $owner->house_no = $request->house_no;
       $owner->email = $request->email;
       $owner->status = $request->status;
       $owner->profession = $request->profession;
       $owner->aadhar_no = $request->aadhar_no;

       $owner->vehicle_type = json_encode($request->vehicle_type);
       $owner->vehicle_name = json_encode($request->vehicle_name);
       $owner->vehicle_number = json_encode($request->vehicle_number);


        if($request->file('owner_image')){
            $file= $request->file('owner_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('owner_images'), $filename);
            $owner['owner_image']= $filename;
        }
          if($request->file('aadhar_image')){
            $file= $request->file('aadhar_image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('aadhar_images'), $filename);
            $owner['aadhar_image']= $filename; 
        }

        $owner->save();
         return redirect('owner_view')->withSuccess('Great! Data has been successfully Updated.');
    }


     public function search_name(){ 
    $search = $_GET['name'];
    $owner = Owner::where('owner_name','LIKE','%'.$search.'%')->get(); 
     return view('owner.residence_search',['owner_details'=>$owner]);
   }

     public function searchbymobile(){
    $search = $_GET['mobile'];
    $owner = Owner::where('mobile','LIKE','%'.$search.'%')->get();
     return view('owner.residence_search',['owner_details'=>$owner]);
   }

   public function search_address(){
    $search = $_GET['address'];
    $owner = Owner::where('house_no','LIKE','%'.$search.'%')
    ->get();
     return view('owner.residence_search',['owner_details'=>$owner]);
   }
}
