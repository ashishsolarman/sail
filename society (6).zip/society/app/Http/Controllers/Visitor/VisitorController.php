<?php

namespace App\Http\Controllers\Visitor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Visitor;

class VisitorController extends Controller
{
   // public function visit_master(){
   //  return view('allowance.visit_master');
   // }

   

// 'phone' => 'required|regex:/(01)[0-9]{9}/'

}
