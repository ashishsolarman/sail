<?php

namespace App\Http\Controllers\Allowance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Visitor;
use App\Models\Appointment;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Storage;
use Illuminate\Support\Facades\Request as Input; 

class AllowanceController extends Controller
{
    public function gate_pass_form(){
        return view('allowance.gate_pass_form');
    }

    public function store_visitor_details(Request $request){
 
        $check = Visitor::where('mobile_no',$request->mobile_no)->get();
         $visitor = new Visitor;
          $visitor->name = $request->name;
          $visitor->mobile_no = $request->mobile_no;
          $visitor->id_type = $request->id_type;
          $visitor->id_no = $request->id_no;
          $visitor->vehicle_type = $request->vehicle_type;
          $visitor->vehicle_name = $request->vehicle_name;
          $visitor->vehicle_number = $request->vehicle_number;
 
      if($request->image == True){
        $img = $request->image;
        $folderPath = "visitors_images/";
        $image_parts = explode(";base64,", $img);
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1];
        $image_base64 = base64_decode($image_parts[1]);
        $fileName = uniqid() . '.png';
        $file = $folderPath . $fileName;
        Storage::put($file, $image_base64);
        $visitor->image = $fileName;
     }
            if(count($check) > 0){
              $appointment = new Appointment;
                $appointment->purpose = $request->purpose;
                $appointment->visitor_id = $request->visitor_id;
                $appointment->meeting_date = $request->meeting_date;
                $appointment->save();
    }else{
            $visitor->save();
             $appointment = new Appointment;
                $appointment->visitor_id = $visitor->id;
                $appointment->purpose = $request->purpose;
                $appointment->meeting_date = $request->meeting_date;
                $appointment->save();
}
          return redirect('visit_master')->withSuccess('Great your Data has been successfully uploaded');
    }

        public function view_visitors(){
         $visitors = DB::table('visitors')
            ->join('appointment_master', 'visitors.id', '=', 'appointment_master.visitor_id')
            ->select('visitors.*', 'appointment_master.*')
            ->get();
        return view('allowance.view_visitors',compact('visitors'));
    }

    public function visitor_history($visitor_id){
        $visitor_id = Crypt::decrypt($visitor_id);
        $visitor = Appointment::where('visitor_id',$visitor_id)->latest()->get();

        return view('allowance.visitor_history',compact('visitor'));
    }

    public function delete_visitors($id){
       $visitors = Visitor::find($id);
       $visitors->destroy($id);
       return redirect('view_visitors')->withSuccess('Great your Data has been successfully Deleted');

    }

    public function visitor_profile($id){
        $id= Crypt::decrypt($id);
       $visitors = Visitor::find($id);
       return view('allowance.visitor_profile',['visitors'=>$visitors]);
    }

    public function edit_visitor_detail($id){
        $id = Crypt::decrypt($id);
     $visitor = Visitor::find($id);
     return view('allowance.edit_visitor_detail',['visitors'=>$visitor]);
    }

    public function update_visitor_detail(Request $request, $id){
          $request->validate([
      'name'=>'required|max:255',
      'mobile_no'=>'required|min:10:max:10',
      'id_type'=>'required|max:255',
      'id_no'=>'required|max:255',
      'vehicle_type'=>'max:255',
      'vehicle_name'=>'max:255',
      'vehicle_number'=>'max:255',
        

     ]);

      $visitor = Visitor::find($id);
      $visitor->name = $request->name;
      $visitor->mobile_no = $request->mobile_no;
      $visitor->id_type = $request->id_type;
      $visitor->id_no = $request->id_no;
      $visitor->vehicle_type = $request->vehicle_type;
      $visitor->vehicle_name = $request->vehicle_name;
      $visitor->vehicle_number = $request->vehicle_number;
     
      $visitor->save();
      return redirect('view_visitors')->withSuccess('Great your Data has been successfully Updated');   
    }

 
   public function search(){
    $search = $_GET['query'];
    $visitors = Visitor::where('name','LIKE','%'.$search.'%')->get();
     return view('allowance.view_visitors',compact('visitors'));
   }

   public function searchbymobile_no(){
     $search = $_GET['mobile'];
    $visitors = Visitor::where('mobile_no','LIKE','%'.$search.'%')->get();
     return view('allowance.view_visitors',compact('visitors'));
   }

      public function searchbydate(){
     $search = $_GET['id_no'];
    $visitors = Visitor::where('id_no','LIKE','%'.$search.'%')->get();
     return view('allowance.view_visitors',compact('visitors'));
   }

public function visit_master(){
    return view('allowance.visit_master');
   }

 public function visitor_search(Request $request)
    {

      $data = \DB::table('visitors');
        if( $request->name){
            $data = $data->where('name', 'LIKE', "%".$request->name."%");
        }
        if( $request->mobile_no){
            $data = $data->where('mobile_no', 'LIKE', "%" . $request->mobile_no . "%");
        }
        
        $data = $data->paginate(10);
        return view('allowance.gate_pass_form', compact('data'));
    }

}
