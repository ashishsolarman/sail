<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tenant extends Model
{
    use HasFactory;
      protected $table = 'tenant_details';
    protected $primarykeys = 'id';
    protected $fillable = ['tenant_name','owner_name','mobile','block','floor','house_no','email','status','profession','owner_image','aadhar_no','aadhar_image','vehicle_type','vehicle_name','vehicle_number'];
}
