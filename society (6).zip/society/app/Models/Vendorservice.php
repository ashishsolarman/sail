<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vendorservice extends Model
{
    use HasFactory;
    protected $table = 'vendor_service';
    protected $primarykeys = 'id';
    protected $fillable = ['visit_date','vendor_id','services'];
}
