<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Collection extends Model
{
    use HasFactory;
    protected $table ='collection_master';
    protected $primarykeys = 'id';
    protected $fillable = ['payment_mode','amount','resident_id','from_date','to_date'];
}
