<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Owner extends Model
{
    use HasFactory;
    protected $table = 'owner_details';
    protected $primarykeys = 'id';
    protected $fillable = ['owner_tenant','owner_name','mobile','block','floor','house_no','email','status','profession','owner_image','aadhar_no','aadhar_image','vehicle_type','vehicle_name','vehicle_number'];
}
