<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Allowance extends Model
{
    use HasFactory;
    protected $table = 'visitors'; 
    protected $fillable = ['visitor_name','email','mobile_no','duration','vehicle_type','vehicle_name','vehicle_number'];
}
