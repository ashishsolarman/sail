<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vendor extends Model
{
    use HasFactory;
    protected $table = 'vendor_master';
    protected $primarykeys = 'id';
    protected $fillable = ['name','mobile_no','id_type','id_no','image','meeting_date','pupose'];
}
