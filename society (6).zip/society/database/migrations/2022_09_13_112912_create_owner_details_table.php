<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOwnerDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('owner_details', function (Blueprint $table) {
            $table->id();
            $table->string('owner_tenant');
            $table->string('owner_name');
            $table->string('mobile');
            $table->string('block');
            $table->string('floor');
            $table->string('house_no');
            $table->string('email');
            $table->string('status');
            $table->string('profession');
            $table->string('owner_image');
            $table->string('aadhar_no');
            $table->string('aadhar_image');
            $table->string('vehicle_type');
            $table->string('vehicle_name');
            $table->string('vehicle_number');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('owner_details');
    }
}
