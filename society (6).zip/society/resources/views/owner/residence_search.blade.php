@extends('layouts.admin_app')
@section('content')
	<div class="container" >
		@if(Session::has('success'))
            <div class="alert alert-success">
            {{ Session::get('success') }}
            </div>
          @endif
		<div class="row justify-content-center">
	        <div class="col-md-12">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Owner List </div>
       
	           <div class="row">
            <div class="col-md-12">
               <div class="row">
              <div class="col-md-4">
               <form class="example" type="get" action="{{route('search_name')}}">
               <label for="project_name">{{_('SEARCH BY NAME')}}<span class="text-danger">*</span></label>
                <input type="search" class="form-control" placeholder="Search.." name="name">
                <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                  </form>
                  </div>
                <div class="col-md-4">
                <form class="example" type="get" action="{{url('searchbymobile')}}">
                <label for="project_name">{{_('SEARCH BY MOBILE')}}<span class="text-danger">*</span></label>
                 <input type="number" class="form-control"  placeholder="Search.." name="mobile">
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div>
                    <div class="col-md-4">
                <form class="example" type="get" action="{{url('search_address')}}">
                <label for="project_name">{{_('SEARCH BY Address')}}<span class="text-danger">*</span></label>
                 <input type="text" class="form-control" placeholder="Search.." name="address" >
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div> 
                  </div>
              <div class="card">
                <div class="table-responsive pt-3">
                  <table class="table table-striped project-orders-table">
                    <thead>
                      <tr>
                        <th class="ml-5">ID</th>
                        <th>Residence</th>
                        <th>Owner name</th>
                         <th>Phone Number</th>
                        <th>Address</th>
                        <th>Email</th>
                        <th>Status</th>
                     
                        <th style="text-align: center;">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      @if(count($owner_details) > 0)
                      @foreach($owner_details as $item)
                      <tr>
                        <td>{{$item->id}}</td>
                        <td>{{$item->owner_tenant}}</td>
                        <td>{{$item->owner_name}}</td>
                        <td>{{$item->mobile}}</td>
                        <td>{{$item->block}}-{{$item->house_no}},{{$item->floor}}</td>
                        <td>{{$item->email}}</td>
                        
                        <td>
                          @if($item->status == "Active")
                          <div class="col">
                          <label class="badge badge-success">Active</label>                     
                         </div>
                         @else
                        <div class="col">
                        <label class="badge badge-danger">Inactive</label>                     
                        </div>
                        @endif
                      </td>
                    
                        <td>

                          <div class="d-flex align-items-center">
                             @php $prodID= Crypt::encrypt($item->id); @endphp 
                          	 <a href="owner_profile_view/{{$prodID}}" type="button" class="btn btn-info btn-sm btn-icon-text mr-3">
                              View
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>                     
                            </a>
                            @php $editID = Crypt::encrypt($item->id) @endphp
                            <a href="edit_owner_details/{{$editID}}" type="button" class="btn btn-success btn-sm btn-icon-text mr-3">
                              Edit
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                            </a>
                            <a href="delete_details/{{$item->id}}" class="btn btn-danger btn-sm btn-icon-text">
                              Delete
                              <i class="typcn typcn-delete-outline btn-icon-append"></i>                          
                            </a>
                          </div>
                        </td>
                      </tr>
                 @endforeach
                 @else<th>No Data Available</th>
                 
                    </tbody>
                 
                 @endif
                  </table>
                </div>
              </div>
            </div>
          </div>
     				<!--  pagination  -->
			
	        </div>
	    </div>
    </div>
	
@endsection