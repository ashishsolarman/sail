@extends('layouts.admin_app')
@section('css')
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block; 
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  </style>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
  <link href="{{ asset('public/css/jquery.multiselect.css') }}" rel="stylesheet" />
@endsection
@section('content')
  <div class="container" style="margin-top: 1%;">
    @if ($message = Session::get('success'))
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button>
   
              <strong>{{ $message }}</strong>
   
      </div>
      <br>
    @endif
         @foreach($data as $item)
@endforeach 
@if(!empty($item))
  <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Maintenance Money</div>
                <form action="{{route('payment_collect')}}" method="post" enctype="multipart/form-data">
                @csrf
          <div class="form-row" >
 
          <div class="form-group col-md-6"> 
           <label for="city">Start From<span class="text-danger">*</span></label>
          <input class="form-control" name="from_date" type="date" required> 
           </div>

             <div class="form-group col-md-6"> 
           <label for="city">To End<span class="text-danger">*</span></label>
          <input class="form-control" name="to_date" type="date" required> 
           </div>
   
            <div class="form-group col-md-6">
              <label for="city">Mode of Payment<span class="text-danger">*</span></label>
                <select class="custom-select mr-sm-2" id="status" name="payment_mode" required>
                <option selected>-</option>
                <option value='Cash'>Cash</option>
                <option value='Online'>Online</option>
       
                       
              </select>
              
            </div>

              <div class="form-group col-md-6">
              <label for="status">Amount<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2" id="status" name="amount" required> 
                <option selected>-</option>
                <option value='300'>₹ 300</option>
                <option value='600'>₹ 600</option>
                <option value='900'>₹ 900</option>
                <option value='1200'>₹ 1200</option>
                <option value='1500'>₹ 1500</option>
                <option value='1800'>₹ 1800</option>
                <option value='2100'>₹ 2100</option>
                <option value='2400'>₹ 2400</option>
                <option value='2700'>₹ 2700</option>
                <option value='3000'>₹ 3000</option>
               
                       
              </select>
            </div>

    
          <input class="form-control" name="resident_id" type="hidden" value="{{$item->id}}"> 
          
          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-info">Collect</button>
            </div>
        </form>


          <div class="col-md-12">
                <div class="box box-default">
                  <div class="box-body">
                      <div class="row">
                                                
                          <div class="container  table-responsive py-5">
                            <table class="table table-bordered table-striped" width="100%">
                                    <tbody><tr>
                                        <th width="27%">Resident ID</th>
                                        <td width="48%">#
                                        {{$item->id}}</td>
                                        <td rowspan="3"><img src="{{asset('owner_images')}}/{{$item->owner_image}}" class="image_responsive" style="width:150px;height:150px;"></td>
                                    </tr>
                                    <tr>
                                        <th>House</th><td>{{$item->owner_tenant}}</td>
                                    </tr>
                                    <tr>
                                        <th>Address</th>
                                        <td>
                                        {{$item->block}}-{{$item->house_no}},{{$item->floor}}
                                      </td>
                                    </tr>
                                </tbody></table>
                          </div>
                      </div>
                      <div class="row">
                          <div class="container  table-responsive">
                            <table class="table table-bordered table-striped">
                              <tbody>
                                  <tr>
                                      <th>Name</th><td>{{$item->owner_name}}</td>
                                      <th>Mobile</th><td>{{$item->mobile}}</td>
                                  </tr>
                                  <tr>
                                   
                                      <th>Identity Card No.</th>
                                      <td><a href="{{asset('aadhar_images')}}/{{$item->aadhar_image}}">{{$item->aadhar_no}}</a>
                                      </td>
                                      <th>Profession</th>
                                      <td>
                                         {{$item->profession}}
                                      </td>
                                  </tr>
                                  
                               <!--    <tr>
                                   
                                      <th>Payment Mode</th>
                                      <td>{{_('xxxx')}}
                                      </td>
                                      <th>Amount</th>
                                      <td>
                                          {{_('xxxx')}}
                                      </td>
                                  </tr> -->
                                
                              </tbody>
                            </table>
                            
                        </div>
                    </div>
                                      </div>
                </div>
              </div>
        
            </div>
        </div>
    </div>
  
  @else<div class="text-center"><h1 style="color:red;">Unable to Found <br> Record Not Found</h1></div>
  @endif
</div>
@endsection
@push('scripts')
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
  
@endpush
