@extends('layouts.admin_app')
@section('css')
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  </style>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
  <link href="{{ asset('public/css/jquery.multiselect.css') }}" rel="stylesheet" />
@endsection
@section('content')
  <div class="container" style="margin-top: 1%;">
    @if ($message = Session::get('success'))
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button> 
   
              <strong>{{ $message }}</strong>
   
      </div>
      <br>
    @endif
  <div class="container" style="margin-top: 1%;">
    <div class="row justify-content-center">
        <div class="col-md-10">
                      
<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">{{_('Payment Collection')}} </div>
<div class="form-group col-md-12">
    <form method="post" action="{{route('collection_search')}}">
                @csrf
             <div class="form-row" style="margin-top:3%;">
             <div class="form-group col-md-12">
              <label for="project_name">{{_('MOBILE')}}<span class="text-danger">*</span></label>
              <input  type="number" min="0" oninput="this.value = Math.abs(this.value)" placeholder="Enter mobile" class="form-control" value="{{ request()->input('mobile') }}" name="mobile">
              @error('mobile')
              <span style="color:red">{{$message}}</span>
              @enderror
              </div>
              <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-success">SUBMIT</button>
              </div>
              </div> 
     
        </form>
      </div>
        
      
    </div>
</div>
</div>
@endsection
@push('scripts')
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
  
@endpush
