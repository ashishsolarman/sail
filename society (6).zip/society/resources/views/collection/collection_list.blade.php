@extends('layouts.admin_app')
@section('content')
  <div class="container" >
    @if(Session::has('success'))
            <div class="alert alert-success">
            {{ Session::get('success') }}
            </div>
          @endif
    <div class="row justify-content-center">
          <div class="col-md-12">
            <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Payment List </div>
                       <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="table-responsive pt-3">
                  <table class="table table-striped">
                      <thead class="thead-dark">
                        <tr>
                          <th>ID</th>
                          <th>Address</th>
                          <th>Amount</th>
                          <th style="text-align: center;">Payment Mode</th>
                          <th>Payment Date</th>
                          <th>Status</th>
                          <th >Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($users as $item)
                        <tr>
                           <td>#{{$item->id}}</td>
                           <td>{{$item->block}}-{{$item->house_no}}</td>
                           <td>₹ {{$item->amount}}</td>
                           <td style="text-align: center;">{{$item->payment_mode}}</td>
                          <td>{{date('d-m-Y', strtotime($item->created_at))}}</td>
                          <td><div class="col">
                            <?php $created_at = $item->created_at;
                             $date1=date('y-m-d', strtotime($created_at));
                             $date2 = date('y-m-d');
                             $diff = abs(strtotime($date2) - strtotime($date1));

                        $years = floor($diff / (365*60*60*24));
                       $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
                       $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

                       printf("%d years, %d months, %d days\n", $years, $months, $days);
                            ?>

                          <label class="badge badge-danger">pending</label>             
                         </div></td>
                          
                              <td style="text-align: center;">

                          <div class="d-flex align-items-center">
                             <a href="{{route('payment_slip')}}" type="button" class="btn btn-danger btn-sm btn-icon-text mr-3">
                              Slip
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>                     
                            </a>
                            @php $prodID= Crypt::encrypt($item->resident_id); @endphp 
                         <a href="collection_history/{{$prodID}}" type="button" class="btn btn-info btn-sm btn-icon-text mr-3">
                              Payment History
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>              
                            </a>
                         
                          </div>
                        </td>
                        </tr>
                    
                        @endforeach
                     
                      </tbody>
                    </table>
                </div>
              </div>
            </div>
          </div>
        <!-- pagination -->
      
          </div>
      </div>
    </div>
  
@endsection