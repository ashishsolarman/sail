@extends('layouts.admin_app')
@section('css')
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  #cont{
  position: relative;

}
.son{
  position: absolute;
  top:0;
  left:0;

}




#control{
  position:absolute;

  left:0;

  z-index: 50;
  background: HoneyDew ;
  opacity:0.7;
  color:#fff;
  text-align: center;

}
#snap{
  background-color: dimgray ;

}
#retake{
  background-color: coral ;

}

#close{
  background-color: lightcoral ;

}
.hov{
  opacity:.8;
  transition: all .5s;
}
.hov:hover{
  opacity:1;

  font-weight: bolder;
} 
/*#canvas{
  z-index: 1;
}
#video{
  z-index: 3;
}*/

  </style>

@section('content')
  <div class="container" style="margin-top: 1%;">
    @if ($message = Session::get('success'))
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button>
   
              <strong>{{ $message }}</strong>
   
      </div>
      <br>
    @endif
  <div class="container" style="margin-top: 1%;">
    <div class="row justify-content-center">
 
        <div class="col-md-10">

  <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">{{_('UPDATE VISITOR')}}</div>
  <form action="{{route('update_visitor_detail',$visitors->id)}}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
            <div class="form-row" style="margin-top:3%;">
             <div class="form-group col-md-6">
              <label for="project_name">{{_('FULL NAME')}}<span class="text-danger">*</span></label>
              <input  type="text" value="{{$visitors->name}}" class="form-control" name="name" id="name">
              @error('name')
              <span style="color:red">{{$message}}</span>
              @enderror
             </div>
             <div class="form-group col-md-6">
              <label for="project_name">{{_('PHONE NUMBER')}}<span class="text-danger">*</span></label>
              <input type="number" class="form-control" value="{{$visitors->mobile_no}}" name="mobile_no" min="0" oninput="this.value = Math.abs(this.value)">
                @error('mobile_no')
              <span style="color:red">{{$message}}</span>
              @enderror
             </div>
         
                  <div class="form-group col-md-6">
              <label for="status">{{_('IDENTITY CARD TYPE.')}}<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2"  id="id_type" name="id_type"  style="height:48px;">
                <option selected>{{$visitors->id_type}}</option>
               
                  <option value="Aadhar Card">Aadhar Card</option>
                 <option value="Passport">Passport</option>
                 <option value="Pan Card">Pan Card</option>
                 <option value="Voter Card">Voter Card</option>
                 <option value="Driving Licence">Driving Licence</option>
              
              </select>
                @error('id_type')
              <span style="color:red">{{$message}}</span>
              @enderror
            </div>
               <div class="form-group col-md-6">
              <label for="project_name">{{_('IDENTITY CARD NO.')}}<span class="text-danger">*</span></label>
              <input style="text-transform:uppercase" type="text"   class="form-control" value="{{$visitors->id_no}}" name="id_no" id="id_no">
               @error('id_no')
              <span style="color:red">{{$message}}</span>
              @enderror
             </div>

     <!-- Webcamera section -->
          
             <div class="form-group col-md-12"><img src="{{asset('uploads/visitors_images')}}/{{$item->image}}" class="col-md-6" width="300" height="200"/></div>
        

            <!-- end webcamera section -->
             
            <div class="form-group col-md-4">
              <label for="status">{{_('VEHICLE TYPE')}}<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2"  id="vehicle_type" name="vehicle_type"  style="height:48px;">
                <option selected>{{$visitors->vehicle_type}}</option>
               
                  <option value="Two Wheeler">Two Wheeler</option>
                 <option value="Three Wheeler">Three Wheeler</option>
                 <option value="Four Wheeler">Four Wheeler</option>
              
              </select>
                @error('vehicle_type')
              <span style="color:red">{{$message}}</span>
              @enderror
            </div>
          
          
               <div class="form-group col-md-4">
              <label for="city">{{_('VEHICLE NAME')}}<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" value="{{$visitors->vehicle_name}}" id="city" name="vehicle_name">
                  @error('vehicle_name')
              <span style="color:red">{{$message}}</span>
              @enderror
            </div>
            <div class="form-group col-md-4">
              <label for="city">{{_('VEHICLE NUMBER')}}<span class="text-danger">*</span></label>
             <input style="text-transform:uppercase" type="text" value="{{$visitors->vehicle_number}}" class="form-control" id="city" name="vehicle_number">
               @error('vehicle_number')
              <span style="color:red">{{$message}}</span>
              @enderror
            </div>
        

        </div> 
            </div>
          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-info">UPDATE</button>
            </div>
        </form>
            </div>
        </div>
    </div>
</div>
@endsection
@push('scripts')
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script language="JavaScript">
    Webcam.set({
        width: 490,
        height: 350,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
    
    Webcam.attach( '#my_camera' );
    
    function take_snapshot() {
        Webcam.snap( function(data_uri) {
            $(".image-tag").val(data_uri);
            document.getElementById('results').innerHTML = '<img src="'+data_uri+'"/>';
        } );
    }
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script> 
$(document).ready(function(){
  $("#flip").click(function(){
    $("#panel").slideDown("slow");
  });
});
</script>
@endpush
