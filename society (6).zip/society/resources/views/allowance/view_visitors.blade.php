@extends('layouts.admin_app')
@section('content')
	<div class="container">
		@if(Session::has('success'))
            <div class="alert alert-success">
            {{ Session::get('success')}}
            </div>
          @endif
		<div class="row justify-content-center">
	        <div class="col-md-12">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">{{_('ALL VISITORS')}}</div>
              <div class="row">
              <div class="col-md-4">
            <form class="example" type="get" action="{{url('search')}}">
               <label for="project_name">{{_('SEARCH BY NAME')}}<span class="text-danger">*</span></label>
                <input type="search" class="form-control" placeholder="Search.." name="query">
                <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                  </form>
                  </div>
                <div class="col-md-4">
                <form class="example" type="get" action="{{url('searchbymobile_no')}}">
                <label for="project_name">{{_('SEARCH BY MOBILE')}}<span class="text-danger">*</span></label>
                 <input type="text" class="form-control" name="mobile" placeholder="Search.." name="search">
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div>
                <div class="col-md-4">
                <form class="example" type="get" action="{{url('searchbydate')}}">
                <label for="project_name">{{_('SEARCH BY ID NO.')}}<span class="text-danger">*</span></label>
                 <input type="text" class="form-control" placeholder="Search.." name="id_no">
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div> 
                  </div>
	       <div class="row">
          <div class="col-md-12">
          
         

              <div class="card">

                <div class="table-responsive pt-3">
                  <div id="print-area-2" class="print-area">
                  <table class="table table-striped project-orders-table" id="theTable" >
                    <thead>
                      <tr>
                        <th class="ml-5">ID</th>
                        <th>Full Name</th>
                         <th>Mobile</th>
                       
                        <th>Identity Card</th>
                        <th>Identity Card No.</th>
                        
                         <th>Photo</th>
                         <th>Created At</th>
                       
                        <th style="text-align: center;">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                      @foreach($visitors as $item)
                    
                      <tr>
                        <td>{{$item->id}}</td>
                        <td>{{$item->name}}</td>
                        <td>{{$item->mobile_no}}</td>
                        <td>{{$item->id_type}}</td>
                        <td>{{$item->id_no}}</td>
                        
                        <td><img src="{{asset('uploads/visitors_images')}}/{{$item->image}}" class="img-responsive" style="width:100px;height:100px;"></td>
                        <td>{{$item->created_at}}</td>


                        <td>

                          <div class="d-flex align-items-center">
                             @php $prodID= Crypt::encrypt($item->id); @endphp 
                          	 <a href="visitor_profile/{{$prodID}}" type="button" class="btn btn-info btn-sm btn-icon-text mr-3">
                              View
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>                
                            </a>
                             @php $visitor= Crypt::encrypt($item->visitor_id); @endphp 
                             <a href="visitor_history/{{$visitor}}" type="button" class="btn btn-warning btn-sm btn-icon-text mr-3">
                              History
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>                
                            </a>
                            @php $editID = Crypt::encrypt($item->id) @endphp
                            <a href="edit_visitor_detail/{{$editID}}" type="button" class="btn btn-success btn-sm btn-icon-text mr-3">
                              Edit
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                            </a>
                            <a href="delete_visitors/{{$item->id}}" class="btn btn-danger btn-sm btn-icon-text">
                              Delete
                              <i class="typcn typcn-delete-outline btn-icon-append"></i>                          
                            </a>
                          </div>
                        </td>
                      </tr>
                 @endforeach
                    </tbody>
                  </table>
                </div>

                </div>
              </div>
            </div>
          </div>
				<!-- pagination -->
    
			
	        </div>
	    </div>
       <div class="row">
            <div class="col-md-4" style="text-align: center;">
              <a class="btn btn-success" id="btnExport" href="#" onClick="fnExcelReport()">Export to xls</a>
              <iframe id="dummyFrame" style="display:none"></iframe>
            </div>
            <div class="col-md-4" ></div>
            <div class="col-md-4" style="text-align: center;">
               <a class="no-print btn btn-info"  href="javascript:printDiv('print-area-2');">Print this table</a>
            </div>
          </div>
    </div>
  
<textarea id="printing-css" style="display:none;">html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}body{line-height:1}ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:before,blockquote:after,q:before,q:after{content:'';content:none}table{border-collapse:collapse;border-spacing:0}body{font:normal normal .8125em/1.4 Arial,Sans-Serif;background-color:white;color:#333}strong,b{font-weight:bold}cite,em,i{font-style:italic}a{text-decoration:none}a:hover{text-decoration:underline}a img{border:none}abbr,acronym{border-bottom:1px dotted;cursor:help}sup,sub{vertical-align:baseline;position:relative;top:-.4em;font-size:86%}sub{top:.4em}small{font-size:86%}kbd{font-size:80%;border:1px solid #999;padding:2px 5px;border-bottom-width:2px;border-radius:3px}mark{background-color:#ffce00;color:black}p,blockquote,pre,table,figure,hr,form,ol,ul,dl{margin:1.5em 0}hr{height:1px;border:none;background-color:#666}h1,h2,h3,h4,h5,h6{font-weight:bold;line-height:normal;margin:1.5em 0 0}h1{font-size:200%}h2{font-size:180%}h3{font-size:160%}h4{font-size:140%}h5{font-size:120%}h6{font-size:100%}ol,ul,dl{margin-left:3em}ol{list-style:decimal outside}ul{list-style:disc outside}li{margin:.5em 0}dt{font-weight:bold}dd{margin:0 0 .5em 2em}input,button,select,textarea{font:inherit;font-size:100%;line-height:normal;vertical-align:baseline}textarea{display:block;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box}pre,code{font-family:"Courier New",Courier,Monospace;color:inherit}pre{white-space:pre;word-wrap:normal;overflow:auto}blockquote{margin-left:2em;margin-right:2em;border-left:4px solid #ccc;padding-left:1em;font-style:italic}table[border="1"] th,table[border="1"] td,table[border="1"] caption{border:1px solid;padding:.5em 1em;text-align:left;vertical-align:top}th{font-weight:bold}table[border="1"] caption{border:none;font-style:italic}.no-print{display:none}</textarea>
<iframe id="printing-frame" name="print_frame" src="about:blank" style="display:none;"></iframe>
@endsection
