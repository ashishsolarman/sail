@extends('layouts.admin_app')
@section('css')
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  #txt-custom{
  display: none;
}

  </style>
  
@endsection
@section('content')
  <div class="container" style="margin-top: 1%;">
      <!-- Flash message -->
    @if (Session()->has('success'))
      <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button>
          <strong>{{ Session()->get('success') }}</strong>
   
      </div>
      <br>
    @endif
  <div class="container" style="margin-top: 1%;">
    <div class="row justify-content-center">
        <div class="col-md-10">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Update Owner details</div>
              <form action="{{route('edit_tenant_details',$tenant_details->id)}}" method="post" enctype="multipart/form-data" id="saleForm">
                @csrf
                @method('PUT')
          <div class="form-row" style="margin-top:3%;">
                <div class="form-group col-md-6">
              <label for="owner_name">Tenant Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="tenant_name" id="tenant_name" value="{{$tenant_details->tenant_name}}">
              @error('owner_name')
              <span style="color:red;">{{$message}}</span>
              @enderror
             </div>
                <div class="form-group col-md-6">
              <label for="owner_name">Owner Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="owner_name" id="owner_name" value="{{$tenant_details->owner_name}}">
              @error('owner_name')
              <span style="color:red;">{{$message}}</span>
              @enderror
             </div>

         <div class="form-group col-md-6">
              <label for="serial_no">Phone Number<span class="text-danger">*</span></label>
              <input type="number" class="form-control" min="0" oninput="this.value = Math.abs(this.value)" name="mobile" id="mobile" value="{{$tenant_details->mobile}}">
              @error('mobile')
              <span style="color:red;">{{$message}}</span>
              @enderror
             </div>

               <div class="form-group col-md-4">
              <label for="status">Block<span class="text-danger">*</span></label>
              <select style="height:48px;" class="custom-select mr-sm-2" id="block" name="block">
                <option selected>{{$tenant_details->block}}</option>
                <option value="A">A</option>
                 <option value="B">B</option>
                 <option value="C">C</option>
                 <option value="D">D</option>
                  <option value="E">E</option>
                  <option value="F">F</option>
               
              
              </select>
                @error('block')
              <span style="color:red;">{{$message}}</span>
              @enderror
            </div>
             <div class="form-group col-md-4">
              <label for="flat_type">Floor <span class="text-danger">*</span></label>
              <select style="height:48px;" class="custom-select mr-sm-2" id="floor" name="floor">
                <option selected>{{$tenant_details->floor}}</option>
               
                <option value="Ground Floor">Ground Floor</option>
                <option value="First Floor">First Floor</option>
                <option value="Third Floor">Third Floor</option>
                <option value="Fourth Floor">Fourth Floor</option>
                 <option value="Fifth Floor">Fifth Floor</option>

              </select>
                @error('floor')
              <span style="color:red;">{{$message}}</span>
              @enderror
            </div>
           
                 <div class="form-group col-md-4">
              <label for="serial_no">House No.<span class="text-danger">*</span></label>
              <input  type="number" min="0" oninput="this.value = Math.abs(this.value)" class="form-control"  name="house_no" id="house_no" value="{{$tenant_details->house_no}}">
                @error('house_no')
              <span style="color:red;">{{$message}}</span>
              @enderror
             </div>
           
    
              <div class="form-group col-md-6">
              <label for="serial_no">Email Address<span class="text-danger">*</span></label>
              <input type="email" class="form-control" maxlength="50" name="email" id="email" value="{{$tenant_details->email}}">
                @error('email')
              <span style="color:red;">{{$message}}</span>
              @enderror
             </div>

             <div class="form-group col-md-6">
              <label for="status">Status<span class="text-danger">*</span></label>
              <select style="height:48px;" class="custom-select mr-sm-2" id="status" name="status">
                <option selected>{{$tenant_details->status}}</option>
               
                  <option value="Active">Active</option>
                 <option value="Inactive">Inactive</option>

              </select>
                @error('status')
              <span style="color:red;">{{$message}}</span>
              @enderror
            </div>
          
           <div class="form-group col-md-6">
              <label for="city">Profession<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="profession"   name="profession" value="{{$tenant_details->profession}}">
               @error('profession')
              <span style="color:red;">{{$message}}</span>
              @enderror
            </div>

          <div class="form-group col-md-6">
              <label for="main_image">Owner Image</label><span class="text-danger">*</span>
              <input type="file" class="form-control" id="owner_image" name="owner_image" value="{{$tenant_details->owner_image}}">
            <div id="main-thumb-output"></div>
              @error('owner_image')
              <span style="color:red;">{{$message}}</span>
              @enderror
          </div>
          <div class="form-group col-md-6">
              <label for="city">Aadhar Card no.<span class="text-danger">*</span></label>
             <input type="number" min="0" oninput="this.value = Math.abs(this.value)" class="form-control" id="aadhar_no"   name="aadhar_no" value="{{$tenant_details->aadhar_no}}">
                @error('aadhar_no')
              <span style="color:red;">{{$message}}</span>
              @enderror
            </div>
          <div class="form-group col-md-6">
              <label for="image">upload your aadhar</label><span class="text-danger">*</span>
              <input type="file" class="form-control" id="aadhar_image" name="aadhar_image" value="{{$tenant_details->aadhar_image}}">
            <div id="thumb-output"></div>
              @error('aadhar_image')
              <span style="color:red;">{{$message}}</span>
              @enderror
          </div>




          <div class="row show_item" style="margin-left:1.5%;">
        <div class="row">
          @php $hobbies = json_decode($tenant_details->vehicle_type)@endphp
            <div class="form-group col-md-5">
              <label for="status">Vehicle Type<span class="text-danger">*</span></label>
               @foreach($hobbies as $hobby)
              <select class="custom-select mr-sm-2 " id="vehicle_type" name="vehicle_type[]" style="height:48px;margin-bottom: 20px;">
                <option selected>{{$hobby}}</option>
               
                  <option value="Two Wheeler">Two Wheeler</option>
                 <option value="Three Wheeler">Three Wheeler</option>
                 <option value="Four Wheeler">Four Wheeler</option>
                
              
              </select>
              @endforeach
                @error('vehicle_type')
              <span style="color:red;">{{$message}}</span>
              @enderror
            </div>
          
             @php $hobbies = json_decode($tenant_details->vehicle_name)@endphp
             
               <div class="form-group col-md-3">
              <label for="city">Vehicle Name<span class="text-danger">*</span></label>
              @foreach($hobbies as $hobby)
             <input type="text"  class="form-control" id="vehicle_name" name="vehicle_name[]" value="{{$hobby}}"><br>
                  @endforeach
                @error('vehicle_name')
              <span style="color:red;">{{$message}}</span>
              @enderror
            </div>
       


         @php $hobbies = json_decode($tenant_details->vehicle_number)@endphp
         
          <div class="form-group col-md-3">
          <label for="city">Vehicle Number<span class="text-danger">*</span></label>
          @foreach($hobbies as $hobby)
          <input type="text"  class="form-control" id="vehicle_number" name="vehicle_number[]" value="{{$hobby}}"><br>
          @endforeach
            </div>

              <div class="form-group col-md-1">
                <label for="status" type="hidden"><span class="text-danger"></span></label>
              <a class="btn btn-info add_item_btn">  <i class=" typcn typcn-plus btn-icon-append"></i></a>
            </div>
          
          </div>
            </div>

      

       </div>
      

           </div>

          
          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-success">Update</button>
            </div>
        </form>
            </div>
        </div>
    </div>
</div>
@endsection
@push('scripts')
 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/js/jquery.min.js"></script>
<script>
    $(document).ready(function(){
      $(".add_item_btn").click(function(e){
      e.preventDefault();
      $(".show_item").prepend(`<div class="row">
            <div class="form-group col-md-5">
              <label for="status">Vehicle Type<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2" id="status" name="vehicle_type[]" required>
                 <option ></option>
               
                  <option value="Two Wheeler">Two Wheeler</option>
                 <option value="Three Wheeler">Three Wheeler</option>
                 <option value="Four Wheeler">Four Wheeler</option>
              
              </select>
             
            </div>
          
          
               <div class="form-group col-md-3">
              <label for="city">Vehicle Name<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="vehicle_name[]" required>
               
            </div>
            <div class="form-group col-md-3">
              <label for="city">Vehicle Number<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="vehicle_number[]" required>
             
            </div>

         <div class="form-group col-md-1">
                <label for="status" type="hidden"><span class="text-danger"></span></label>
              <a class="btn btn-danger remove_item_btn">  <i class=" typcn typcn-minus btn-icon-append"></i></a>
            </div>
       </div>`);
      });
      $(document).on('click','.remove_item_btn',function(e){
       let row_item = $(this).parent().parent();
       $(row_item).remove();
      });
    });
  </script>
@endpush
