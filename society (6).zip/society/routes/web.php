<?php
use Illuminate\Support\Facades\Route;

 use App\Http\Controllers\Auth\Request;

     use App\Http\Controllers\UserController;
     use App\Http\Controllers\Owner\OwnerController;
      use App\Http\Controllers\Tenant\TenantController;
      use App\Http\Controllers\Collection\CollectionController;
      use App\Http\Controllers\Allowance\AllowanceController;
      use App\Http\Controllers\Auth\LoginController;
      use App\Http\Controllers\Visitor\VisitorController;
       use App\Http\Controllers\Vendor\VendorController;


Route::get('/', function () {
    return view('auth.login');
});


Route::get('project', function () {
    return view('user.project');
});


// Route::get('details', function () {
//     return view('user.details');
// });
Session::flash('message','User Just Logout');
Session::flash('alert','alert-danger');

Auth::routes();
Route::get('/logout',[LoginController::class,'logout'])->name('logout');

Route::get('/admin_home', [App\Http\Controllers\HomeController::class, 'index'])->name('admin_home');

// Auth
Route::get('/profile',[UserController::class,'profile'])->name('profile');
// owner

Route::get('/add_owner',[OwnerController::class,'owner'])->name('owner');
Route::post('/add_owner',[OwnerController::class,'store_owner'])->name('store_owner');

Route::get('/owner_view',[OwnerController::class,'owner_view'])->name('owner_view');
Route::get('/owner_profile_view/{prodID}',[OwnerController::class,'owner_profile_view'])->name('owner_profile_view');

Route::get('/delete_details/{id}',[OwnerController::class,'delete_details'])->name('delete_details');

Route::get('/edit_owner_details/{editID}',[OwnerController::class,'edit_owner_details'])->name('edit_owner_details');
Route::put('/edit_owner_details/{id}',[OwnerController::class,'update_owner_details'])->name('edit_owner_details');

Route::get('/add_tenant',[TenantController::class,'tenant'])->name('tenant');
Route::post('/add_tenant',[TenantController::class,'store_tenant'])->name('store_tenant');
Route::get('/tenant_view',[TenantController::class,'tenant_view'])->name('tenant_view');
Route::get('/edit_tenant_details/{id}',[TenantController::class,'edit_tenant_details'])->name('edit_tenant_details');
Route::get('/tenant_profile_view/{prodID}',[TenantController::class,'tenant_profile_view'])->name('tenant_profile_view');
Route::get('/delete_tenant_details/{id}',[TenantController::class,'delete_tenant_details'])->name('delete_tenant_details');

Route::put('/edit_tenant_details/{id}',[TenantController::class,'update_tenant_details'])->name('edit_tenant_details');
Route::get('/collection_master',[CollectionController::class,'collection'])->name('collection_master');
Route::get('/collection_list',[CollectionController::class,'collection_list'])->name('collection_list');
Route::get('/collection_search',[CollectionController::class,'collection_search'])->name('collection_search');
Route::post('/collection_search',[CollectionController::class,'search_mobile'])->name('collection_search');
Route::post('/payment_collect',[CollectionController::class,'store_payment'])->name('payment_collect');

Route::get('/payment_slip',[CollectionController::class,'payment_slip'])->name('payment_slip');
Route::get('/visit_master',[AllowanceController::class,'visit_master'])->name('visit_master');
Route::post('/visit_master', [AllowanceController::class, 'visitor_search'])->name('visitor_search');

Route::get('/gate_pass_form',[AllowanceController::class,'gate_pass_form'])->name('gate_pass_form');
Route::post('/gate_pass_form',[AllowanceController::class,'store_visitor_details'])->name('store_visitor_details');
Route::get('/view_visitors',[AllowanceController::class,'view_visitors'])->name('view_visitors');

Route::get('/delete_visitors/{id}',[AllowanceController::class,'delete_visitors'])->name('delete_visitors');
Route::get('/visitor_profile/{id}',[AllowanceController::class,'visitor_profile'])->name('visitor_profile');
Route::get('/edit_visitor_detail/{editID}',[AllowanceController::class,'edit_visitor_detail'])->name('edit_visitor_detail');
Route::put('/edit_visitor_detail/{editID}',[AllowanceController::class,'update_visitor_detail'])->name('update_visitor_detail');

Route::get('/search',[AllowanceController::class,'search'])->name('search');
Route::get('/searchbymobile_no',[AllowanceController::class,'searchbymobile_no'])->name('searchbymobile_no');
Route::get('/searchbydate',[AllowanceController::class,'searchbydate'])->name('searchbydate');

Route::get('/search_name',[OwnerController::class,'search_name'])->name('search_name');
Route::get('/searchbymobile',[OwnerController::class,'searchbymobile'])->name('searchbymobile');
Route::get('/search_address',[OwnerController::class,'search_address'])->name('search_address');


Route::get('/collection_history/{prodID}',[CollectionController::class,'collection_history'])->name('collection_history');

Route::get('vendor_master',[VendorController::class,'vendor'])->name('vendor_master');
Route::post('vendor_master',[VendorController::class,'store'])->name('vendor_master');
Route::get('view_vendor',[VendorController::class,'view_vendor'])->name('view_vendor');
Route::get('delete_vendor/{id}',[VendorController::class,'destroy'])->name('delete_vendor');
Route::get('/vendor_profile/{PRO}',[VendorController::class,'vendor_profile'])->name('vendor_profile');
Route::get('/edit_vendor/{editID}',[VendorController::class,'edit_visitor_detail'])->name('edit_vendor');

Route::get('vendor_search',[VendorController::class,'vendor_search'])->name('vendor_search');
Route::post('vendor_search',[VendorController::class,'searchbymobile'])->name('vendor_search');

Route::get('vendor_history/{vendor_id}',[VendorController::class,'vendor_history'])->name('vendor_history');
Route::get('visitor_history/{visitor_id}',[AllowanceController::class,'visitor_history'])->name('visitor_history');

Route::get('basic_email',[CollectionController::class,'basic_email'])->name('basic_email');
Route::get('residence_search',[OwnerController::class,'residence_search'])->name('residence_search');

Route::get('/searchbyname',[VendorController::class,'searchbyname'])->name('searchbyname');
Route::get('/search_mobile',[VendorController::class,'search_mobile'])->name('search_mobile');
Route::get('/searchbyaddress',[VendorController::class,'searchbyaddress'])->name('searchbyaddress');

