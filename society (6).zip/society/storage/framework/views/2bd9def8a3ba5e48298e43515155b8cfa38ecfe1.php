
<?php $__env->startSection('content'); ?>

<!-- buy-banner -->
<section class="buy-header d-flex flex-column align-items-center justify-content-center">
  <div class="text-center heading">
    <h1>Sale</h1>
    </div>
</section>
<!--buy-banner -->

<!--buy-content -->
<div class="container list">
  <div class="row internal">
          <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card-wrapper col-lg-4 col-md-6 col-sm-12">
      
      <div class="card-main">
        <a href="details/<?php echo e($value['id']); ?>">
          <div class="card-img-wrapper">
          <img class="card-img-top" src="<?php echo e($value->main_image); ?>" alt="project cap">
          <div class="for-sale">
          <p><?php echo e($value->status); ?></p>        
          </div>
        </div>
      </a>
        <div class="listing">
          <h5 class="title"><?php echo e($value->project_name); ?></h5>
          <p class="card-text" style="text-align: center; padding: 10px; "><?php echo e($value->city); ?></p>
          <p class="card-text" style="text-align: center; padding: 10px; border-bottom: 1px solid #bbb;"><b><?php echo e($value->flat_type); ?></b></p>


          <div class="row" style="padding: 5px;">
          <div class="col-md-6"><p class="card-text">  Price : <i class="fa fa-inr" aria-hidden="true"></i> <?php echo e($value->price); ?></p></div>
          <div class="col-md-6"><p class="card-text"> <i class="fa fa-check" aria-hidden="true"></i> Status : <?php echo e($value->status); ?></p></div>
          </div>
          <p style="margin: 0px; font-size: 14px; margin-bottom: 10px;"><i class="fa fa-building" aria-hidden="true"></i> <?php echo e($value->short_description); ?></p>
          <div class="mybtn text-center"><a href="details/<?php echo e($value['id']); ?>">See Details</a> </div>                          
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <!-- <div class="card-wrapper col-lg-4 col-md-6 col-sm-12">
      <div class="card-main">
        <div class="card-img-wrapper">
          <img class="card-img-top" src="<?php echo e(asset('img/list2.jpg')); ?>" alt="project cap">
        </div>
        <div class="listing">
          <h5 class="title">DLF Park Place</h5>
          <p class="card-text" style="text-align: center; padding: 10px; border-bottom: 1px solid #bbb;"><b>3 BHK / 4 BHK Apartment</b></p>

          <div class="row" style="padding: 5px;">
          <div class="col-md-6"><p class="card-text">  Price : <i class="fa fa-inr" aria-hidden="true"></i> 38 Lac</p></div>
          <div class="col-md-6"><p class="card-text"> <i class="fa fa-check" aria-hidden="true"></i> Status : Rent / Sell</p></div>
          </div>
          <p style="margin: 0px; font-size: 14px; margin-bottom: 10px;"><i class="fa fa-building" aria-hidden="true"></i> DLF Park Place Golf Course Road, Gurgaon</p>
          <div class="mybtn text-center"><a href="<?php echo e(url('details')); ?>"  class="text-center">See Details</a> </div>                          
        </div>
      </div>
    </div>


    <div class="card-wrapper col-lg-4 col-md-6 col-sm-12">
      <div class="card-main">
        <div class="card-img-wrapper">
          <img class="card-img-top" src="<?php echo e(asset('img/list3.jpg')); ?>" alt="project cap">
        </div>
        <div class="listing">
          <h5 class="title">DLF Park Place</h5>
          <p class="card-text" style="text-align: center; padding: 10px; border-bottom: 1px solid #bbb;"><b>3 BHK / 4 BHK Apartment</b></p>

          <div class="row" style="padding: 5px;">
          <div class="col-md-6"><p class="card-text">  Price : <i class="fa fa-inr" aria-hidden="true"></i> 38 Lac</p></div>
          <div class="col-md-6"><p class="card-text"> <i class="fa fa-check" aria-hidden="true"></i> Status : Rent / Sell</p></div>
          </div>
          <p style="margin: 0px; font-size: 14px; margin-bottom: 10px;"><i class="fa fa-building" aria-hidden="true"></i> DLF Park Place Golf Course Road, Gurgaon</p>
          <div class="mybtn text-center"><a href="<?php echo e(url('details')); ?>" class="text-center">See Details</a> </div>                          
        </div>
      </div>
    </div>
  </div>
  <div class="row pt-5 inter">
    <div class="card-wrapper col-lg-4 col-md-6 col-sm-12">
      <div class="card-main">
        <div class="card-img-wrapper">
          <img class="card-img-top" src="<?php echo e(asset('img/list3.jpg')); ?>" alt="project cap">
        </div>
        <div class="listing">
          <h5 class="title">DLF Park Place</h5>
          <p class="card-text" style="text-align: center; padding: 10px; border-bottom: 1px solid #bbb;"><b>3 BHK / 4 BHK Apartment</b></p>

          <div class="row" style="padding: 5px;">
          <div class="col-md-6"><p class="card-text">  Price : <i class="fa fa-inr" aria-hidden="true"></i> 38 Lac</p></div>
          <div class="col-md-6"><p class="card-text"> <i class="fa fa-check" aria-hidden="true"></i> Status : Rent / Sell</p></div>
          </div>
          <p style="margin: 0px; font-size: 14px; margin-bottom: 10px;"><i class="fa fa-building" aria-hidden="true"></i> DLF Park Place Golf Course Road, Gurgaon</p>
          <div class="mybtn text-center"><a href="<?php echo e(url('details')); ?>" class="text-center">See Details</a> </div>                          
        </div>
      </div>
    </div>

    <div class="card-wrapper col-lg-4 col-md-6 col-sm-12">
      <div class="card-main">
        <div class="card-img-wrapper">
          <img class="card-img-top" src="<?php echo e(asset('img/list1.jpg')); ?>" alt="project cap">
        </div>
        <div class="listing">
          <h5 class="title">DLF Park Place</h5>
          <p class="card-text" style="text-align: center; padding: 10px; border-bottom: 1px solid #bbb;"><b>3 BHK / 4 BHK Apartment</b></p>

          <div class="row" style="padding: 5px;">
          <div class="col-md-6"><p class="card-text">  Price : <i class="fa fa-inr" aria-hidden="true"></i> 38 Lac</p></div>
          <div class="col-md-6"><p class="card-text"> <i class="fa fa-check" aria-hidden="true"></i> Status : Rent / Sell</p></div>
          </div>
          <p style="margin: 0px; font-size: 14px; margin-bottom: 10px;"><i class="fa fa-building" aria-hidden="true"></i> DLF Park Place Golf Course Road, Gurgaon</p>
          <div class="mybtn text-center"><a href="<?php echo e(url('details')); ?>" class="text-center">See Details</a> </div>                          
        </div>
      </div>
    </div>
    <div class="card-wrapper col-lg-4 col-md-6 col-sm-12">
      <div class="card-main">
        <div class="card-img-wrapper">
          <img class="card-img-top" src="<?php echo e(asset('img/list2.jpg')); ?>" alt="project cap">
        </div>
        <div class="listing">
          <h5 class="title">DLF Park Place</h5>
          <p class="card-text" style="text-align: center; padding: 10px; border-bottom: 1px solid #bbb;"><b>3 BHK / 4 BHK Apartment</b></p>

          <div class="row" style="padding: 5px;">
          <div class="col-md-6"><p class="card-text">  Price : <i class="fa fa-inr" aria-hidden="true"></i> 38 Lac</p></div>
          <div class="col-md-6"><p class="card-text"> <i class="fa fa-check" aria-hidden="true"></i> Status : Rent / Sell</p></div>
          </div>
          <p style="margin: 0px; font-size: 14px; margin-bottom: 10px;"><i class="fa fa-building" aria-hidden="true"></i> DLF Park Place Golf Course Road, Gurgaon</p>
          <div class="mybtn text-center"><a href="<?php echo e(url('details')); ?>" class="text-center">See Details</a> </div>                          
        </div>
      </div>
    </div> -->   
  </div>
</div>

<!--buy-content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/user/sale.blade.php ENDPATH**/ ?>