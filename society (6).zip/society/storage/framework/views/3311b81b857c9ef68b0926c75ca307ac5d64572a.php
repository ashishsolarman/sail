
<?php $__env->startSection('content'); ?>
	<div class="container" >
		<?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
		<div class="row justify-content-center">
	        <div class="col-md-12">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Owner List </div>
       
	           <div class="row">
            <div class="col-md-12">
               <div class="row">
              <div class="col-md-4">
               <form class="example" type="get" action="<?php echo e(route('search_name')); ?>">
               <label for="project_name"><?php echo e(_('SEARCH BY NAME')); ?><span class="text-danger">*</span></label>
                <input type="search" class="form-control" placeholder="Search.." name="name">
                <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                  </form>
                  </div>
                <div class="col-md-4">
                <form class="example" type="get" action="<?php echo e(url('searchbymobile')); ?>">
                <label for="project_name"><?php echo e(_('SEARCH BY MOBILE')); ?><span class="text-danger">*</span></label>
                 <input type="number" class="form-control"  placeholder="Search.." name="mobile">
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div>
                    <div class="col-md-4">
                <form class="example" type="get" action="<?php echo e(url('search_address')); ?>">
                <label for="project_name"><?php echo e(_('SEARCH BY Address')); ?><span class="text-danger">*</span></label>
                 <input type="text" class="form-control" placeholder="Search.." name="address" >
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div> 
                  </div>
              <div class="card">
                <div class="table-responsive pt-3">
                  <table class="table table-striped project-orders-table">
                    <thead>
                      <tr>
                        <th class="ml-5">ID</th>
                        <th>Residence</th>
                        <th>Owner name</th>
                         <th>Phone Number</th>
                        <th>Address</th>
                        <th>Email</th>
                        <th>Status</th>
                     
                        <th style="text-align: center;">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if(count($owner_details) > 0): ?>
                      <?php $__currentLoopData = $owner_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->owner_tenant); ?></td>
                        <td><?php echo e($item->owner_name); ?></td>
                        <td><?php echo e($item->mobile); ?></td>
                        <td><?php echo e($item->block); ?>-<?php echo e($item->house_no); ?>,<?php echo e($item->floor); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        
                        <td>
                          <?php if($item->status == "Active"): ?>
                          <div class="col">
                          <label class="badge badge-success">Active</label>                     
                         </div>
                         <?php else: ?>
                        <div class="col">
                        <label class="badge badge-danger">Inactive</label>                     
                        </div>
                        <?php endif; ?>
                      </td>
                    
                        <td>

                          <div class="d-flex align-items-center">
                             <?php $prodID= Crypt::encrypt($item->id); ?> 
                          	 <a href="owner_profile_view/<?php echo e($prodID); ?>" type="button" class="btn btn-info btn-sm btn-icon-text mr-3">
                              View
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>                     
                            </a>
                            <?php $editID = Crypt::encrypt($item->id) ?>
                            <a href="edit_owner_details/<?php echo e($editID); ?>" type="button" class="btn btn-success btn-sm btn-icon-text mr-3">
                              Edit
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                            </a>
                            <a href="delete_details/<?php echo e($item->id); ?>" class="btn btn-danger btn-sm btn-icon-text">
                              Delete
                              <i class="typcn typcn-delete-outline btn-icon-append"></i>                          
                            </a>
                          </div>
                        </td>
                      </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php else: ?><th>No Data Available</th>
                 
                    </tbody>
                 
                 <?php endif; ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
     				<!--  pagination  -->
			
	        </div>
	    </div>
    </div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/owner/residence_search.blade.php ENDPATH**/ ?>