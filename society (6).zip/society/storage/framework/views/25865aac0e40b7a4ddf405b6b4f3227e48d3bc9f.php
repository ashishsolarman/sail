
<?php $__env->startSection('content'); ?>
  <!---banner -->
<section class="see-main d-flex flex-column align-items-center justify-content-center">
  <div class="text-center heading">
    <h1>Contact Us</h1>
  </div>
</section>
<!---banner -->


<!--CONTACT DETAILS-->
<div class="container main-contact">
  <div class="row">
    <div class="col-lg-8 col-md-12 contact">
      <h3 class="mb-3">Contact Us</h3>
        <form id="contactform" class="contact-form" name="contactform" method="post" novalidate="novalidate">
          <div class="form-group">
            <input type="text" required="" class="form-control input-custom input-full" name="name" placeholder="First Name" aria-required="true">
            </div>

<div class="form-group">
  <input type="text" required="" class="form-control input-custom input-full" name="lastname" placeholder="Last Name" aria-required="true">
</div>

<div class="form-group">
  <input type="text" class="form-control input-custom input-full" name="email" placeholder="Email">
</div>

<div class="form-group">
  <textarea class="form-control textarea-custom input-full" id="ccomment" name="message" required="" rows="8" placeholder="Message" aria-required="true"></textarea>
</div>

<div class="sub"><a href="#">Submit</a></div>
</form>
</div>

<div class="col-lg-4 col-md-12 bgc">
  <div class="call-info">
    <h3>Contact Details</h3>
      <p class="mb-4 text-white">Please find below contact details and contact us today!</p>
        <ul>
          <li>
            <div class="info">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
            <p class="in-p">ED-117, Tagore Garden, New Delhi & B3, Shopping Center, Tagore Garden</p>
          </div>
        </li>
<li>
  <div class="info">
    <i class="fa fa-phone" aria-hidden="true"></i>
      <p class="in-p"><a href="tel:9810365066"> +91-9810365066</a>,<a href="tel:9810053025"> +91-9810053025</a></p>
    </div>
</li>

<li>
  <div class="info">
    <i class="fa fa-envelope" aria-hidden="true"></i>
      <p class="in-p ti"><a href="mailto:info@nagpalproperties.co.in"> info@nagpalproperties.co.in</a></p>
</div>
</li>

<li>
  <div class="info cll">
    <i class="fa fa-clock-o" aria-hidden="true"></i>
      <p class="in-p ti">9:00 a.m - 8:30 p.m</p>
    </div>
  </li>
</ul>
</div>
</div>
</div>
</div>
<!--CONTACT DETAILS-->


<!--Our Location-->
<div class="container location">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12 map">
      <h2>OUR LOCATION</h2>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1750.6733057273152!2d77.1128353501059!3d28.649338623980558!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d03701844465d%3A0x87fe9861f5516783!2sNagpal%20Properties!5e0!3m2!1sen!2sin!4v1654072762700!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-12 map">
      <h2>OUR LOCATION</h2>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1750.6733057273152!2d77.1128353501059!3d28.649338623980558!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d03701844465d%3A0x87fe9861f5516783!2sNagpal%20Properties!5e0!3m2!1sen!2sin!4v1654072762700!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </div>
</div>
<!--Our Location-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/contact_us.blade.php ENDPATH**/ ?>