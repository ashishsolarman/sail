
<?php $__env->startSection('content'); ?>

<!---banner -->
<section class="see-main d-flex flex-column align-items-center justify-content-center">
	<div class="text-center heading">
	<h1><?php echo e($sale->flat_type); ?> APARTMENT</h1>
	</div>
</section>
	<!---banner -->

	<!-- slider-start -->
	<div class="container">
		<div class="row">
			<h6 class="heading-main"><?php echo e($sale->flat_type); ?> APARTMENT</h6>
			<div class="col-lg-8 col-md-8 col-sm-12">
				<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
					<div class="carousel-inner">
						<div class="carousel-item active">
							<img src="<?php echo e(asset('img/bg1.jpg')); ?>" class="d-block w-100" alt="...">
						</div>
						<div class="carousel-item">
							<img src="<?php echo e(asset('img/bg1.jpg')); ?>" class="d-block w-100" alt="...">
						</div>
						<div class="carousel-item">
							<img src="<?php echo e(asset('img/bg1.jpg')); ?>" class="d-block w-100" alt="...">
						</div>
					</div>
					<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="visually-hidden">Previous</span>
					</button>
					<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="visually-hidden">Next</span>
					</button>
				</div>
			</div>

	<!-- slider-end -->

	<!-- form-start -->
			<div class="col-lg-4 col-md-4 col-sm-12 enquiry">
				<form>
					<div class="mb-1 mt-1">
						<label for="email" class="form-label">Email</label>
						<input type="email" class="form-control" id="email" name="email">
					</div>
					<div class="mb-1">
						<label for="tel" class="form-label">Phone</label>
						<input type="tel" class="form-control" id="tel" name="tel">
					</div>
					<label for="comment">Message</label>
					<textarea class="form-control" rows="5" id="comment" name="text"></textarea>
	  				<div class="form-btn"><a href="#" >Enquiry Now</a></div>
				</form>
			</div>
		</div>
	</div>
	<!-- form-end -->

	<!--tabs -->
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 main-tab">
				<!-- Tab links -->
				<div class="tab">
				  <button class="tablinks" onclick="openCity(event, 'overview')" id="defaultOpen">OVERVIEW</button>
				  <button class="tablinks" onclick="openCity(event, 'about')">ABOUT</button>
				  <button class="tablinks" onclick="openCity(event, 'floor')">FLOOR PLAN</button>
				  <button class="tablinks" onclick="openCity(event, 'amenities')">AMENITIES</button>
				</div>

				<div id="overview" class="tabcontent">
					<h3 class="tab-heading">Overview</h3>
					<p>Nagpal Properties is a network of professionals who know and understand that their 
					business is about more than just real estate and construction. It’s about people. People 
					whose homes are the central plank upon which they will nurture families, build wealth, and 
					find sanctuary. nagpal properties is a network of professionals who know and understand that their 
					business is about more than just real estate and construction. It’s about people. People 
					whose homes are the central plank upon which they will nurture families, build wealth, and 
					find sanctuary.</p>
				</div>

				<div id="about" class="tabcontent">
					<h3 class="tab-heading">About</h3>
					<p>Nagpal Properties is a network of professionals who know and understand that their 
					business is about more than just real estate and construction. It’s about people. People 
					whose homes are the central plank upon which they will nurture families, build wealth, and 
					find sanctuary. nagpal properties is a network of professionals who know and understand that their 
					business is about more than just real estate and construction. It’s about people. People 
					whose homes are the central plank upon which they will nurture families, build wealth, and 
					find sanctuary.</p> 
				</div>

				<div id="floor" class="tabcontent">
					<h3 class="tab-heading">Floor Plan</h3>
					<table id="customers">
						<tr>
						    <th>BHK</th>
						    <th>Type</th>
						    <th>Super Area</th>
						    <th>Carpet Area</th>
						    <th>Balcony / Terrace</th>
						    <th>Price</th>
						</tr>
						<tr>
						    <td>3 BHK</td>
						    <td>Ft. Flat</td>
						    <td>2341 Sqft.</td>
						    <td>N/A</td>
						    <td>N/A</td>
						    <td>2.22 Cr</td>
						</tr>
						<tr>
						    <td>3 BHK</td>
						    <td>Ft. Flat</td>
						    <td>2341 Sqft.</td>
						    <td>N/A</td>
						    <td>N/A</td>
						    <td>2.22 Cr</td>
						</tr>
						<tr>
						    <td>3 BHK</td>
						    <td>Ft. Flat</td>
						    <td>2341 Sqft.</td>
						    <td>N/A</td>
						    <td>N/A</td>
						    <td>2.22 Cr</td>
						</tr>
						<tr>
						    <td>3 BHK</td>
						    <td>Ft. Flat</td>
						    <td>2341 Sqft.</td>
						    <td>N/A</td>
						    <td>N/A</td>
						    <td>2.22 Cr</td>
						</tr>
						<tr>
						    <td>3 BHK</td>
						    <td>Ft. Flat</td>
						    <td>2341 Sqft.</td>
						    <td>N/A</td>
						    <td>N/A</td>
						    <td>2.22 Cr</td>
						</tr>
					</table>
				</div>

				<div id="amenities" class="tabcontent">
					<h3 class="tab-heading">Amenities</h3>
					<p>Nagpal Properties is a network of professionals who know and understand that their 
					business is about more than just real estate and construction. It’s about people. People 
					whose homes are the central plank upon which they will nurture families, build wealth, and 
					find sanctuary. nagpal properties is a network of professionals who know and understand that their 
					business is about more than just real estate and construction. It’s about people. People 
					whose homes are the central plank upon which they will nurture families, build wealth, and 
					find sanctuary.</p>	

					<div class="amenities">
						<h4>SPORTS</h4>
						<p><i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Gymnasium
						<i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Swimming Pool
						<i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Yoga Areas</p>


						<h4>CONVENIENCE</h4>
						<p><i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Power Backup
						<i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Attached Market
						<i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Pre-School
						<i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Medical Facility</p>

						<h4>SAFETY</h4>
						<p><i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Party Hall
						<i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Clubhouse</p>

						<h4>ENVIORNMENT</h4>
						<p><i class="fa fa-check-circle" aria-hidden="true" style="color: #16a9b5;"></i> Normal Park / Central Green</p>		

						<div class="box-main">
							<div class="box text-center">
								<i class="fa fa-shield" aria-hidden="true"></i><br>
								<span>24 Hours Security</span>
							</div>

							<div class="box text-center">
								<i class="fa fa-shield" aria-hidden="true"></i><br>
								<span>Gym</span>
							</div>

							<div class="box text-center">
								<i class="fa fa-shield" aria-hidden="true"></i><br>
								<span>Intercom</span>
							</div>

							<div class="box text-center">
								<i class="fa fa-shield" aria-hidden="true"></i><br>
								<span>Kid's Play Area</span>
							</div>

							<div class="box text-center">
								<i class="fa fa-shield" aria-hidden="true"></i><br>
								<span>Lift</span>
							</div>

							<div class="box text-center">
								<i class="fa fa-plug" aria-hidden="true"></i><br>
								<span>Power Backup</span>
							</div>

							<div class="box text-center">
								<i class="fa fa-shield" aria-hidden="true"></i><br>
								<span>2 Swimming Pool</span>
							</div>

							<div class="box text-center">
								<i class="fa fa-shield" aria-hidden="true"></i><br>
								<span>Jogging Track</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--tabs -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  	<script>
	    $(document).ready(function() {
	      	$('.brand-carousel').owlCarousel({
		        loop:true,
		        margin:10,
		        autoplay:true,
		        responsive:{
		          0:{
		            items:1
		          },
		          600:{
		            items:3
		          },
		          1000:{
		            items:5
		          }
		        }
	      	});
	    });

	    function openCity(evt, cityName) {
		  var i, tabcontent, tablinks;
		  tabcontent = document.getElementsByClassName("tabcontent");
		  for (i = 0; i < tabcontent.length; i++) 
		  {
		    tabcontent[i].style.display = "none";
		  }
		  tablinks = document.getElementsByClassName("tablinks");
		  for (i = 0; i < tablinks.length; i++) {
		    tablinks[i].className = tablinks[i].className.replace(" active", "");
		  }
		  document.getElementById(cityName).style.display = "block";
		  evt.currentTarget.className += " active";
		}

		// Get the element with id="defaultOpen" and click on it
			document.getElementById("defaultOpen").click();
  	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/user//details.blade.php ENDPATH**/ ?>