<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\nagpal_property\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>