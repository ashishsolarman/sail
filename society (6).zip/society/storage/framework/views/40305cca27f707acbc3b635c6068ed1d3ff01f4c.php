<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('img/fav.png')); ?>" type="image/x-icon">
   <title>Finance Department</title>

     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
   
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
       

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="app.css">
    <link href="<?php echo e(asset('side_navbar/css/style.css')); ?>" rel="stylesheet">





    <style>
        .sub_menu{
            display: none;
        }

        .accordion-item p {
    margin: 10px 0;
}

        .accordion-item p a {
    color: #fff;
    font-size: 16px;
}

.accordion-item {
    background-color: transparent;
    border: 1px solid rgba(0, 0, 0, 0.125);
}

.accordion-button{
    background: transparent;
    color: #fff;
    padding: 5px 0px;
}
.accordion-button:not(.collapsed) {
    color: #0c63e4;
    background-color: transparent;
    box-shadow: inset 0 -1px 0 rgb(0 0 0 / 13%);
}

.accordion-button::after{
    content: '\f107';
    font-family: 'FontAwesome';
    /* margin-right: 10px; */
    font-size: 25px;
    /* font-weight: 800; */
    margin-top: -15px;
    color: #fff;
    background-image: none;
}

.accordion-button:not(.collapsed)::after{
    background-image: none;
}

    </style>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(url('admin_home')); ?>" style="width:15%;">
                    <img src="<?php echo e(asset('img/finance-logo.jpg')); ?>" alt="Logo" style="width:100%;">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                            
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle fa fa-user mr-3" style="font-size: x-large;" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                                                  </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                 
                                    <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">
                                       <i class="fa fa-user-circle-o" aria-hidden="true"></i>  <?php echo e(__('My Profile')); ?>

                                    </a>
                                  
                                     <?php if(Auth::user()->role == "admin"): ?>
                                      <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                        <i class="fa fa-pencil" aria-hidden="true"></i>  <?php echo e(__('Edit Profile')); ?>

                                    </a>
                                    <?php endif; ?>
                                        <?php if(Auth::user()->role == "admin"): ?>
                                     <a class="dropdown-item" href="<?php echo e(route('reset')); ?>">
                                        <i class="fa fa-cog" aria-hidden="true"></i>  <?php echo e(__('Change Password')); ?>

                                    </a>
                                    <?php endif; ?>
                                        <?php if(Auth::user()->role == "admin"): ?>
                                     <a class="dropdown-item" href="<?php echo e(route('users_data')); ?>">
                                        <i class="fa fa-users" aria-hidden="true"></i>  <?php echo e(__('Users')); ?>

                                    </a>
                                    <?php endif; ?>

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <i class="fa fa-power-off"></i>  <?php echo e(__('Logout')); ?>

                                    </a>


                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>


                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="wrapper d-flex align-items-stretch">
            <nav id="sidebar">
                <div class="custom-menu">
                    <button type="button" id="sidebarCollapse" class="btn btn-primary">
              <i class="fa fa-bars"></i>
              <span class="sr-only">Toggle Menu</span>
            </button>
        </div>
                <div class="p-4">
                
            <ul class="list-unstyled components mb-5">
             
    <div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    
               <p><a href="<?php echo e('admin_home'); ?>"><span class="fa fa-home mr-3"></span> Home</a></p>
            </div>

            <?php if(Auth::user()->role != "admin"): ?>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
       <p><a href="<?php echo e(route('admin_slider')); ?>"><span class="fa fa-user mr-3"></span>Menu</a></p>
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <p><a href="<?php echo e(route('top_header')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Top Header</a></p>
        <p><a href="<?php echo e(route('middle_header')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Middle Header</a></p>
        <p><a href="<?php echo e(route('main_header')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>main Header</a></p>
       
    </div>
  </div>
<?php endif; ?>

<?php if(Auth::user()->role != "admin"): ?>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo1">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo1" aria-expanded="false" aria-controls="flush-collapseTwo1">
       <p><a href="<?php echo e(route('admin_slider')); ?>"><span class="fa fa-sliders mr-3"></span>Slider</a></p>
      </button>
    </h2>
    <div id="flush-collapseTwo1" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo1" data-bs-parent="#accordionFlushExample">
      <p><a href="<?php echo e(route('main_slider')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Main Slider</a></p>
        <p><a href="<?php echo e(route('scheme_slider')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Scheme Slider</a></p>
        <p><a href="<?php echo e(route('gallery_slider')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Gallery Slider</a></p>
        <p><a href="<?php echo e(route('other_links')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Others Links</a></p>
    </div>
  </div>
<?php endif; ?>

<?php if(Auth::user()->role != "admin"): ?>
<div class="accordion-item">
    
<p><a href="<?php echo e(route('admin_minister')); ?>"><span class="fa fa-user mr-3"></span>Ministers</a></p>
</div>
<?php endif; ?>


<?php if(Auth::user()->role != "admin"): ?>
<div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo3">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo3" aria-expanded="false" aria-controls="flush-collapseTwo3">
       <p><a href="<?php echo e(route('admin_slider')); ?>"><span class="fa fa-tags  mr-3"></span>Tickers</a></p>
      </button>
    </h2>
    <div id="flush-collapseTwo3" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo3" data-bs-parent="#accordionFlushExample">
         <p><a href="<?php echo e(route('admin_ticker')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Add Ticker <i class="fa fa-plus-square" aria-hidden="true"></i></a></p>


<?php ($tickers = \App\Models\Ticker::all()); ?> 
         <?php $__currentLoopData = $tickers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><a href="<?php echo e(route('top_ticker')); ?>"><span class="fa fa-dot-circle-o mr-3"></span><?php echo e($item->ticker_name); ?></a></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <!--    <p><a href="<?php echo e(route('trending_ticker')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Trending Ticker</a></p>
        <p><a href="<?php echo e(route('release_ticker')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Press Releases Ticker</a></p>
<p><a href="<?php echo e(route('links_ticker')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Links Ticker</a></p> -->
       
    </div>
  </div>
<?php endif; ?>
              <?php if(Auth::user()->role != "admin"): ?>
            <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo4">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo4" aria-expanded="false" aria-controls="flush-collapseTwo4">
       <p><a href="<?php echo e(route('admin_slider')); ?>"><span class="fa fa-tags  mr-3"></span>Footer</a></p>
      </button>
    </h2>
    <div id="flush-collapseTwo4" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo4" data-bs-parent="#accordionFlushExample">
      <p><a href="<?php echo e(route('footer_links')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Footer Links</a></p>
        <p><a href="<?php echo e(route('copyrights')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Copy Rights</a></p>
        <p><a href="<?php echo e(route('visitors')); ?>"><span class="fa fa-dot-circle-o mr-3"></span>Visitors</a></p>
        
       
    </div>
  </div>
            <?php endif; ?>
  <div class="accordion-item">
    
               <p><a href="<?php echo e(route('admin_content')); ?>"><span class="fa fa-sliders mr-3"></span>Content</a></p>
            </div>
            <div class="accordion-item">
                  <p><a href="<?php echo e(route('important_link')); ?>"><span class="fa fa-file-text-o mr-3"></span>Important Links</a></p>
            </div>
            <div class="accordion-item">

    
               <p><a href="<?php echo e(url('admin_menu_data')); ?>"><span class="fa fa-eye mr-3"></span>View Menu</a></p>
            </div>
            <div class="accordion-item">
    
               <p><a href="<?php echo e('main_slider_view'); ?>"><span class="fa fa-sliders mr-3"></span>View Slider</a></p>
            </div>
            <div class="accordion-item">
    
               <p><a href="<?php echo e(route('admin_view_minister')); ?>"><span class="fa fa-user mr-3"></span>View Minister</a></p>
            </div>

             <div class="accordion-item">

    
               <p><a href="<?php echo e(url('admin_menu_data')); ?>"><span class="fa fa-tags mr-3"></span>View Tickers</a></p>
            </div>

             <div class="accordion-item">
    
               <p><a href="<?php echo e(url('admin_menu_data')); ?>"><span class="fa fa-user mr-3"></span>View Footer</a></p>
            </div>
</div>
               


             
            </ul>
            </div>
        </nav>
    

        <!-- <main class="py-6"> -->
            <?php echo $__env->yieldContent('content'); ?>
        <!-- </main> -->
    </div>
    </div>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('side_navbar/js/popper.js')); ?>" defer></script>
    <script src="<?php echo e(asset('side_navbar/js/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('side_navbar/js/main.js')); ?>" defer></script>
    <script>
    $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cms\resources\views/layouts/admin_app.blade.php ENDPATH**/ ?>