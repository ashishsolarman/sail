
<?php $__env->startSection('content'); ?>
<!-- hero container -->
    <section class="hero d-flex flex-column align-items-center
      justify-content-center">
      <div class="hero-overlay"></div>
      <div class="text-center central-content">
        <h1>
          Helping people finding places to call<br>
           their homes since 1964</h1>
        </div>
      </div>
    </section>
<!-- /hero container -->

<!-- Home-Page-Popup -->
<div class="modal fade popup" id="Modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Enquiry now</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
                <form id="contactform" class="contact-form" name="contactform" method="post" novalidate="novalidate">
          <div class="form-group">
            <input type="text" required="" class="form-control input-custom input-full" name="name" placeholder="First Name" aria-required="true">
            </div>

<div class="form-group">
  <input type="text" required="" class="form-control input-custom input-full" name="lastname" placeholder="Last Name" aria-required="true">
</div>

<div class="form-group">
  <input type="text" class="form-control input-custom input-full" name="email" placeholder="Email">
</div>

<div class="form-group">
  <textarea class="form-control textarea-custom input-full" id="ccomment" name="message" required="" rows="8" placeholder="Message" aria-required="true"></textarea>
</div>

<div class="sub"><a href="#">Submit</a></div>
</form>
      </div>
    </div>
  </div>
</div>
<!-- Home-Page-Popup -->


<!-- feature-section -->
    <section class="container">
      <div class="row main">
        <div class="col-12 col-md-4 pro">
          <div class="card service" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-3 text-center">
                <i class="fa fa-building" aria-hidden="true" style="font-size: 3rem;padding-top:
                  1rem;"></i>
              </div>
              <div class="col-md-9">
                <div class="card-body">
                  <h5 class="card-title">
                    Wide Range of Properties</h5>
                  <p class="card-text text-secondary">This is a wider card with
                    supporting text below as a natural lead-in to additional
                    content.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-4 pro">
          <div class="card service" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-3 text-center">

                <i class="fa fa-inr" aria-hidden="true" style="font-size:
                  3rem;padding-top: 1rem;"></i>
              </div>
              <div class="col-md-9">
                <div class="card-body">
                  <h5 class="card-title">Rent or Sale</h5>
                  <p class="card-text text-secondary">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-4 pro">
          <div class="card service" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-3 text-center">
                <i class="fa fa-location-arrow" aria-hidden="true" style="font-size:
                  3rem;padding-top: 1rem;"></i>
              </div>
              <div class="col-md-9">
                <div class="card-body">
                  <h5 class="card-title">
                    Property Location</h5>
                  <p class="card-text text-secondary">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<!-- /feature-section -->

<!-- rent -->
    <section class="offers container-fluid parallax-one">
      <div class="section-heading">
        <h2 class="text-capitalize text-center text-white">Rental Properties</h2>
        <p class="text-capitalize text-center"><a href="#"
            class="text-secondary text-white">View All 56 New Listings</a></p>
      </div>

<!-- Swiper -->
<div class="container">
  <div class="row internal">  
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <div class="card text-capitalize">
            <div class="img-container">
              <img src="<?php echo e(asset('img/Rent_IMP/R1.jpeg')); ?>" alt="">
            </div>
          <div class="details">
        <div class="visible-details">
      <div class="price">
    <div class="btn btn-card"> &#8377;1,50,000/-</div>
  </div>
<div class="name"><strong>Fully furnished 3BHK</strong></div>
  <div class="location">Greater Kailash 2</div>
    </div>
      <div class="d-flex hidden-details justify-content-between">
        <div class="home-feature-item">
          <span>area</span><br><span>-<!-- <sup>2</sup> --></span>
            </div>
              <div class="home-feature-item">
                <span>bed</span><br><span>3</span>
              </div>
            <div class="home-feature-item">
          <span>baths</span><br><span>2</span>
        </div>
      <div class="home-feature-item">
    <span>garages</span><br><span>-</span>
  </div>
</div>
</div>
</div>
</div>

          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Rent_IMP/R2.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;1,20,000/-</div>
                  </div>
                  <div class="name"> <strong>Fully furnished - 2nd floor </strong></div>
                  <div class="location">Greater Kailash - 1, South Delhi</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>300 sq yards<!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>-</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>-</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

             <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Rent_IMP/R2.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;1,20,000/-</div>
                  </div>
                  <div class="name"> <strong>Fully furnished - 2nd floor </strong></div>
                  <div class="location">Greater Kailash - 1, South Delhi</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>300 sq yards<!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>-</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>-</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/card1.jpg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;45000</div>
                  </div>
                  <div class="name"> <strong>Pure Ground Floor</strong></div>
                  <div class="location">Tagore Garden</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>200 square yards<!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>3</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>2</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

        <div class="swiper-pagination"></div>
      </div>

      <div class="col-lg-12 listing-btn">
  <a href="rent.html">View All Properties</a>

</div>
            </div>
      </div>
    </section>
     <!-- /rent -->

     <!-- Project-section -->
    <section class="offers container-fluid">
      <div class="section-heading">
        <h2 class="text-capitalize text-center">Projects</h2>
          </div>
          <div class="container">
     <div class="row mt-5">
      <div class="col-lg-4 col-md-3- col-sm-12 pro">
        <div class="content">
         <a href="project.html">
          <div class="content-overlay"></div>
            <img class="content-image" src="<?php echo e(asset('img/AMPM/g2.jpeg')); ?>">
              <div class="content-details fadeIn-bottom fadeIn-right">
        <h3>AMPM</h3>
<!--        <a href="#" class="btn btn-danger">See Details</a> -->
      </div>
    </a>
  </div>
</div>


<div class="col-lg-4 col-md-3- col-sm-12 pro">
        <div class="content">
         <a href="project.html">
          <div class="content-overlay"></div>
            <img class="content-image" src="<?php echo e(asset('img/BUFFETERIA/g2.jpeg')); ?>">
              <div class="content-details fadeIn-bottom fadeIn-right">
        <h3>BUFFETERIA</h3>
<!--        <a href="#" class="btn btn-danger">See Details</a> -->
      </div>
    </a>
  </div>
</div>


<div class="col-lg-4 col-md-3- col-sm-12 pro">
        <div class="content">
         <a href="project.html">
          <div class="content-overlay"></div>
            <img class="content-image" src="<?php echo e(asset('img/NEW_YORK/g1.jpeg')); ?>">
              <div class="content-details fadeIn-bottom fadeIn-right">
        <h3>NEW YORK</h3>
<!--        <a href="#" class="btn btn-danger">See Details</a> -->
      </div>
    </a>
  </div>
</div>
<div class="row project-btn text-center d-flex mt-5">
<div class="col-lg-12">
  <a href="project.html">View All</a>

</div>
</div>

</div>
</div>
</section>
<!-- Project-section -->

     <!-- offers-section -->
    <section class="exclusive container-fluid">
      <div class="section-heading">
        <h2 class="text-capitalize text-center">Properties Listing For Purchase</h2>
        <!-- <hr style="width: 20%;border-bottom: 2px solid #d92228;margin :1rem auto"> -->
        <p class="text-capitalize text-center"><a href="#"
            class="text-secondary">View All 44 New Listings</a></p>
      </div>

      <!-- Swiper -->
      <div class="container">
        <div class="row">

      <div class="swiper mySwiper">
        <div class="swiper-wrapper">

          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Sale_IMP/S1.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;1.10 Cr</div>
                  </div>
                  <div class="name"> <strong>Brand New 2BHK</strong></div>
                  <div class="location">Tagore Garden</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>80 sq yards <!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>2</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>-</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Sale_IMP/S2.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;2.20 Cr</div>
                  </div>
                  <div class="name"> <strong>3BHK 1st Floor With Lift </strong></div>
                  <div class="location">Rajouri Garden</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>207 sq yards<!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>3</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>2</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Sale_IMP/S3.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;5 Cr</div>
                  </div>
                  <div class="name"> <strong>Fully Premium 3BHK</strong></div>
                  <div class="location">Rajouri Garden</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>268 sq yards <!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>3</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>2</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Sale_IMP/S4.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;2.25 Cr</div>
                  </div>
                  <div class="name"> <strong>3rd & 4th Floor </strong></div>
                  <div class="location">Sushant Lok 1</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>215 sq yards <!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>3</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>3</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Sale_IMP/S5.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;2.25 Cr</div>
                  </div>
                  <div class="name"> <strong>3BHK All Floors Available </strong></div>
                  <div class="location">Sushant Lok 1</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>270 sq yards <!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>3</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>2</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="swiper-slide">

            <div class="card text-capitalize">
              <div class="img-container">
                <img src="<?php echo e(asset('img/Sale_IMP/S6.jpeg')); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;3.85 Cr</div>
                  </div>
                  <div class="name"> <strong>4BHK Upper 1st Floor </strong></div>
                  <div class="location">Kirti Nagar</div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span>300 square yards <!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span>4</span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span>3</span>
                  </div>
                  <div class="home-feature-item">
                    <span>garages</span><br><span>-</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

        <div class="swiper-pagination"></div>
      </div>
            <div class="col-lg-12 view-btn">
  <a href="sale.html">View All Properties</a>

</div>
             </div>
      </div>


    </section>
    <!-- /offers-section -->

      <!-- counting-area -->
    <section class="counting-area container-fluid count parallax-two">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-6 completed">
            <h2 class="text-capitalize text-white">the hundred of completed work still
              counting </h2>
            <p style="text-align: justify;" class="text-secondary text-white">Lorem ipsum dolor sit, amet consectetur
              adipisicing elit. Illum vitae sunt recusandae quas labore
              voluptatibus doloribus pariatur veritatis. Officiis, perferendis
              molestias. Cum quod magni neque consectetur ab nesciunt rerum
              voluptate necessitatibus porro maiores magnam, natus voluptatibus
              eligendi ducimus cumque laudantium, sed ex voluptatum saepe eius
              enim, illo quas minima tenetur?</p>
          </div>
          <div class="col-12 col-md-6 counting-area-right">
            <div class="counter-container">

              <div class="row shadow text-center">
                <div class="col-6"><div class="count-box"><h1>531</h1><span>homes
                      for sale</span></div></div>
                <div class="col-6"><div class="count-box"><h1>4</h1><span>open
                      house</span></div></div>
                <div class="col-6"><div class="count-box"><h1>1252</h1><span>recently
                      sold</span></div></div>
                <div class="col-6"><div class="count-box"><h1>2</h1><span>price
                      reduced</span></div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
     <!--/counting-area -->

     <!-- Our-partner -->
    <section class="section part">
      <div class="section-heading mb-4">
        <h2 class="text-capitalize text-center">Our Partner</h2>
          </div>
          <div class="container">
            <div class="row">

     <div class="brand-carousel section-padding owl-carousel" id="brand-carousel">
  <div class="single-logo">
    <img src="<?php echo e(asset('img/chanel.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('img/chanel1.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('img/chanel2.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('img/chanel3.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('img/chanel4.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('img/chanel5.jpg')); ?>" alt="">
  </div>
</div>
</div>
</div>
    </div>

          </div>
</section>
    <!-- Our-partner -->

     <!-- happy-customer -->
    <section class="happy-customer container-fluid">
      <div class="section-heading mb-2">
        <h2 class="text-capitalize text-center">customer testimonials</h2>
        <hr style="width: 20%;border-bottom: 2px solid #16a9b5;margin :1rem
          auto">
      </div>
      <div class="container">
      <div class="row client">
        <div class="col-12 col-md-6 thin">
          <!-- Swiper -->
          <div class="swiper mySwiper2">
            <div class="swiper-wrapper">

              <div class="swiper-slide">
                <div class="testimonial flex flex-column font-roboto pro">
                  <div class="quote-icon-container flex">
                    <div class="quote-icon">
                      <!-- <i class="fab fa-twitter"></i> -->
                      <i class="fa fa-quote-left"></i>
                    </div>
                  </div>
                  <div class="testimonial-text text-dark2">
                    <p>
                      Nagpal Properties provides a great place to stay with safe environment. if they show you something about property that is always same as it. No fake pictures.
                    </p>
                    <hr />
                    <div class="pic-name d-flex font-roboto">
                      <img
                        src="<?php echo e(asset('img/user.png')); ?>"
                        alt=""
                        />
                      <span class="name"> parinita singha </span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="testimonial flex flex-column font-roboto pro">
                  <div class="quote-icon-container flex">
                    <div class="quote-icon">
                      <!-- <i class="fab fa-twitter"></i> -->
                      <i class="fa fa-quote-left"></i>
                    </div>
                  </div>
                  <div class="testimonial-text text-dark2">
                    <p>
                      It was a nice experience with Nagpal Properties. They helped me to find a new home to stay as it was difficult for me, as an individual,to find a home with friendly roommates.Thankfully Nagpal Properties helped me to get one with all kind of facilities.
                    </p>
                    <hr />
                    <div class="pic-name d-flex font-roboto pro">
                      <img
                        src="<?php echo e(asset('img/user.png')); ?>"
                        alt=""
                        />
                      <span class="name"> Rajan Mehra </span>
                    </div>
                  </div>
                </div>
              </div>


              <div class="swiper-slide">
                <div class="testimonial flex flex-column font-roboto pro">
                  <div class="quote-icon-container flex">
                    <div class="quote-icon">
                      <!-- <i class="fab fa-twitter"></i> -->
                      <i class="fa fa-quote-left"></i>
                    </div>
                  </div>
                  <div class="testimonial-text text-dark2">
                    <p>
                     I have got a genuine and very quick response from the site. I am very happy with service of nagpalproperties.com owner plans.
                    </p>
                    <hr />
                    <div class="pic-name d-flex font-roboto pro">
                      <img
                        src="<?php echo e(asset('img/user.png')); ?>"
                        alt=""
                        />
                      <span class="name"> Deepak Katakwal</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- <div class="swiper-pagination"></div> -->
          </div>
          <!-- /swiper mySwiper -->
        </div>
        <div class="col-12 col-md-6">
          <img src="<?php echo e(asset('img/tt2.jpg')); ?>" width="100%" alt="">
        </div>
      </div>
      </div>

    </section>
 <!-- /happy-customer -->
 <?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
  <script>
    $(document).ready(function() {
      $('.brand-carousel').owlCarousel({
        loop:true,
        margin:10,
        autoplay:true,
        responsive:{
          0:{
            items:1
          },
          600:{
            items:3
          },
          1000:{
            items:5
          }
        }
      });

    var myModal = new bootstrap.Modal(document.getElementById("Modal"));
      myModal.show();  
      
    });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/first.blade.php ENDPATH**/ ?>