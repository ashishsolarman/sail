
<?php $__env->startSection('css'); ?>
	<style>
    body
    {
    	color: #000000;
    }
    label.error 
	{
    	color: #dc3545;
    	font-size: 14px;
    }

	input[type="file"] {
	  display: block;
	}
	.imageThumb {
	  max-height: 75px;
	  border: 2px solid;
	  padding: 1px;
	  cursor: pointer;
	  margin: 10px 5px 0 0;
	  width: 100px;

	}
	.pip {
	  display: inline-block;
	  margin: 10px 5px 0 0;
	}
	.remove {
	  display: block;
	  background: #444;
	  border: 1px solid black;
	  color: white;
	  text-align: center;
	  cursor: pointer;
	  width: 100px; 

	}
	.remove:hover {
	  background: white;
	  color: black;
	}

	textarea.form-control 
	{
	    min-height: calc(11.6em + 0.75rem + 2px);
	}
	</style>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
	<link href="<?php echo e(asset('public/css/jquery.multiselect.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 1%;">
		<?php if($message = Session::get('success')): ?>
 
	    <div class="alert alert-success alert-block">
	 
	        <button type="button" class="close" data-dismiss="alert">×</button>
	 
	            <strong><?php echo e($message); ?></strong>
	 
	    </div>
	    <br>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-10">
        	
        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Menu Page</div>
        	<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#ModalLoginForm">
                          create menu +
                                </button>
            	<form action="<?php echo e(route('admin_sale')); ?>" method="post" enctype="multipart/form-data" id="saleForm">
            		<?php echo csrf_field(); ?>
				  <div class="form-row" style="margin-top:3%;">
				 
					<div class="form-group col-md-6">
				      <label for="property_type"> Main Menu<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="menu" name="menu">
				        <option selected>-</option>
				         <option value="home">Home</option>
				        <option value="about_us">About us</option>
				        <option value="home">Contact us</option>
				        <option value="select">Career</option>
				        <option value="select">Blog</option>
				        <option value="select">Blog</option>
				        <option value="select">Contact us</option>
		       
				      </select>
					</div>
					 	 <div class="form-group col-md-6">
				  	 	<label for="serial_no">Sub-menu<span class="text-danger">*</span></label>
				      <input type="text" class="form-control" maxlength="50" name="sub_menu" id="sub_menu">
				     </div>
				  	 <div class="form-group col-md-6">
				  	 	<label for="project_name">Sub sub-menu<span class="text-danger">*</span></label>
				      <input type="text" class="form-control" maxlength="50" name="sub_sub_menu" id="sub_sub_menu">
				     </div>

					<div class="form-group col-md-12" style="text-align: center;">
				  		<button type="submit" class="btn btn-success">Submit</button>
				    </div>
				</form>
            </div>
        </div>
    </div>
</div>


<!-- Modal HTML Markup -->
<div id="ModalLoginForm" class="modal fade">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" style="text-align: center;">Create Menu</h4>
            </div>
            <div class="modal-body">
                <form role="form" method="POST" action="">
                 	 <div class="form-group col-md-6">
				  	 	<label for="project_name">Menu<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="sub_sub_menu" id="sub_sub_menu">
				     </div>

                
                    <div class="form-group">
                        <div>
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </div>
                </form>
              
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
	<script src="<?php echo e(asset('public/js/jquery.multiselect.js')); ?>"></script>
	<script>
		$(document).ready(function() {
            $('#saleForm').validate({
                rules: {
                    serial_no: "required",
                    project_name: "required",
                    flat_type: "required",
                    price: "required",
                    status: "required",
                    short_desc: "required",
                    overview: "required",
                    city: "required",
                    parking: "required",
                    condition: "required",
                    property_type: "required",
                    floor: "required",
                    area: "required",
                    total_bedroom: "required",
                    total_bathroom: "required",
                    maintenance: "required",
                }
            });
            $('#amenity').multiselect({
		        listWidth: 830,
		        cssEven: false,
		        cssOdd: false,
		    });
            $('.select3').select2({
			    closeOnSelect: false
			});
			$('#select_all').click(function() {
		        $('#amenity option').prop('selected', true);
		    });
			if (window.File && window.FileList && window.FileReader) {
		    $("#main-file-input").on("change", function(e) {
		      var files = e.target.files,
		        filesLength = files.length;
		      for (var i = 0; i < filesLength; i++) {
		        var f = files[i]
		        var fileReader = new FileReader();
		        fileReader.onload = (function(e) {
		          var file = e.target;
		          $("<span class=\"pip\">" +
		            "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
		            "<br/><span class=\"remove\">Remove</span>" +
		            "</span>").insertAfter("#main-file-input");
		          $(".remove").click(function(){
		            $(this).parent(".pip").remove();
		          });
		        });
		        fileReader.readAsDataURL(f);
		      }
		    });
		  } else {
		    alert("Your browser doesn't support to File API")
		  }
		 if (window.File && window.FileList && window.FileReader) {
		    $("#file-input").on("change", function(e) {
		      var files = e.target.files,
		        filesLength = files.length;
		      for (var i = 0; i < filesLength; i++) {
		        var f = files[i]
		        var fileReader = new FileReader();
		        fileReader.onload = (function(e) {
		          var file = e.target;
		          $("<span class=\"pip\">" +
		            "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
		            "<br/><span class=\"remove\">Remove</span>" +
		            "</span>").insertAfter("#file-input");
		          $(".remove").click(function(){
		            $(this).parent(".pip").remove();
		          });
		        });
		        fileReader.readAsDataURL(f);
		      }
		    });
		  } else {
		    alert("Your browser doesn't support to File API")
		  }
        });
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/sale.blade.php ENDPATH**/ ?>