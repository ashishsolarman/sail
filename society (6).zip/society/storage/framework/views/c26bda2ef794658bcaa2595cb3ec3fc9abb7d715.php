
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 1%;">
		<?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
		<div class="row justify-content-center">
	        <div class="col-md-11">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Sale List</div>
	            	<div style="overflow-x: scroll;">
		              <table class="table table-bordered table-striped" id="system_table">
		                <thead>
			                <tr>
			                  <th>ID</th>
			                  <th>Menu</th>
			                  <th>Sub Menu</th>
			                  <th>Sub Sub_Menu</th>
			               
			                  <th>Created At</th>
			                  <th colspan="2" style="text-align: center;">Action</th>
			                </tr>
		                </thead>
		                <tbody>
		               		<?php $__currentLoopData = $sales_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <tr>
				                <td><?php echo e($sales_data->id); ?></td>
				                <td><?php echo e($sales_data->serial_no); ?></td>
				                <td><?php echo e($sales_data->project_name); ?></td>
				                <td><?php echo e($sales_data->flat_type); ?></td>
				                <td><?php echo e($sales_data->price); ?></td>
				                <td><?php echo e($sales_data->status); ?></td>
				                <td><?php echo e($sales_data->city); ?></td>
				                <td><?php echo e($sales_data->property_type); ?></td>
				                <td><?php echo e($sales_data->created_at); ?></td>
				                <td><a href="delete_sale/<?php echo e($sales_data['id']); ?>"  class="btn btn-danger">delete</a></td>
				                <td><a href="edit_sale/<?php echo e($sales_data['id']); ?>"  class="btn btn-info">Edit</a></td>
			                </tr>
		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              </tbody>
             		</table>
				</div>
				<!-- pagination -->
				<?php echo e($sales_datas->links()); ?>

	        </div>
	    </div>
    </div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/menu_data.blade.php ENDPATH**/ ?>