
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- buy-banner -->
<section class="buy-header d-flex flex-column align-items-center justify-content-center">
  <div class="text-center heading">
    <h1>Projects</h1>
  </div>
</section>
<!--buy-banner -->

<!--buy-content -->
<div class="container list">
   <div class="accordion-wrapper internal">
  		<div class="accordion internal">
    		<input type="radio" name="radio-a" id="check1" checked>
    		<label class="accordion-label" for="check1">HOTEL CANNAUGHT ROYALE</label>
	    	<div class="accordion-content">
	      		<div class="row photos">
	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g1.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g2.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g3.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g4.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g5.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g6.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g7.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g8.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g9.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g9.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g10.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g10.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g11.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g11.jpeg')); ?>"></a>
	                </div>

	                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/hotel_cannaught_royal/g12.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/hotel_cannaught_royal/g12.jpeg')); ?>"></a>
	                </div>
	            </div>
	    	</div>
  		</div>
	<div class="accordion">
	    <input type="radio" name="radio-a" id="check2">
	    <label class="accordion-label" for="check2">CALIFORNIA BOL</label>
    	<div class="accordion-content">
        	<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g4.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g5.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g6.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g7.jpeg')); ?>"></a>
                </div>

                <!-- <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g8.jpeg')); ?>"></a>
                </div> -->

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g9.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g9.jpeg')); ?>"></a>
                </div>

               <!--  <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/california_bol/g10.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/california_bol/g10.jpeg')); ?>"></a>
                </div> -->
            </div>
    	</div>
  	</div>
	<div class="accordion">
	    <input type="radio" name="radio-a" id="check3">
	    <label class="accordion-label" for="check3">ETERNITY</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/eternity/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/eternity/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/eternity/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/eternity/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/eternity/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/eternity/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/eternity/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/eternity/g4.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/eternity/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/eternity/g5.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
	<div class="accordion">
	    <input type="radio" name="radio-a" id="check4">
	    <label class="accordion-label" for="check4">FARMHOUSE</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/farmhouse/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/farmhouse/g1.jpeg')); ?>"></a></div>
      		</div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check5">
	    <label class="accordion-label" for="check5">GROVER MITHAIWALA - RAJINDER NAGAR</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/rajinder_nagar/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/rajinder_nagar/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/rajinder_nagar/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/rajinder_nagar/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/rajinder_nagar/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/rajinder_nagar/g3.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check6">
	    <label class="accordion-label" for="check6">GROVER MITHAIWALA PASCHIM VIHAR</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/paschim_vihar/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/paschim_vihar/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/paschim_vihar/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/paschim_vihar/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/paschim_vihar/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/paschim_vihar/g3.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check8">
	    <label class="accordion-label" for="check8">AMPM</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g4.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g5.jpeg')); ?>"></a>
                </div>

                <!-- <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g6.jpeg')); ?>"></a>
                </div> -->

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g7.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/ampm/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/ampm/g8.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check10">
	    <label class="accordion-label" for="check10">NEW YORK</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/newyork/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/newyork/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/newyork/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/newyork/g2.jpeg')); ?>"></a>
                </div>
        	</div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check11">
	    <label class="accordion-label" for="check11">PICASSO HOTEL MEERA BAGH</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g1.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g2.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g3.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g4.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_hotel_meera_bagh/g5.jpeg')); ?>"></a></div>
            </div>
    	</div>
 	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check12">
	    <label class="accordion-label" for="check12">PICASSO PRIVE NARAINA</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g4.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g5.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g6.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g7.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g8.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_prive_naraina/g9.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_prive_naraina/g9.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check13">
	    <label class="accordion-label" for="check13">PICASSO ROOF TOP</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_roof_top/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_roof_top/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_roof_top/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_roof_top/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_roof_top/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_roof_top/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_roof_top/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_roof_top/g4.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/picasso_roof_top/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/picasso_roof_top/g5.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check14">
	    <label class="accordion-label" for="check14">PIND BALLUCI</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/pind_balluci/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/pind_balluci/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/pind_balluci/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/pind_balluci/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/pind_balluci/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/pind_balluci/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/pind_balluci/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/pind_balluci/g4.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check15">
	    <label class="accordion-label" for="check15">Privilege punjab</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/Privilege_punjab/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/Privilege_punjab/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/Privilege_punjab/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/Privilege_punjab/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/Privilege_punjab/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/Privilege_punjab/g3.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check16">
	    <label class="accordion-label" for="check16">QUBITOS RELOADED</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_reloaded/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_reloaded/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_reloaded/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_reloaded/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_reloaded/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_reloaded/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_reloaded/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_reloaded/g4.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_reloaded/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_reloaded/g5.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
	<div class="accordion">
	    <input type="radio" name="radio-a" id="check17">
	    <label class="accordion-label" for="check17">QUBITOS THE TERRACE CAFE</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g1.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g2.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g3.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g4.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g5.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g6.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g7.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/qubitos_the_terrace_cafe/g8.jpeg')); ?>"></a></div>
            </div>
    	</div>
  	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check18">
	    <label class="accordion-label" for="check18">THE MILKY WAY</label>
    	<div class="accordion-content">
     		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/the_milky_way/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/the_milky_way/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/the_milky_way/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/the_milky_way/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/the_milky_way/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/the_milky_way/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/the_milky_way/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/the_milky_way/g4.jpeg')); ?>"></a>
                </div>
        	</div>
    	</div>
 	</div>
  	<div class="accordion">
	    <input type="radio" name="radio-a" id="check19">
	    <label class="accordion-label" for="check19">Tippling Street</label>
    	<div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g4.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g5.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g6.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g7.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/tippling_street/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/tippling_street/g8.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
	<div class="accordion">
	    <input type="radio" name="radio-a" id="check20">
	    <label class="accordion-label" for="check20">WEST SIDE STORY</label>
	    <div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story/g3.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story/g4.jpeg')); ?>"></a>
                </div>

                <!-- <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story/g5.jpeg')); ?>"></a></div> -->

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story/g6.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story/g7.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
  	</div>
	<div class="accordion">
	    <input type="radio" name="radio-a" id="check21">
	    <label class="accordion-label" for="check21">WEST SIDE STORY - BANQUET</label>
	    <div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story_banquet/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story_banquet/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/west_side_story_banquet/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/west_side_story_banquet/g2.jpeg')); ?>"></a>
                </div>
            </div>
    	</div>
	</div>
	<div class="accordion">
	    <input type="radio" name="radio-a" id="check22">
	    <label class="accordion-label" for="check22">BUFFETERIA</label>
	    <div class="accordion-content">
      		<div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g1.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g2.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g3.jpeg')); ?>"></a>
                </div>

                <!-- <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g4.jpeg')); ?>"></a>
                </div> -->

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g5.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g6.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g7.jpeg')); ?>"></a>
                </div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/buffeteria/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/buffeteria/g8.jpeg')); ?>"></a>
                </div>
            </div>
    </div>
  </div>


 <div class="accordion">
    <input type="radio" name="radio-a" id="check9">
    <label class="accordion-label" for="check9">Other Projects</label>
    <div class="accordion-content">
      <div class="row photos">
                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g1.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g1.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g2.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g2.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g3.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g3.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g4.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g4.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g5.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g5.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g6.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g6.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g7.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g7.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g8.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g8.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g9.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g9.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g10.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g10.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g11.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g11.jpeg')); ?>"></a></div>

                <div class="col-sm-6 col-md-4 col-lg-3 item"><a href="<?php echo e(asset('public/img/misc/g12.jpeg')); ?>" data-lightbox="photos"><img class="img-fluid" src="<?php echo e(asset('public/img/misc/g12.jpeg')); ?>"></a></div>
            </div>
    </div>
  </div>

  
</div>
</div>
</div>
</div>

<!--buy-content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/user/project.blade.php ENDPATH**/ ?>