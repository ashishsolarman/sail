<div class="container">
	<div class="row col-md-8" >
		<a class="navbar-brand" href="https://nagpalproperties.co.in/" style="width:325px;">
        	<img src="https://nagpalproperties.co.in/public/img/finallogo.png" alt="Logo">
		</a>
		<h2>Hello Admin,</h2>
		You received an email from : <?php echo e($first_name); ?> <?php echo e($last_name); ?>

		Here are the details:<br><br>
		<table>
			<tr style='text-align:center;'>
				<td style='padding: 10px;border: 1px solid #bbb;width: 25%;'><b>Name:</b></td> 
				<td style='padding: 10px;border: 1px solid #bbb;'><?php echo e($first_name); ?> <?php echo e($last_name); ?><br></td>
			</tr>
			<tr style='text-align:center;'>
				<td style='padding: 10px;border: 1px solid #bbb;width: 25%;'><b>Email:</b></td>
				<td style='padding: 10px;border: 1px solid #bbb;width: 25%;'><?php echo e($email); ?><br></td>
			</tr>
			<tr style='text-align:center;'>
				<td style='padding: 10px;border: 1px solid #bbb;width: 25%;'><b>Message:</b></td>
				<td style='padding: 10px;border: 1px solid #bbb;width: 25%;'><?php echo e($message_details); ?></td>
			</tr>
		</table>
		Thank You
	</div>
</div><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/user/contact_email.blade.php ENDPATH**/ ?>