<h1>Hi, <?php echo e($name); ?></h1>
l<p>Sending Mail Regarding  Payment.</p><?php /**PATH C:\xampp\htdocs\society\resources\views/mail.blade.php ENDPATH**/ ?>