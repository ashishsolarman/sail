
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  #cont{
  position: relative;

}
.son{
  position: absolute;
  top:0;
  left:0;

}




#control{
  position:absolute;

  left:0;

  z-index: 50;
  background: HoneyDew ;
  opacity:0.7;
  color:#fff;
  text-align: center;

}
#snap{
  background-color: dimgray ;

}
#retake{
  background-color: coral ;

}

#close{
  background-color: lightcoral ;

}
.hov{
  opacity:.8;
  transition: all .5s;
}
.hov:hover{
  opacity:1;

  font-weight: bolder;
}
#panel, #flip {
  padding: 5px;
  text-align: center;
  background-color: #fff;
  border: solid 1px #c3c3c3;
}

#panel {
  padding: 50px;
  display: none;
}

  </style>

<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
    <?php if($message = Session::get('success')): ?>
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button>
   
              <strong><?php echo e($message); ?></strong>
   
      </div>
      <br>
    <?php endif; ?>
  <div class="container">
  <div class="row justify-content-center">
  <div class="col-md-10">
  <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000"><?php echo e(_('ADD VISITOR')); ?></div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <form action="<?php echo e(route('store_visitor_details')); ?>" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
            <div class="form-row" style="margin-top:3%;">
             <div class="form-group col-md-6">
              <label for="project_name"><?php echo e(_('FULL NAME')); ?><span class="text-danger">*</span></label>
              <input  type="text" value="<?php if(!empty($item->mobile_no)): ?><?php echo e($item->name); ?> <?php else: ?> <?php endif; ?>" class="form-control" name="name" id="name" required>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div>
             <div class="form-group col-md-6">
              <label for="project_name"><?php echo e(_('PHONE NUMBER')); ?><span class="text-danger">*</span></label>
              <input type="number" class="form-control" value="<?php echo e(request()->input('mobile_no')); ?>" name="mobile_no" min="0" oninput="this.value = Math.abs(this.value)" readonly>
                <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div>
         
              <div class="form-group col-md-6">
              <label for="status"><?php echo e(_('IDENTITY CARD TYPE.')); ?><span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2"  id="id_type" name="id_type"  style="height:48px;" required>
                <option selected><?php if(!empty($item->mobile_no)): ?><?php echo e($item->id_type); ?> <?php else: ?> <?php endif; ?></option>
               
                 <option value="Aadhar Card">Aadhar Card</option>
                 <option value="Passport">Passport</option>
                 <option value="Pan Card">Pan Card</option>
                 <option value="Voter Card">Voter Card</option>
                 <option value="Driving Licence">Driving Licence</option>
              
              </select>
                <?php $__errorArgs = ['id_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
               <div class="form-group col-md-6">
              <label for="project_name"><?php echo e(_('IDENTITY CARD NO.')); ?><span class="text-danger">*</span></label>
              <input style="text-transform:uppercase" type="text"   class="form-control" value="<?php if(!empty($item->mobile_no)): ?><?php echo e($item->id_no); ?> <?php else: ?> <?php endif; ?>"  name="id_no" id="id_no" required>
               <?php $__errorArgs = ['id_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div>

             <!-- Webcamera section -->
             <?php if(!empty($item->mobile_no)): ?>
             <div class="form-group col-md-12"><img src="<?php echo e(asset('uploads/visitors_images')); ?>/<?php echo e($item->image); ?>" class="col-md-6" width="300" height="200"/></div>
        
           <?php else: ?>
              <div class="col-md-12" id="flip" style="background-color: skyblue;border-radius: 20px;color:white;">Open Webcam to Take Identity Card Screenshot & Photo</div>
           <?php endif; ?>
           <div class="row " id="panel">
            <div class="form-group col-md-4">
                <div id="my_camera"></div>
                <br/>
                <input type=button class="btn btn-info" value="Take A photo" onClick="take_snapshot()">
                <input type="hidden" name="image"  class="image-tag">
            </div>
            <div class="form-group col-md-4">
                <div id="results">Your captured image will appear here...</div>
            </div>
        </div>
        
    


            <!-- end webcamera section -->
             
            <div class="form-group col-md-4">
              <label for="status"><?php echo e(_('VEHICLE TYPE')); ?><span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2"  id="vehicle_type" name="vehicle_type"  style="height:48px;">
                <option selected><?php if(!empty($item->mobile_no)): ?><?php echo e($item->vehicle_type); ?> <?php else: ?> <?php endif; ?></option>
               
                  <option value="Two Wheeler">Two Wheeler</option>
                 <option value="Three Wheeler">Three Wheeler</option>
                 <option value="Four Wheeler">Four Wheeler</option>
              
              </select>
                <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          
          
               <div class="form-group col-md-4">
              <label for="city"><?php echo e(_('VEHICLE NAME')); ?><span class="text-danger">*</span></label>
             <input type="text"  class="form-control" value="<?php if(!empty($item->mobile_no)): ?><?php echo e($item->vehicle_name); ?> <?php else: ?> <?php endif; ?>"  id="city" name="vehicle_name">
                  <?php $__errorArgs = ['vehicle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-4">
              <label for="city"><?php echo e(_('VEHICLE NUMBER')); ?><span class="text-danger">*</span></label>
             <input style="text-transform:uppercase" type="text" value="<?php if(!empty($item->mobile_no)): ?><?php echo e($item->vehicle_number); ?> <?php else: ?> <?php endif; ?>"  class="form-control" id="city" name="vehicle_number">
               <?php $__errorArgs = ['vehicle_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        <div class="form-group col-md-12">
        <label for="city"><?php echo e(_('Visit Date')); ?><span class="text-danger">*</span></label>
        <input  type="date" data-date-format="DD/MM/YYYY"   class="form-control" data-date=""  name="meeting_date" required>
               <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
  <input  type="hidden"  class="form-control" value="<?php if(!empty($item->mobile_no)): ?><?php echo e($item->id); ?> <?php else: ?> <?php endif; ?>"  name="visitor_id">
            <div class="form-group col-md-12">
            <label for="city"><?php echo e(_('PURPOSE OF VISIT')); ?><span class="text-danger">*</span></label>
            <textarea rows="4" class="form-control" required name="purpose"></textarea>
              <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div> 
            </div>
          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-success">SUBMIT</button>
            </div>
        </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script language="JavaScript">
    Webcam.set({
        width: 490,
        height: 350,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
    
    Webcam.attach( '#my_camera' );
    
    function take_snapshot() {
        Webcam.snap( function(data_uri) {
            $(".image-tag").val(data_uri);
            document.getElementById('results').innerHTML = '<img src="'+data_uri+'"/>';
        } );
    }
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script> 
$(document).ready(function(){
  $("#flip").click(function(){
    $("#panel").slideDown("slow");
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/allowance/gate_pass_form.blade.php ENDPATH**/ ?>