
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block; 
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  </style>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
  <link href="<?php echo e(asset('public/css/jquery.multiselect.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
    <?php if($message = Session::get('success')): ?>
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button>
   
              <strong><?php echo e($message); ?></strong>
   
      </div>
      <br>
    <?php endif; ?>
  <div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-12">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Maintenance Money</div>
                <form action="#" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
          <div class="form-row" >
 
          <div class="form-group col-md-6"> 
           <label for="city">From<span class="text-danger">*</span></label>
          <input class="form-control" name="from_date" type="date" required> 
           </div>

             <div class="form-group col-md-6"> 
           <label for="city">To<span class="text-danger">*</span></label>
          <input class="form-control" name="to_date" type="date" required> 
           </div>
   
            <div class="form-group col-md-6">
              <label for="city">Mode of Payment<span class="text-danger">*</span></label>
                <select class="custom-select mr-sm-2" id="status" name="payment_mode">
                <option selected>-</option>
                <option value='1'>Cash</option>
                <option value='2'>Online</option>
       
                       
              </select>
              
            </div>

              <div class="form-group col-md-6">
              <label for="status">Amount<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2" id="status" name="amount">
                <option selected>-</option>
                <option value='300'>₹ 300</option>
                <option value='600'>₹ 600</option>
                <option value='900'>₹ 900</option>
                <option value='1200'>₹ 1200</option>
                <option value='1500'>₹ 1500</option>
                <option value='1800'>₹ 1800</option>
                <option value='2100'>₹ 2100</option>
                <option value='2400'>₹ 2400</option>
                <option value='2700'>₹ 2700</option>
                <option value='3000'>₹ 3000</option>
               
                       
              </select>
            </div>

          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-info">Collect</button>
            </div>
        </form>
          <div class="col-md-12">
                <div class="box box-default">
                  <div class="box-body">
                      <div class="row">
                                                
                          <div class="container  table-responsive py-5" >
                            <table class="table table-bordered table-striped" width="100%">
                                    <tbody><tr>
                                        <th width="27%">Registration No</th>
                                        <td width="48%">
                                        2022/GDA/09/28/55147</td>
                                        <td  ><img src="https://cdn.pixabay.com/photo/2016/08/08/09/17/avatar-1577909__340.png" width="160" height="120"></td>
                                    </tr>
                                    <tr>
                                        <th>Visit Date</th><td>27-09-2022 13:07:24</td>
                                    </tr>
                                    <tr>
                                        <th>Department/Officer</th>
                                        <td>
                                        Sh. Chandra Prakash Tripathi (CATP)
                                      </td>
                                    </tr>
                                </tbody></table>
                          </div>
                      </div>
                      <div class="row">
                          <div class="container  table-responsive ">
                            <table class="table table-bordered table-striped">
                              <tbody>
                                  <tr>
                                      <th>Name</th><td>ARUN </td>
                                      <th>Mobile</th><td>9911397473</td>
                                  </tr>
                                  <tr>
                                      <th>Identity Card</th><td></td>
                                      <th>Identity Card No.</th>
                                      <td>
                                      </td>
                                  </tr>
                                                      <tr>
                                      <th>Visitor Count</th>
                                      <td>
                                          3
                                      </td>
                                      <th>Last Visited Date</th>
                                      <td>
                                          23-09-2022 12:51:45 
                                      </td>
                                  </tr>
                                  <tr>
                                      <th>Purpose of Visit</th>
                                      <td colspan="3">KHASRA NO-606 TILA SHAHBAJ PUR MAP 

                                      VACCINATION COMPLETE</td>
                                  </tr>
                                
                              </tbody>
                            </table>
                            
                        </div>
                    </div>
                                      </div>
                </div>
              </div>
        
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
  
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/collection/collection.blade.php ENDPATH**/ ?>