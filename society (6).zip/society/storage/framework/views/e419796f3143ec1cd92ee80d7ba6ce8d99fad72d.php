
<?php $__env->startSection('content'); ?>

<!-- about-banner -->
<section class="about-main d-flex flex-column align-items-center justify-content-center">
  <div class="text-center heading">
    <h1>Collaboration</h1>
  </div>
</section>
<!--about-banner -->

<!--about-content -->
<section class="about-content">
  <div class="container">
    <div class="row internal">
      <div class="col-lg-10 mx-auto collaboration">
        <h2 class="mb-3">Collaboration</h2>
        <form id="contactform" class="contact-form" name="contactform" method="post" novalidate="novalidate">
          <div class="form-group">
            <input type="text" required="" class="form-control input-custom input-full" name="name" placeholder="Name" aria-required="true">
            </div>

              <div class="form-group">
              <input type="tel" required="" class="form-control input-custom input-full" name="telphone" placeholder="Phone Number" aria-required="true">
              </div>

            <div class="form-group">
              <input type="text" class="form-control input-custom input-full" name="expectation" placeholder="Expectation">
            </div>

          <div class="form-group">
            <input type="tel" required="" class="form-control input-custom input-full" name="ask" placeholder="Asking Price" aria-required="true">
          </div>

          <div class="form-group">
            <input type="text" class="form-control input-custom input-full" name="other" placeholder="Other Details">
          </div>

            <div class="form-group">
              <textarea class="form-control textarea-custom input-full" id="ccomment" name="add" required="" rows="8" placeholder="Address" aria-required="true"></textarea>
            </div>

<div class="sub"><a href="#">Submit</a></div>
</form>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/collaboration.blade.php ENDPATH**/ ?>