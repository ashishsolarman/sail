
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  </style>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
  <link href="<?php echo e(asset('public/css/jquery.multiselect.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
    <?php if($message = Session::get('success')): ?>
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button>
   
              <strong><?php echo e($message); ?></strong>
   
      </div>
      <br>
    <?php endif; ?>
  <div class="container" style="margin-top: 1%;">
    <div class="row justify-content-center">
        <div class="col-md-10">
                      
<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000"><?php echo e(_('ADD NEW VISITOR')); ?> </div>
<div class="form-group col-md-12">
    <form method="post" action="<?php echo e(route('visitor_search')); ?>" >
                <?php echo csrf_field(); ?>
             <div class="form-row" style="margin-top:3%;">
             <div class="form-group col-md-12">
              <label for="project_name"><?php echo e(_('MOBILE')); ?><span class="text-danger">*</span></label>
              <input  type="number" placeholder="Enter mobile" class="form-control" value="<?php echo e(request()->input('mobile')); ?>" name="mobile_no">
              <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-success">SUBMIT</button>
              </div>
              </div> 
     
        </form>
      </div>
        
      
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
  
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/allowance/visit_master.blade.php ENDPATH**/ ?>