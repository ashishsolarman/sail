
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  #txt-custom{
  display: none;
}

  </style>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
  <link href="<?php echo e(asset('public/css/jquery.multiselect.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
      <!-- Flash message -->
    <?php if(Session()->has('success')): ?>
      <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button>
          <strong><?php echo e(Session()->get('success')); ?></strong>
   
      </div>
      <br>
    <?php endif; ?>
  <div class="container" style="margin-top: 1%;">
    <div class="row justify-content-center">
        <div class="col-md-10">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Tenant Registration</div>
              <form action="<?php echo e(route('store_tenant')); ?>" method="post" enctype="multipart/form-data" id="saleForm">
                <?php echo csrf_field(); ?>
          <div class="form-row" style="margin-top:3%;">
              <div class="form-group col-md-6">
              <label for="status">Owner Name<span class="text-danger">*</span></label>
              <select style="height:48px;" class="custom-select mr-sm-2" id="owner_name" name="owner_name" value="<?php echo e(old('owner_name')); ?>">
                <option selected></option>
                <?php ($owner_details = \App\Models\Owner::all()); ?> 
                <?php $__currentLoopData = $owner_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option ><?php echo e($item->owner_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </select>
                <?php $__errorArgs = ['block'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
              <div class="form-group col-md-6">
              <label for="owner_name">Tenant Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="tenant_name" id="tenant_name" value="<?php echo e(old('tenant_name')); ?>">
              <?php $__errorArgs = ['tenant_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div>

              <div class="form-group col-md-6">
              <label for="serial_no">Phone Number<span class="text-danger">*</span></label>
              <input type="number" class="form-control" min="0" oninput="this.value = Math.abs(this.value)" name="mobile" id="mobile" value="<?php echo e(old('mobile')); ?>">
              <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div>

               <div class="form-group col-md-4">
              <label for="status">Block<span class="text-danger">*</span></label>
              <select style="height:48px;" class="custom-select mr-sm-2" id="block" name="block" value="<?php echo e(old('block')); ?>">
                <option selected></option>
                <option value="A">A</option>
                 <option value="B">B</option>
                 <option value="C">C</option>
                 <option value="D">D</option>
                  <option value="E">E</option>
                  <option value="F">F</option>
               
              
              </select>
                <?php $__errorArgs = ['block'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
             <div class="form-group col-md-4">
              <label for="flat_type">Floor <span class="text-danger">*</span></label>
              <select style="height:48px;" class="custom-select mr-sm-2" id="floor" name="floor" value="<?php echo e(old('floor')); ?>">
                <option ></option>
               
                <option value="Ground Floor">Ground Floor</option>
                <option value="First Floor">First Floor</option>
                <option value="Third Floor">Third Floor</option>
                <option value="Fourth Floor">Fourth Floor</option>
                 <option value="Fifth Floor">Fifth Floor</option>

              </select>
                <?php $__errorArgs = ['floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           
                 <div class="form-group col-md-4">
              <label for="serial_no">House No.<span class="text-danger">*</span></label>
              <input  type="number" min="0" oninput="this.value = Math.abs(this.value)" class="form-control"  name="house_no" id="house_no" value="<?php echo e(old('house_no')); ?>">
                <?php $__errorArgs = ['house_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div>
    
              <div class="form-group col-md-6">
              <label for="serial_no">Email Address<span class="text-danger">*</span></label>
              <input type="email" class="form-control" maxlength="50" name="email" id="email" value="<?php echo e(old('email')); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             </div>

             <div class="form-group col-md-6">
              <label for="status">Status<span class="text-danger">*</span></label>
              <select style="height:48px;" class="custom-select mr-sm-2" id="status" name="status" value="<?php echo e(old('status')); ?>">
                <option></option>
               
                  <option value="Active">Active</option>
                 <option value="Inactive">Inactive</option>

              </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           <!--        <div class="form-group col-md-6">
            <label for="status">Profession<span class="text-danger">*</span></label>
           <select style="height:48px;" id="profession" name="profession" class="custom-select mr-sm-2">
           <option selected>-</option>
            <option value="custom">Businessman</option>
             <option value="custom">Lawyer</option>
              <option value="custom">Custom</option>
               </select><br><br>
            
            </div> -->
           <div class="form-group col-md-6">
              <label for="city">Profession<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="profession"   name="profession" value="<?php echo e(old('profession')); ?>">
               <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          <!--  <div class="form-group col-md-6" style="display :none;" type="text" id="txt-custom">
              <label for="main_image">Field</label><span class="text-danger">*</span>
              <input class="form-control" name="custom-value" />
              <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
            <div id="main-thumb-output"></div>
          </div>  -->
         

          <div class="form-group col-md-6">
              <label for="main_image">Owner Image</label><span class="text-danger">*</span>
              <input type="file" class="form-control" id="owner_image" name="owner_image" value="<?php echo e(old('owner_image')); ?>">
            <div id="main-thumb-output"></div>
              <?php $__errorArgs = ['owner_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group col-md-6">
              <label for="city">Aadhar Card no.<span class="text-danger">*</span></label>
             <input type="number" min="0" oninput="this.value = Math.abs(this.value)" class="form-control" id="aadhar_no"   name="aadhar_no" value="<?php echo e(old('aadhar_no')); ?>">
                <?php $__errorArgs = ['aadhar_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          <div class="form-group col-md-6">
              <label for="image">upload your aadhar</label><span class="text-danger">*</span>
              <input type="file" class="form-control" id="aadhar_image" name="aadhar_image" value="<?php echo e(old('aadhar_image')); ?>">
            <div id="thumb-output"></div>
              <?php $__errorArgs = ['aadhar_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="row show_item" style="margin-left:1.5%;">
        <div class="row">
            <div class="form-group col-md-5">
              <label for="status">Vehicle Type<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2" id="vehicle_type" name="vehicle_type[]" style="height:48px;" value="<?php echo e(old('vehicle_type')); ?>">
                <option ></option>
               
                  <option value="Two Wheeler">Two Wheeler</option>
                 <option value="Three Wheeler">Three Wheeler</option>
                 <option value="Four Wheeler">Four Wheeler</option>
                <!-- <option value="unsold">Sold</option> -->
              
              </select>
                <?php $__errorArgs = ['vehicle_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          
          
               <div class="form-group col-md-3">
              <label for="city">Vehicle Name<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="vehicle_name" name="vehicle_name[]" value="<?php echo e(old('vehicle_name')); ?>">
                <?php $__errorArgs = ['vehicle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-3">
              <label for="city">Vehicle Number<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="vehicle_number" name="vehicle_number[]" value="<?php echo e(old('vehicle_number')); ?>">
                  <?php $__errorArgs = ['vehicle_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span style="color:red;"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            </div>

         <div class="form-group col-md-1">
                <label for="status" type="hidden"><span class="text-danger"></span></label>
              <a class="btn btn-info add_item_btn">  <i class=" typcn typcn-plus btn-icon-append"></i></a>
            </div>
       </div>
           </div>
          
          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-success">Submit</button>
            </div>
        </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/js/jquery.min.js"></script>
<script>
    $(document).ready(function(){
      $(".add_item_btn").click(function(e){
      e.preventDefault();
      $(".show_item").prepend(`<div class="row">
            <div class="form-group col-md-5">
              <label for="status">Vehicle Type<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2" id="status" name="vehicle_type[]" required>
                 <option ></option>
               
                  <option value="Two Wheeler">Two Wheeler</option>
                 <option value="Three Wheeler">Three Wheeler</option>
                 <option value="Four Wheeler">Four Wheeler</option>
              
              </select>
           
            </div>
          
          
               <div class="form-group col-md-3">
              <label for="city">Vehicle Name<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="vehicle_name[]" required>
          
            </div>
            <div class="form-group col-md-3">
              <label for="city">Vehicle Number<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="vehicle_number[]" required>
          
            </div>

         <div class="form-group col-md-1">
                <label for="status" type="hidden"><span class="text-danger"></span></label>
              <a class="btn btn-danger remove_item_btn">  <i class=" typcn typcn-minus btn-icon-append"></i></a>
            </div>
       </div>`);
      });
      $(document).on('click','.remove_item_btn',function(e){
       let row_item = $(this).parent().parent();
       $(row_item).remove();
      });
    });
  </script>
<script>
  let selectEl = document.getElementById('select-list');

selectEl.addEventListener('change', (e) => {
  if (e.target.value == 'custom') {
    document.getElementById('txt-custom').style.display = 'block';
  } else {
    document.getElementById('txt-custom').style.display = 'none';
  }
});
</script>
<script>
  let selectEl = document.getElementById('select-list');

selectEl.addEventListener('change', (e) => {
  if (e.target.value == 'bussinessman') {
    document.getElementById('txt-custom').style.display = 'block';
  } else {
    document.getElementById('txt-custom').style.display = 'none';
  }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/tenant/add_tenant.blade.php ENDPATH**/ ?>