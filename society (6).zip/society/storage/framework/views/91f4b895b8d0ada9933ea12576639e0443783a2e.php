
<?php $__env->startSection('content'); ?>
<style>
[draggable="true"] {
  user-select: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  -ms-user-select: none;
}

ul.moveable {
  list-style: none;
  margin: 0px;

  li {
    list-style-image: none;
    margin: 10px;
    border: 1px solid #ccc;
    padding: 4px;
    border-radius: 4px;
    color: #666;
    cursor: move;

    &:hover {
      background-color: #eee;
    }
  }
}
</style>
	<div class="container" style="margin-top: 1%;">
		<?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
		<div class="row justify-content-center">
	        <div class="col-md-11">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Menu List</div>
	            	<div style="overflow-x: scroll;">
		              <table class="table table-bordered table-striped" id="system_table">
		                <thead>
			                <tr>
			                  <th>ID</th>
			                  <th>Menu</th>
			                  <th>Sub Menu</th>
			                  <th>Sub Sub_Menu</th>
			               
			                  <th>Created At</th>
			                  <th colspan="2" style="text-align: center;">Action</th>
			                </tr>
		                </thead>
		                <tbody>
		                	
		               		<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		               	
			                <tr>
				                <td><?php echo e($menu_data->id); ?></td>
				                <td><?php echo e($menu_data->menu); ?></td>
				                <td><?php echo e($menu_data->sub_menu); ?></td>
				                  <td><?php echo e($menu_data->sub_sub_menu); ?></td>
				                <td><?php echo e($menu_data->created_at); ?></td>
				                <td><a href="delete_sale/<?php echo e($menu_data['id']); ?>"  class="btn btn-danger">delete</a></td>
				                <td><a href="edit_menu/<?php echo e($menu_data['id']); ?>"  class="btn btn-info">Edit</a></td>
			                </tr>
		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              </tbody>
             		</table>
				</div>
				<!-- pagination -->
				
	        </div>
	    </div>



<ul id="items-list" class="moveable">
    <li>One</li>
    <li>Two</li>
    <li>Three</li>
    <li>Four</li>
</ul>
    </div>
<script>
	let items = document.querySelectorAll('#items-list > li')

items.forEach(item => {
  $(item).prop('draggable', true)
  item.addEventListener('dragstart', dragStart)
  item.addEventListener('drop', dropped)
  item.addEventListener('dragenter', cancelDefault)
  item.addEventListener('dragover', cancelDefault)
})

function dragStart (e) {
  var index = $(e.target).index()
  e.dataTransfer.setData('text/plain', index)
}

function dropped (e) {
  cancelDefault(e)
  
  // get new and old index
  let oldIndex = e.dataTransfer.getData('text/plain')
  let target = $(e.target)
  let newIndex = target.index()
  
  // remove dropped items at old place
  let dropped = $(this).parent().children().eq(oldIndex).remove()

  // insert the dropped items at new place
  if (newIndex < oldIndex) {
    target.before(dropped)
  } else {
    target.after(dropped)
  }
}

function cancelDefault (e) {
  e.preventDefault()
  e.stopPropagation()
  return false
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views//menu_data.blade.php ENDPATH**/ ?>