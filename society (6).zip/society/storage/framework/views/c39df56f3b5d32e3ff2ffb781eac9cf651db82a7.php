<!DOCTYPE html>
<html>
<head>
	
</head>
<body>

</body>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script>
	$(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>

<?php $__env->stopPush(); ?>
</html><?php /**PATH C:\xampp\htdocs\cms\resources\views/ak.blade.php ENDPATH**/ ?>