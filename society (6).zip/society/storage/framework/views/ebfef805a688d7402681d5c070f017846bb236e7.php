
<?php $__env->startSection('content'); ?>

<!-- about-banner -->
<section class="about-main d-flex flex-column align-items-center justify-content-center">
  <div class="text-center heading">
    <h1>About Us</h1>
  </div>
</section>
<!--about-banner -->

<!--about-content -->
<section class="about-content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <p> Nagpal Properties is a network of professionals who know and understand that their 
business is about more than just real estate and construction. It’s about people. People 
whose homes are the central plank upon which they will nurture families, build wealth, and 
find sanctuary.<br>
Founded by Mr. Krishan Lal Nagpal in 1964, Nagpal Properties has been part of the fabric of 
Indian life for more than 56 years. We’ve helped many thousands of people realise their 
dreams and we intend to be doing so well into the future. Over the years Nagpal Properties 
has established an untarnished reputation for honesty, integrity and professionalism. It’s a 
reputation we aim to keep.<br>
We believe that a good result and integrity are not mutually exclusive. Indeed our sales 
results show that honesty and profits do mix.<br>
Nagpal properties today is still a family owned business, now spanning residential and 
commercial real estate consultation and construction. We are small enough to feel like 
family with local knowledge and experience but large enough to see the big picture.
Our aim is to make your property experience a rewarding one and we’ll always go the extra 
mile to make it easier – right down to helping you move out and move in.<br>
Our principals and their staff are committed to the company’s guiding philosophy – “always, 
in all ways, beyond reproach” – ensuring that all those we deal with, whether buyers, 
sellers, investors or renters, are treated with respect, honesty and equity.<br>
Innovators from the day we opened our doors, Nagpal Properties is a modern and 
progressive network that continues to evolve to meet the changing needs of its clientele. 
We understand the value of smart, strategic marketing and use every resource at our 
disposal to see your property sold. Through our databases, the web, Social media handles 
and direct mail, we’ll build a campaign that delivers results. One tailored to suit your needs 
and your budget. It’s your home after all.<br>
Our reputation is your guarantee that you’ll be dealing with professionals who feel 
privileged to be entrusted with your greatest asset.</p>
</div>
</section>
 <?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/about_us.blade.php ENDPATH**/ ?>