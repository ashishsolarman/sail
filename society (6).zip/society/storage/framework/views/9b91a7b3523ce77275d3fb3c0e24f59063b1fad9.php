
<?php $__env->startSection('content'); ?>
<head>
  
   
    <!-- include libraries(jQuery, bootstrap) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-md-7 offset-3 mt-4">

                <div class="card-body" style="position:absolute;margin-top: 150px;">
                                   <?php if(Session()->has('success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e(Session()->get('success')); ?></strong>
     
        </div>
        <br>
    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('admin_content')); ?>">
                       <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <textarea type="text" class="form-control" name="content" id="summernote"></textarea>
                        </div>
                        <button type='submit' class="btn btn-danger btn-block">Save</button>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</body>
<!-- summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $('#summernote').summernote({
        height: 400,
         htmlMode:false,
    });
</script>


<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views//content.blade.php ENDPATH**/ ?>