
<?php $__env->startSection('content'); ?>
	<div class="container">
		<?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
		<div class="row justify-content-center">
	        <div class="col-md-12">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000"><?php echo e(_('ALL VENDORS')); ?></div>
         
	       <div class="row">
          <div class="col-md-12">
                   <div class="col-md-12">
               <div class="row">
              <div class="col-md-4">
               <form class="example" type="get" action="<?php echo e(route('searchbyname')); ?>">
               <label for="project_name"><?php echo e(_('SEARCH BY NAME')); ?><span class="text-danger">*</span></label>
                <input type="search" class="form-control" placeholder="Search.." name="name">
                <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                  </form>
                  </div>
                <div class="col-md-4">
                <form class="example" type="get" action="<?php echo e(url('searchbymobile')); ?>">
                <label for="project_name"><?php echo e(_('SEARCH BY MOBILE')); ?><span class="text-danger">*</span></label>
                 <input type="number" class="form-control"  placeholder="Search.." name="mobile">
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div>
                    <div class="col-md-4">
                <form class="example" type="get" action="<?php echo e(url('searchbyaddress')); ?>">
                <label for="project_name"><?php echo e(_('SEARCH BY ID N0')); ?><span class="text-danger">*</span></label>
                 <input type="text" class="form-control" placeholder="Search.." name="id_no" >
                  <button type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
                    </form>
                    </div> 
                  </div>
         

              <div class="card">

                <div class="table-responsive pt-3">
                  <div id="print-area-2" class="print-area">
                  <table class="table table-striped project-orders-table" id="theTable" >
                    <thead>
                      <tr>
                        <th class="ml-5">ID</th>
                        <th>Full Name</th>
                         <th>Mobile</th>
                       
                        <th>Identity Card</th>
                        <th>Identity Card No.</th>
                        
                         <th>Photo</th>
                         <th>Created At</th>
                       
                        <th style="text-align: center;">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $vendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      

                      <tr>
                        
                        <td>#<?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->mobile_no); ?></td>
                        <td><?php echo e($item->id_type); ?></td>
                        <td><?php echo e($item->id_no); ?></td>
                        
                        <td>
                           <a href="<?php echo e(asset('uploads/vendors_images')); ?>/<?php echo e($item->image); ?>" target="_blank">
                          <img src="<?php echo e(asset('uploads/vendors_images')); ?>/<?php echo e($item->image); ?>" class="img-responsive" style="width:100px;height:100px;"></a></td>
                        <td><?php echo e($item->created_at); ?></td>


                        <td>

                          <div class="d-flex align-items-center">
                             <?php $PRO= Crypt::encrypt($item->id); ?> 
                             <a href="vendor_profile/<?php echo e($PRO); ?>" type="button" class="btn btn-info btn-sm btn-icon-text mr-3">
                              View
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>                
                            </a>
                              <?php $vendor = Crypt::encrypt($item->vendor_id) ?>
                             <a href="vendor_history/<?php echo e($vendor); ?>" type="button" class="btn btn-warning btn-sm btn-icon-text mr-3">
                              History
                                 <i class="typcn typcn-eye-outline btn-icon-append"></i>                
                            </a>
                            <?php $editID = Crypt::encrypt($item->id) ?>
                            <a href="edit_vendor/<?php echo e($editID); ?>" type="button" class="btn btn-success btn-sm btn-icon-text mr-3">
                              Edit
                              <i class="typcn typcn-edit btn-icon-append"></i>                          
                            </a>
                            <a href="delete_vendor/<?php echo e($item->id); ?>" class="btn btn-danger btn-sm btn-icon-text">
                              Delete
                              <i class="typcn typcn-delete-outline btn-icon-append"></i>                          
                            </a>
                          </div>
                        </td>
                      </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>

                </div>
              </div>
            </div>
          </div>
				<!-- pagination -->
    
			
	        </div>
	    </div>
   
    </div>
  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/vendor/vendorsearch.blade.php ENDPATH**/ ?>