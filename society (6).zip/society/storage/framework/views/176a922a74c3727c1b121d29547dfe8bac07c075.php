

<?php $__env->startSection('content'); ?>

<!---banner -->
<section class="see-main d-flex flex-column align-items-center justify-content-center">
	<div class="text-center heading">
	<h1><?php echo e($sales->flat_type); ?></h1>
	</div>
</section>
	<!---banner -->

	<!-- slider-start -->
	<?php 
	    $x = explode ("|", $sales->image);
	?>
	<?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12">
		        <div class="row">
		          <div class="col-lg-6 col-md-6 col-sm-6">
				    <h6 class="heading-main"><?php echo e($sales->flat_type); ?></h6>
				  </div>
				  <div class="col-lg-6 col-md-6 col-sm-6 comb">
				    <div class="insale">
				      <p><?php echo e($sales->status); ?></p>
				    </div>

				    <div class="price">
				      <p>INR. <?php echo e($sales->price); ?></p>
				    </div>
		 		  </div>
		        </div>
			<!-- <h6 class="heading-main"><?php echo e($sales->flat_type); ?> APARTMENT</h6> -->

				<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
					<div class="carousel-inner">
							<?php $__currentLoopData = $x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
							<img src="<?php echo e(url('public/admin_image_upload_sale/'.$val)); ?>" style="height: " class="d-block w-100" alt="...">
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="visually-hidden">Previous</span>
					</button>
					<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="visually-hidden">Next</span>
					</button>
				</div>
		</div>
					

	<!-- slider-end -->

	<!-- form-start -->
			<div class="col-lg-4 col-md-4 col-sm-12 enquiry">
				<form id="contactform" class="contact-form" name="contactform" action="<?php echo e(route('details')); ?>" method="post" method="post" novalidate="novalidate">
		          <?php echo csrf_field(); ?>
		          <div class="form-group">
		            <input type="text" required="" class="form-control input-custom input-full" name="first_name" placeholder="First Name" aria-required="true">
		            <?php if($errors->has('first_name')): ?> 
		                <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span> 
		            <?php endif; ?>
		            </div>

		          <div class="form-group">
		            <input type="text" required="" class="form-control input-custom input-full" name="last_name" placeholder="Last Name" aria-required="true">
		            <?php if($errors->has('last_name')): ?> 
		                <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
		            <?php endif; ?>
		          </div>

		          <div class="form-group">
		            <input type="text" class="form-control input-custom input-full" name="email" placeholder="Email">
		            <?php if($errors->has('email')): ?> 
		                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
		            <?php endif; ?>
		          </div>

		          <div class="form-group">
		            <textarea class="form-control textarea-custom input-full" id="ccomment" name="message_details" required="" rows="8" placeholder="Please share property details also with your query here!" aria-required="true"></textarea>
		            <?php if($errors->has('message_details')): ?> 
		                <span class="text-danger"><?php echo e($errors->first('message_details')); ?></span>
		            <?php endif; ?>
		          </div>
	  				<div class="form-btn" style="text-align: center;">
              			<button type="submit" class="btn btn-success">Submit</button>
              		</div>
				</form>
			</div>
		</div>
	</div>
	<!-- form-end -->

	<!--tabs -->
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 main-tab">
				<!-- Tab links -->
				<div class="tab">
				  <button class="tablinks" onclick="openCity(event, 'overview')" id="defaultOpen">OVERVIEW</button>
				  <button class="tablinks" onclick="openCity(event, 'floor')">PROPERTY</button>
				  <button class="tablinks" onclick="openCity(event, 'amenities')">AMENITIES</button>
				</div>

				<div id="overview" class="tabcontent">
					<h3 class="tab-heading">Overview</h3>
					<p><?php echo e($sales->overview); ?></p>
				</div>

				<div id="floor" class="tabcontent">
					<h3 class="tab-heading">Property Details</h3>
                        <div class="row">
                            <div class="col-md-4 col-sm-6">
                                <ul style="list-style-type: none;">
                                	<li><span style="color: #16a9b5;"><b>&#10003;</b></span> <span style="font-weight: 500">Serial No.</span> : <?php echo e($sales->serial_no); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span> <span style="font-weight: 500">Status</span> : <?php echo e($sales->status); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span> <span style="font-weight: 500">Price :</span> INR. <?php echo e($sales->price); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span> <span style="font-weight: 500">Property Type</span> : <?php echo e($sales->property_type); ?></li>
                                    

                                </ul>
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <ul style="list-style-type: none;">
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">Condition</span> : <?php echo e($sales->condition); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">Floor</span> : <?php echo e($sales->floor); ?> </li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">Area</span> : <?php echo e($sales->area); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">Maintance</span> : <?php echo e($sales->maintenance); ?></li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-sm-6">
                                <ul style="list-style-type: none;">
                                	<li><span style="color: #16a9b5;"><b>&#10003;</b></span> <span style="font-weight: 500">Bedrooms</span> : <?php echo e($sales->total_bedroom); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">Bathrooms</span> : <?php echo e($sales->total_bathroom); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">City</span> : <?php echo e($sales->city); ?></li>
                                    <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">Parking</span> : <?php echo e($sales->parking); ?></li>
                                   <!--  <li><span style="color: #16a9b5;"><b>&#10003;</b></span>  <span style="font-weight: 500">Property Owner</span> :  <?php echo e($sales->city); ?></li> -->
                                    <!--<li>
                                        <strong>Zip Code: </strong>2451
                                    </li>-->
                                </ul>
                            </div>
                        </div>

				</div>
				<div class="tabcontent" id="amenities">                    
                    <!-- <div class="properties-description mt-30 mb-20"> -->
                    <h3 class="tab-heading">Amenities</h3>
                    <div class="row">
						<?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($key % 4 == 0): ?>
			                	<div class="col-md-4 col-sm-6">
					        <?php endif; ?>
		                			<ul style="list-style-type: none;">
									<li><span style="color: #16a9b5;"><b>&#10003;</b></span> <?php echo e($value); ?></li>
									</ul>
							<?php if(($key+1) % 4 == 0): ?>
			                	</div>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
			</div>
		</div>
	</div>
</section>
<!--tabs -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  	<script>
	    $(document).ready(function() {
	      	$('.brand-carousel').owlCarousel({
		        loop:true,
		        margin:10,
		        autoplay:true,
		        responsive:{
		          0:{
		            items:1
		          },
		          600:{
		            items:3
		          },
		          1000:{
		            items:5
		          }
		        }
	      	});
	    });

	    function openCity(evt, cityName) {
		  var i, tabcontent, tablinks;
		  tabcontent = document.getElementsByClassName("tabcontent");
		  for (i = 0; i < tabcontent.length; i++) 
		  {
		    tabcontent[i].style.display = "none";
		  }
		  tablinks = document.getElementsByClassName("tablinks");
		  for (i = 0; i < tablinks.length; i++) {
		    tablinks[i].className = tablinks[i].className.replace(" active", "");
		  }
		  document.getElementById(cityName).style.display = "block";
		  evt.currentTarget.className += " active";
		}

		// Get the element with id="defaultOpen" and click on it
			document.getElementById("defaultOpen").click();
  	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.details_app_usr_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/user/details.blade.php ENDPATH**/ ?>