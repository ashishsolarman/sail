
<?php $__env->startSection('css'); ?>
	<style>
    body
    {
    	color: #000000;
    }
    label.error 
	{
    	color: #dc3545;
    	font-size: 14px;
    }

	input[type="file"] {
	  display: block;
	}
	.imageThumb {
	  max-height: 75px;
	  border: 2px solid;
	  padding: 1px;
	  cursor: pointer;
	  margin: 10px 5px 0 0;
	  width: 100px;

	}
	.pip {
	  display: inline-block;
	  margin: 10px 5px 0 0;
	}
	.remove {
	  display: block;
	  background: #444;
	  border: 1px solid black;
	  color: white;
	  text-align: center;
	  cursor: pointer;
	  width: 100px; 

	}
	.remove:hover {
	  background: white;
	  color: black;
	}

	textarea.form-control 
	{
	    min-height: calc(11.6em + 0.75rem + 2px);
	}
	</style>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
	<link href="<?php echo e(asset('public/css/jquery.multiselect.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 1%;">
		<!-- Flash message -->
		<?php if(Session()->has('success')): ?>
	    <div class="alert alert-success alert-block">
	        <button type="button" class="close" data-dismiss="alert">×</button>
	        <strong><?php echo e(Session()->get('success')); ?></strong>
	 
	    </div>
	    <br>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-10">
        	
        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Adv Slider</div>
        
            	<form action="<?php echo e(route('main_slider')); ?>" method="post" enctype="multipart/form-data" id="saleForm">
            		<?php echo csrf_field(); ?>
				  <div class="form-row" style="margin-top:3%;"> 
				  	
				 
					
					 	 <div class="form-group col-md-6">
				  	 	<label for="sub_menu">Slider Images<span class="text-danger">*</span></label>
				      <input type="file" class="form-control"  name="image[]" >
				  
                
				     </div>
				      <div class="form-group col-md-6">
				  	 	<label for="sub_menu">Title<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="image" >
				  
                
				     </div>
				      <div class="form-group col-md-6">
				  	 	<label for="sub_menu">Alt Tag<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="image" >
		
				     </div>
				   <div class="form-group col-md-6">
				  	 	<label for="sub_menu">HyperLink<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="image" >
		
				     </div>

					<div class="form-group col-md-12" style="text-align: center;">
				  		<button type="submit" class="btn btn-success">Send to Operator</button>
				  		<a href="<?php echo e(Route('main_slider_view')); ?>" class="btn btn-primary">View Slider</a>
				    </div>
				   
				</form>
				 <div class="form-group col-md-12" style="text-align: center;">
				  		<a href="<?php echo e(url('/admin_slider')); ?>"  class="btn btn">Back</a>
				    </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
	<script src="<?php echo e(asset('public/js/jquery.multiselect.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/slider/add_slider.blade.php ENDPATH**/ ?>