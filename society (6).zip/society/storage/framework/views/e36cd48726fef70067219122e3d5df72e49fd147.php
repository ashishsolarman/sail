
<?php $__env->startSection('css'); ?>
<style>
  .main-tab{
    padding: 60px 0px;
}

.tab {
  overflow: hidden;
  border: 1px solid #ddd;
  background-color: #d8f1ff;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 5px 16px;
  transition: 0.3s;
  font-size: 17px;
  border-right: 1px solid #ddd;
}

/* Change background color of buttons on hover */
/*.tab button:hover {
  background-color: #ddd;
}*/

/* Create an active/current tablink class */
.tab button.active {
  background-color: #16a9b5;
  color: #fff;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}


/* filter start tab */
.filter-tab{
    padding: 0px;
    margin: 0px auto;
}

.filter-tab .tab {
  overflow: hidden;
  border: 1px solid #ddd;
  background-color: #eee;
}


.filter-tab .tab button{
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 5px 48.3px;
  transition: 0.3s;
  font-size: 18px;
}
/* filter start tab */

/* Change background color of buttons on hover */
/*.tab button:hover {
  background-color: #ddd;
}*/

/* Create an active/current tablink class */
.tab button.active {
  background-color: #16a9b5;
  color: #fff;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}


.tabcontent p{
    font-size: 14px;
    text-align: justify;
}

.tab-heading{
    font-size: 18px;
    font-weight: 600;
    color: #000;
    padding: 10px 0px;
    border-bottom: 1px solid #bbb;

}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- hero container -->
<section class="hero d-flex flex-column align-items-center
  justify-content-center">
  <div class="hero-overlay"></div>
    <div class="text-center central-content">
      <h1>
        Helping people finding places to call<br>
         their homes since 1964</h1>
    </div>
  </div>
  
</section>
<!-- /hero container -->
<div class="container"  style="padding: 12px;">
<div class="row">
  <div class="col-lg-6 col-md-10 col-sm-12 filter-tab">
      <!-- Tab links -->
<div class="tab">
  <button class="tablinks active" onclick="openCity(event, 'Sale Property')" id="defaultOpen">Sale Property Search</button>
  <button class="tablinks" onclick="openCity(event, 'Rent Property')">Rent Property Search</button>
</div>

<div id="Sale Property" class="tabcontent" style="display: block;">
<div class="col-md-12">
    <form action="<?php echo e(route('sale_search')); ?>" method="post" enctype="multipart/form-data" id="search">
      <?php echo csrf_field(); ?>
      <div>
        <!-- <h5 style="text-align: center;">Sale Property Search</h5> -->
      </div>
      <div class="row" style="margin-top: 3%; text-align: center;">
         
      <div style="display: flex;" class="form-group col-md-9">
          <label style="padding-top: 3px;" for="city">Location<span class="text-danger">*</span></label>
          <input style="width: 95%;margin-left: 4%;padding: 6px;" class="typeahead form-control" placeholder="Enter location" type="text" id="city" name="city">
        </div>
        <div class="form-group col-md-3">
          <button type="submit" class="btn btn-success btn-sm">Search</button>
        </div>
      </div>
    </form>
  </div> 
</div>
<div id="Rent Property" class="tabcontent" style="display: none;">
  <div class="col-md-12">
    <form action="<?php echo e(route('rent_search')); ?>" method="post" enctype="multipart/form-data" id="search">
      <?php echo csrf_field(); ?>
      <div>
        <!-- <h5 style="text-align: center;">Rent Property Search</h5> -->
      </div>
      <div class="row" style="margin-top: 3%; text-align: center;">
         
      <div style="display: flex;" class="form-group col-md-9">
          <label style="padding-top: 3px;" for="city">Location<span class="text-danger">*</span></label>
          <input style="width: 95%;margin-left: 4%;padding: 6px;" class="typeahead form-control" placeholder="Enter location" type="text" id="city" name="city">
        </div>
        <div class="form-group col-md-3">
          <button type="submit" class="btn btn-success btn-sm">Search</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
</div>
</div>

  <!-- Home-Page-Popup -->
  <div class="modal fade popup" id="Modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Enquire now</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php if(Session::has('success')): ?>
              <div class="alert alert-success">
              <?php echo e(Session::get('success')); ?>

              </div>
            <?php endif; ?>
          <form id="contactform" class="contact-form" name="contactform" action="<?php echo e(route('details')); ?>" method="post" method="post" novalidate="novalidate">
              <?php echo csrf_field(); ?>
            <div class="form-group">
              <input type="text" required="" class="form-control input-custom input-full" name="first_name" placeholder="First Name" aria-required="true">
              <?php if($errors->has('first_name')): ?> 
                  <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span> 
              <?php endif; ?>
              </div>

            <div class="form-group">
              <input type="text" required="" class="form-control input-custom input-full" name="last_name" placeholder="Last Name" aria-required="true">
              <?php if($errors->has('last_name')): ?> 
                  <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
              <?php endif; ?>
            </div>

            <div class="form-group">
              <input type="text" class="form-control input-custom input-full" name="email" placeholder="Email">
              <?php if($errors->has('email')): ?> 
                  <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
              <?php endif; ?>
            </div>

            <div class="form-group">
              <textarea class="form-control textarea-custom input-full" id="ccomment" name="message_details" required="" rows="8" placeholder="Message" aria-required="true"></textarea>
              <?php if($errors->has('message_details')): ?> 
                  <span class="text-danger"><?php echo e($errors->first('message_details')); ?></span>
              <?php endif; ?>
            </div>
            <div class="form-group col-md-12" style="text-align: center;">
                <button type="submit" class="btn btn-success">Submit</button>
            </div>
          </form>  
      </div>
    </div>
  </div>
</div>
<!-- Home-Page-Popup -->


<!-- feature-section -->
    <!-- <section class="container">
      <div class="row main">
        <div class="col-12 col-md-4 pro">
          <div class="card service" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-3 text-center">
                <i class="fa fa-building" aria-hidden="true" style="font-size: 3rem;padding-top:
                  1rem;"></i>
              </div>
              <div class="col-md-9">
                <div class="card-body">
                  <h5 class="card-title">
                    Wide Range of Properties</h5>
                  <p class="card-text text-secondary">This is a wider card with
                    supporting text below as a natural lead-in to additional
                    content.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-4 pro">
          <div class="card service" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-3 text-center">

                <i class="fa fa-inr" aria-hidden="true" style="font-size:
                  3rem;padding-top: 1rem;"></i>
              </div>
              <div class="col-md-9">
                <div class="card-body">
                  <h5 class="card-title">Rent or Sale</h5>
                  <p class="card-text text-secondary">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-4 pro">
          <div class="card service" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-3 text-center">
                <i class="fa fa-location-arrow" aria-hidden="true" style="font-size:
                  3rem;padding-top: 1rem;"></i>
              </div>
              <div class="col-md-9">
                <div class="card-body">
                  <h5 class="card-title">
                    Property Location</h5>
                  <p class="card-text text-secondary">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section> -->
<!-- /feature-section -->

<!-- rent -->
    <section class="offers container-fluid parallax-one">
      <div class="section-heading">
        <h2 class="text-capitalize text-center text-white">Rental Properties</h2>
        <p class="text-capitalize text-center"><a href="<?php echo e(url('rent')); ?>"
            class="text-secondary text-white">View All New Listings</a></p>
      </div>
      <!-- Swiper -->
<div class="container">
  <div class="row internal">  
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="swiper-slide">
          <div class="card text-capitalize">
          <a href="rent_details/<?php echo e($value['id']); ?>">
            <div class="img-container">
              <img src="<?php echo e($value->main_image); ?>" alt="">
            </div>
          <div class="details">
        <div class="visible-details">
      <div class="price">
    <div class="btn btn-card"> &#8377;<?php echo e($value->price); ?></div>
  </div>
<div class="name"><strong><?php echo e($value->condition); ?>&nbsp; <?php echo e($value->flat_type); ?></strong></div>
  <div class="location"><?php echo e($value->city); ?></div>
    </div>
      <div class="d-flex hidden-details justify-content-between">
        <div class="home-feature-item">
          <span>area</span><br><span><?php echo e($value->area); ?></span>
            </div>
              <div class="home-feature-item">
                <span>bed</span><br><span><?php echo e($value->total_bedroom); ?></span>
              </div>
            <div class="home-feature-item">
          <span>baths</span><br><span><?php echo e($value->total_bathroom); ?></span>
        </div>
      <div class="home-feature-item">
    <span>parking</span><br><span><?php echo e($value->parking); ?></span>
  </div>
</div>
</div>
</a>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          
        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

        <div class="swiper-pagination"></div>
      </div>

      <div class="col-lg-12 listing-btn">
  <a href="<?php echo e(url('rent')); ?>">View All Properties</a>

</div>
            </div>
      </div>
    </section>
     <!-- /rent -->

     <!-- Project-section -->
    <section class="offers container-fluid">
      <div class="section-heading">
        <h2 class="text-capitalize text-center">Projects</h2>
          </div>
          <div class="container">
     <div class="row mt-5">
      <div class="col-lg-4 col-md-3- col-sm-12 pro">
        <div class="content">
         <a href="<?php echo e(url('project')); ?>">
          <div class="content-overlay"></div>
            <img class="content-image" src="<?php echo e(asset('public/img/ampm/g2.jpeg')); ?>">
              <div class="content-details fadeIn-bottom fadeIn-right">
        <h3>AMPM</h3>
<!--        <a href="#" class="btn btn-danger">See Details</a> -->
      </div>
    </a>
  </div>
</div>


<div class="col-lg-4 col-md-3- col-sm-12 pro">
        <div class="content">
         <a href="<?php echo e(url('project')); ?>">
          <div class="content-overlay"></div>
            <img class="content-image" src="<?php echo e(asset('public/img/buffeteria/g2.jpeg')); ?>">
              <div class="content-details fadeIn-bottom fadeIn-right">
        <h3>BUFFETERIA</h3>
<!--        <a href="#" class="btn btn-danger">See Details</a> -->
      </div>
    </a>
  </div>
</div>


<div class="col-lg-4 col-md-3- col-sm-12 pro">
        <div class="content">
         <a href="<?php echo e(url('project')); ?>">
          <div class="content-overlay"></div>
            <img class="content-image" src="<?php echo e(asset('public/img/newyork/g1.jpeg')); ?>">
              <div class="content-details fadeIn-bottom fadeIn-right">
        <h3>NEW YORK</h3>
<!--        <a href="#" class="btn btn-danger">See Details</a> -->
      </div>
    </a>
  </div>
</div>
<div class="row project-btn text-center d-flex mt-5">
<div class="col-lg-12">
  <a href="<?php echo e(url('project')); ?>">View All</a>

</div>
</div>

</div>
</div>
</section>
<!-- Project-section -->

     <!-- offers-section -->
    <section class="exclusive container-fluid">
      <div class="section-heading">
        <h2 class="text-capitalize text-center">Properties Listing For Purchase</h2>
        <!-- <hr style="width: 20%;border-bottom: 2px solid #d92228;margin :1rem auto"> -->
        <p class="text-capitalize text-center"><a href="<?php echo e(url('sale')); ?>"
            class="text-secondary">View All New Listings</a></p>
      </div>

      <!-- Swiper -->
      <div class="container">
        <div class="row">

      <div class="swiper mySwiper">
        <div class="swiper-wrapper">
          <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="swiper-slide">

            <div class="card text-capitalize">
            <a href="details/<?php echo e($sale['id']); ?>">
              <div class="img-container">
                <img src="<?php echo e($sale->main_image); ?>" alt="">
              </div>
              <div class="details">
                <div class="visible-details">
                  <div class="price">
                    <div class="btn btn-card"> &#8377;<?php echo e($sale->price); ?></div>
                  </div>
                  <div class="name"> <strong><?php echo e($sale->condition); ?>&nbsp;<?php echo e($sale->flat_type); ?></strong></div>
                  <div class="location"><?php echo e($sale->city); ?></div>
                </div>
                <div class="d-flex hidden-details justify-content-between">
                  <div class="home-feature-item">
                    <span>area</span><br><span><?php echo e($sale->area); ?> <!-- <sup>2</sup> --></span>
                  </div>
                  <div class="home-feature-item">
                    <span>bed</span><br><span><?php echo e($sale->total_bedroom); ?></span>
                  </div>
                  <div class="home-feature-item">
                    <span>baths</span><br><span><?php echo e($sale->total_bathroom); ?></span>
                  </div>
                  <div class="home-feature-item">
                    <span>parking</span><br><span><?php echo e($sale->parking); ?></span>
                  </div>
                </div>
              </div>
            </a>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>

        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>

        <div class="swiper-pagination"></div>
      </div>
            <div class="col-lg-12 view-btn">
  <a href="<?php echo e(url('sale')); ?>">View All Properties</a>

</div>
             </div>
      </div>


    </section>
    <!-- /offers-section -->

      <!-- counting-area -->
    <section class="counting-area container-fluid count parallax-two">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-6 completed">
            <h2 class="text-capitalize text-white">the hundred of completed work still
              counting </h2>
            <p style="text-align: justify;" class="text-secondary text-white">Lorem ipsum dolor sit, amet consectetur
              adipisicing elit. Illum vitae sunt recusandae quas labore
              voluptatibus doloribus pariatur veritatis. Officiis, perferendis
              molestias. Cum quod magni neque consectetur ab nesciunt rerum
              voluptate necessitatibus porro maiores magnam, natus voluptatibus
              eligendi ducimus cumque laudantium, sed ex voluptatum saepe eius
              enim, illo quas minima tenetur?</p>
          </div>
          <div class="col-12 col-md-6 counting-area-right">
            <div class="counter-container">

              <div class="row shadow text-center">
                <div class="col-6"><div class="count-box"><h1>531</h1><span>homes
                      for sale</span></div></div>
                <div class="col-6"><div class="count-box"><h1>4</h1><span>open
                      house</span></div></div>
                <div class="col-6"><div class="count-box"><h1>1252</h1><span>recently
                      sold</span></div></div>
                <div class="col-6"><div class="count-box"><h1>2</h1><span>price
                      reduced</span></div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
     <!--/counting-area -->

     <!-- Our-partner -->
    <section class="section part">
      <div class="section-heading mb-4">
        <h2 class="text-capitalize text-center">Our Partner</h2>
          </div>
          <div class="container">
            <div class="row">

     <div class="brand-carousel section-padding owl-carousel" id="brand-carousel">
  <div class="single-logo">
    <img src="<?php echo e(asset('public/img/chanel.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('public/img/chanel1.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('public/img/chanel2.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('public/img/chanel3.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('public/img/chanel4.jpg')); ?>" alt="">
  </div>
<div class="single-logo">
    <img src="<?php echo e(asset('public/img/chanel5.jpg')); ?>" alt="">
  </div>
</div>
</div>
</div>
    </div>

          </div>
</section>
    <!-- Our-partner -->

     <!-- happy-customer -->
    <section class="happy-customer container-fluid">
      <div class="section-heading mb-2">
        <h2 class="text-capitalize text-center">customer testimonials</h2>
        <hr style="width: 20%;border-bottom: 2px solid #16a9b5;margin :1rem
          auto">
      </div>
      <div class="container">
      <div class="row client">
        <div class="col-12 col-md-6 thin">
          <!-- Swiper -->
          <div class="swiper mySwiper2">
            <div class="swiper-wrapper">

              <div class="swiper-slide">
                <div class="testimonial flex flex-column font-roboto pro">
                  <div class="quote-icon-container flex">
                    <div class="quote-icon">
                      <!-- <i class="fab fa-twitter"></i> -->
                      <i class="fa fa-quote-left"></i>
                    </div>
                  </div>
                  <div class="testimonial-text text-dark2">
                    <p>
                      Nagpal Properties provides a great place to stay with safe environment. if they show you something about property that is always same as it. No fake pictures.
                    </p>
                    <hr />
                    <div class="pic-name d-flex font-roboto">
                      <img
                        src="<?php echo e(asset('public/img/user.png')); ?>"
                        alt=""
                        />
                      <span class="name"> parinita singha </span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="testimonial flex flex-column font-roboto pro">
                  <div class="quote-icon-container flex">
                    <div class="quote-icon">
                      <!-- <i class="fab fa-twitter"></i> -->
                      <i class="fa fa-quote-left"></i>
                    </div>
                  </div>
                  <div class="testimonial-text text-dark2">
                    <p>
                      It was a nice experience with Nagpal Properties. They helped me to find a new home to stay as it was difficult for me, as an individual,to find a home with friendly roommates.Thankfully Nagpal Properties helped me to get one with all kind of facilities.
                    </p>
                    <hr />
                    <div class="pic-name d-flex font-roboto pro">
                      <img
                        src="<?php echo e(asset('public/img/user.png')); ?>"
                        alt=""
                        />
                      <span class="name"> Rajan Mehra </span>
                    </div>
                  </div>
                </div>
              </div>


              <div class="swiper-slide">
                <div class="testimonial flex flex-column font-roboto pro">
                  <div class="quote-icon-container flex">
                    <div class="quote-icon">
                      <!-- <i class="fab fa-twitter"></i> -->
                      <i class="fa fa-quote-left"></i>
                    </div>
                  </div>
                  <div class="testimonial-text text-dark2">
                    <p>
                     I have got a genuine and very quick response from the site. I am very happy with service of nagpalproperties.com owner plans.
                    </p>
                    <hr />
                    <div class="pic-name d-flex font-roboto pro">
                      <img
                        src="<?php echo e(asset('public/img/user.png')); ?>"
                        alt=""
                        />
                      <span class="name"> Deepak Katakwal</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- <div class="swiper-pagination"></div> -->
          </div>
          <!-- /swiper mySwiper -->
        </div>
        <div class="col-12 col-md-6">
          <img src="<?php echo e(asset('public/img/tt2.jpg')); ?>" width="100%" alt="">
        </div>
      </div>
      </div>

    </section>
 <!-- /happy-customer -->
 <?php $__env->stopSection(); ?>
 <?php $__env->startPush('scripts'); ?>
  <script>
    $(document).ready(function() {
      $('.brand-carousel').owlCarousel({
        loop:true,
        margin:10,
        autoplay:true,
        responsive:{
          0:{
            items:1
          },
          600:{
            items:3
          },
          1000:{
            items:5
          }
        }
      });

    var myModal = new bootstrap.Modal(document.getElementById("Modal"));
      myModal.show();  
      
    });

    function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/user/first.blade.php ENDPATH**/ ?>