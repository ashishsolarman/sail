<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('public/img/fav.png')); ?>" type="image/x-icon">
   <title>Nagpal Properties</title>

    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('public/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/side_navbar/css/style.css')); ?>" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(url('admin_home')); ?>" style="width:325px;">
                    <img src="../public/img/finallogo.png" alt="Logo" style="width:100%;">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle fa fa-user mr-3" style="font-size: x-large;" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="wrapper d-flex align-items-stretch">
            <nav id="sidebar">
                <div class="custom-menu">
                    <button type="button" id="sidebarCollapse" class="btn btn-primary">
              <i class="fa fa-bars"></i>
              <span class="sr-only">Toggle Menu</span>
            </button>
        </div>
                <div class="p-4">
                
            <ul class="list-unstyled components mb-5">
              <li>
                <a href="<?php echo e(url('admin_home')); ?>"><span class="fa fa-home mr-3"></span> Home</a>
              </li>
              <li>
                  <a href="<?php echo e(url('admin_sale')); ?>"><span class="fa fa-user mr-3"></span> Sale</a>
              </li>
              <li>
              <a href="<?php echo e(url('admin_rent')); ?>"><span class="fa fa-briefcase mr-3"></span> Rent</a>
              </li>
              <li>
              <a href="<?php echo e(url('admin_sale_property')); ?>"><span class="fa fa-sticky-note mr-3"></span>View Sale Property</a>
              </li>
              <li>
              <a href="<?php echo e(url('admin_rent_property')); ?>"><span class="fa fa-sticky-note mr-3"></span>View Rent Property</a>
              </li>
              </li>
              <li>
              <a href="<?php echo e(url('admin_collaboration')); ?>"><span class="fa fa-sticky-note mr-3"></span>View Collaborations</a>
              </li>
              <!-- <li>
              <a href="#"><span class="fa fa-suitcase mr-3"></span> Gallery</a>
              </li>
              <li>
              <a href="#"><span class="fa fa-cogs mr-3"></span> Services</a>
              </li>
              <li>
              <a href="#"><span class="fa fa-paper-plane mr-3"></span> Contacts</a>
              </li> -->
            </ul>
            </div>
        </nav>
    

        <!-- <main class="py-6"> -->
            <?php echo $__env->yieldContent('content'); ?>
        <!-- </main> -->
    </div>
    </div>
    <!-- Scripts -->
    <script src="<?php echo e(asset('public/js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('public/side_navbar/js/popper.js')); ?>" defer></script>
    <script src="<?php echo e(asset('public/side_navbar/js/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('public/side_navbar/js/main.js')); ?>" defer></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cms\resources\views/layouts/admin_app_edit.blade.php ENDPATH**/ ?>