
<?php $__env->startSection('css'); ?>
	<style>
    body
    {
    	color: #000000;
    }
    label.error 
	{
    	color: #dc3545;
    	font-size: 14px;
    }

	input[type="file"] {
	  display: block;
	}
	.imageThumb {
	  max-height: 75px;
	  border: 2px solid;
	  padding: 1px;
	  cursor: pointer;
	  margin: 10px 5px 0 0;
	  width: 100px;

	}
	.pip {
	  display: inline-block;
	  margin: 10px 5px 0 0;
	}
	.remove {
	  display: block;
	  background: #444;
	  border: 1px solid black;
	  color: white;
	  text-align: center;
	  cursor: pointer;
	  width: 100px; 

	}
	.remove:hover {
	  background: white;
	  color: black;
	}

	textarea.form-control 
	{
	    min-height: calc(11.6em + 0.75rem + 2px);
	}
		#myDIV-1 {
  
  
  display: none;
 

}

#myDIV-2 {
  
  display: none;
 
 
}

#myDIV-3 {

  display: none;

 
}

.amit{
	display: flex;
	justify-content: center;
}
	</style>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
	<link href="<?php echo e(asset('public/css/jquery.multiselect.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 1%;">
		<!-- Flash message -->
		<?php if(Session()->has('success')): ?>
	    <div class="alert alert-success alert-block">
	        <button type="button" class="close" data-dismiss="alert">×</button>
	        <strong><?php echo e(Session()->get('success')); ?></strong>
	 
	    </div>
	    <br>
    <?php endif; ?>

    <div class="row justify-content-center"> 
        <div class="col-md-10">
        	
        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Footer Page</div>
        
            	<form action="<?php echo e(route('footer_links')); ?>" method="post" enctype="multipart/form-data" id="saleForm">
            		<?php echo csrf_field(); ?>
            		<div class="show_item">
				  <div class="form-row" style="margin-top:3%;"> 
	                  
	                  
					  <div class="form-group col-md-5">
				  	 	<label for="sub_menu">Detail<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="detail[]" required>
				    <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				      <span style="color:red;"><?php echo e($message); ?></span>
				      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
				     </div>
				      <div class="form-group col-md-5">
				  	 	<label for="sub_menu">Footer Hyperlink<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="detail_link[]" required>
				    <?php $__errorArgs = ['detail_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				      <span style="color:red;"><?php echo e($message); ?></span> 
				      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
				     </div>
				     <div class="form-group col-md-2">
				     	<a class="btn btn-success add_item_btn" style="positin:absolute;margin-top:30px;margin-left: 20px;"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
				     </div>
				 </div>
				</div>

				    

					<div class="form-group col-md-12" style="text-align: center;">
				  		<button type="submit" class="btn btn-success">Submit</button>
				  		<a href="<?php echo e(Route('footer_links_view')); ?>" class="btn btn-primary">View </a>
				    </div>
				   

				  
				</form>
				 <div class="form-group col-md-12" style="text-align: center;">
				  		<a href="<?php echo e(url('/admin_Footer')); ?>"  class="btn btn">Back</a>
				    </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
	function myFunction(y) {
   if (y === undefined) {
      y = 1;
   }
   var x = document.getElementById('myDIV-'+y);
   if (x.style.display === 'block') {
     x.style.display = 'none';
   } else {
     x.style.display = 'block';
   }
}
</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/js/jquery.min.js"></script>
	<script src="<?php echo e(asset('public/js/jquery.multiselect.js')); ?>"></script>
	<script>
		$(document).ready(function(){
			$(".add_item_btn").click(function(e){
      e.preventDefault();
      $(".show_item").prepend(`  <div class="form-row" style="margin-top:3%;"> 
	                  
	                  
					  <div class="form-group col-md-5">
				  	 	<label for="sub_menu">Detail<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="detail[]" required>
				    <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				      <span style="color:red;"><?php echo e($message); ?></span>
				      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
				     </div>
				      <div class="form-group col-md-5">
				  	 	<label for="sub_menu">Footer Hyperlink<span class="text-danger">*</span></label>
				      <input type="text" class="form-control"  name="detail_link[]" required>
				    <?php $__errorArgs = ['detail_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				      <span style="color:red;"><?php echo e($message); ?></span>
				      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
				     </div>
				     <div class="form-group col-md-2">
				     	<a class="btn btn-danger remove_item_btn" style="positin:absolute;margin-top:30px;margin-left: 20px;"><i class="fa fa-minus-circle" aria-hidden="true"></i></a>
				     </div>
				 </div>`);
			});
			$(document).on('click','.remove_item_btn',function(e){
       let row_item = $(this).parent().parent();
       $(row_item).remove();
			});
		});
	</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/footer/footer.blade.php ENDPATH**/ ?>