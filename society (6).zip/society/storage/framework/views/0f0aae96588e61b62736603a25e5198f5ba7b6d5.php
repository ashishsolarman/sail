
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }

  </style>

<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
    <?php if($message = Session::get('success')): ?>
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button>
   
              <strong><?php echo e($message); ?></strong>
   
      </div>
      <br>
    <?php endif; ?>
  <div class="container" style="margin-top: 1%;">
    <div class="row justify-content-center">
        <div class="col-md-10">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Gate Paas</div>
     <form action="#" method="post" enctype="multipart/form-data" id="saleForm">
                <?php echo csrf_field(); ?>
          <div class="form-row" style="margin-top:3%;">


   <div class="form-group col-md-6">
              <label for="project_name">Visitor Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="project_name" id="project_name">
             </div>
             <div class="form-group col-md-6">
              <label for="project_name">Phone Number<span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="project_name" id="project_name">
             </div>
             <div class="form-group col-md-6">
              <label for="project_name">Email<span class="text-danger">*</span></label>
              <input type="email" class="form-control" name="email" id="project_name">
             </div>

               <div class="form-group col-md-6">
              <label for="project_name">Expected duration<span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="expected" id="project_name">
             </div>
         
            <div class="form-group col-md-4">
              <label for="status">Vehicle Type<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2" id="status" name="status" style="height:48px;">
                <option selected>-</option>
               
                  <option value="Fourth Floor">Two Wheeler</option>
                 <option value="Fifth Floor">Three Wheeler</option>
                 <option value="Fifth Floor">Four Wheeler</option>
                <!-- <option value="unsold">Sold</option> -->
              
              </select>
            </div>
          
          
               <div class="form-group col-md-4">
              <label for="city">Vehicle Name<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="city">
              
            </div>
            <div class="form-group col-md-4">
              <label for="city">Vehicle Number<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="city">
              
            </div>

        
      


  </div> 


            </div>
        
       

          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-success">Send to Owner</button>
            </div>
        </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/js/jquery.min.js"></script>
<script>
    $(document).ready(function(){
      $(".add_item_btn").click(function(e){
      e.preventDefault();
      $(".show_item").prepend(`<div class="row">
            <div class="form-group col-md-5">
              <label for="status">Vehicle Type<span class="text-danger">*</span></label>
              <select class="custom-select mr-sm-2" id="status" name="status">
                <option selected>-</option>
               
                  <option value="Fourth Floor">Two Wheeler</option>
                 <option value="Fifth Floor">Three Wheeler</option>
                 <option value="Fifth Floor">Four Wheeler</option>
                <!-- <option value="unsold">Sold</option> -->
              
              </select>
            </div>
          
          
               <div class="form-group col-md-3">
              <label for="city">Vehicle Name<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="city">
              
            </div>
            <div class="form-group col-md-3">
              <label for="city">Vehicle Number<span class="text-danger">*</span></label>
             <input type="text"  class="form-control" id="city" name="city">
              
            </div>

         <div class="form-group col-md-1">
                <label for="status" type="hidden"><span class="text-danger"></span></label>
              <a class="btn btn-danger remove_item_btn">  <i class=" typcn typcn-minus btn-icon-append"></i></a>
            </div>
       </div>`);
      });
      $(document).on('click','.remove_item_btn',function(e){
       let row_item = $(this).parent().parent();
       $(row_item).remove();
      });
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/allowance/permission_request.blade.php ENDPATH**/ ?>