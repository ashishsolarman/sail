
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 1%;">
		<?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
		<div class="row justify-content-center">
	        <div class="col-md-11">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Main Menu Page <a href="<?php echo e(route('main_header')); ?>" class="btn btn-info" style="float:right">Add Menu</a></div>
	            	<div style="overflow-x: scroll;">
		              <table class="table table-bordered table-striped" id="ticker_data">
		                <thead>
			                <tr>
			                  <th>ID</th>
			                   <th>MENU</th>
			                   <th>SUB_MENU</th>
			                   <th>SUB SUB_MENU</th>
			                  <th>Created At</th>
			                  <th colspan="2" style="text-align: center;">Action</th>
			                </tr>
		                </thead>
		                <tbody>
		               		 <?php $__currentLoopData = $main_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                    <tr>
				                <td><?php echo e($item->id); ?></td>
				                <td><?php echo e($item->menu); ?></td>
				                   <td><?php echo e($item->sub_menu); ?></td>            
				                <td><?php echo e($item->sub_sub_menu); ?></td>
				                <td><a href="delete_main_menu/<?php echo e($item->id); ?>"  class="btn btn-danger">delete</a></td>
				                <td><a href="edit_main_menu/<?php echo e($item->id); ?>"  class="btn btn-info">Edit</a></td>
			                </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		          
		              </tbody>
             		</table>
				</div>
				<!-- pagination -->
			
	        </div>
	    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views//main_header_view.blade.php ENDPATH**/ ?>