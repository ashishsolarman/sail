
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block; 
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control  
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
    <?php if($message = Session::get('success')): ?>
 
      <div class="alert alert-success alert-block">
   
          <button type="button" class="close" data-dismiss="alert">×</button>
   
              <strong><?php echo e($message); ?></strong>
   
      </div>
      <br>
    <?php endif; ?>

  <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Collection History</div>
         
     
<div class="table-responsive pt-3"> 
   <table class="table table-striped">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#Payment ID</th>
      <th scope="col">Payment For</th>
      <th scope="col">Amount</th>
      <th scope="col">Payment Mode</th>
      <th scope="col">Status</th>
      <th scope="col">Email</th>
      <th scope="col">Created_at</th>
    </tr>
  </thead>
  <tbody>
     


<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row"><?php echo e($item->resident_id); ?></th>
      <td><?php echo e(date('d-m-Y', strtotime($item->from_date))); ?> to <?php echo e(date('d-m-Y', strtotime($item->to_date))); ?></td>
      <td>₹<?php echo e($item->amount); ?></td>
      <td><?php echo e($item->payment_mode); ?></td>
      <td> <div class="col">
                          <label class="badge badge-success">Paid</label>                     
                         </div></td>
                            <td> <div class="col">
                          <a href="<?php echo e(route('basic_email')); ?>" class="badge badge-danger">Email</a>                     
                         </div></td>
        <th><?php echo e($item->created_at->format('d-m-y')); ?> <?php echo e($item->created_at->format('H:i:s')); ?></th>
    </tr>
   
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>  
    </div>   

</div>
</div>
</div>



  
  
</section>
         
        
            </div>
        </div>
    </div>
  

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  
  
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/collection/collection_history.blade.php ENDPATH**/ ?>