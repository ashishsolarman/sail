
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 1%;">
		<?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
		<div class="row justify-content-center">
	        <div class="col-md-11">
	        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Footer Details Page <a href="<?php echo e(route('visitors')); ?>" class="btn btn-info" style="float:right">Add Vistors</a></div>
	            	<div style="overflow-x: scroll;">
		              <table class="table table-bordered table-striped" id="system_table">
		                <thead>
			                <tr>
			                  <th>ID</th>
			                   <th>No. of Visitors</th>
			                  <th>Detail Hyperlink</th>
			                  <th>Created At</th>
			                  <th colspan="2" style="text-align: center;">Action</th>
			                </tr>
		                </thead>
		                <tbody>
		               		 <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                    <tr>
				                <td><?php echo e($item->id); ?></td>
				                <td><?php echo e($item->visitors); ?></td>
				                <td><?php echo e($item->last_updated); ?></td>	                
				                <td><?php echo e($item->created_at); ?></td>
				                <td><a href="delete_visitors/<?php echo e($item->id); ?>"  class="btn btn-danger">delete</a></td>
				                <td><a href="edit_visitors/<?php echo e($item->id); ?>"  class="btn btn-info">Edit</a></td>
			                </tr>
			                
		          
		              </tbody>
             		</table>
				</div>
				<!-- pagination -->
			
	        </div>
	    </div>
    </div>
    
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms\resources\views/footer/visitors_view.blade.php ENDPATH**/ ?>