
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
  <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Profile</div>
      <section >
  <div class="container">
    <div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            <a download="download.jpg" href="<?php echo e(asset('owner_images')); ?>/<?php echo e($tenant_details->owner_image); ?>">
            <img  src="<?php echo e(asset('owner_images')); ?>/<?php echo e($tenant_details->owner_image); ?>" alt="avatar"
              class="rounded-circle img-fluid" style="width: 150px;"></a>
            <h5 class="my-3"><?php echo e($tenant_details->tenant_name); ?></h5>
            <p class="text-muted mb-1"><?php echo e($tenant_details->profession); ?></p>
         
          </div>
        </div>
          <div class="card mb-4">
          <div class="card-body text-center">
             <p class="text-muted mb-1"><?php echo e(_('Aadhar Card')); ?></p>
            <img src="<?php echo e(asset('aadhar_images')); ?>/<?php echo e($tenant_details->aadhar_image); ?>" alt="avatar"
              class="" style="width: 200px;height:100px;" >
               <p class="text-muted mb-1"><?php echo e(_('Aadhar Number')); ?></p>
            <h5 class="my-3"><?php echo e($tenant_details->aadhar_no); ?></h5>

          </div>
        </div>
       
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($tenant_details->tenant_name); ?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Email Address</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($tenant_details->email); ?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Mobile</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($tenant_details->mobile); ?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Owner Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($tenant_details->owner_name); ?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Address</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($tenant_details->block); ?>,<?php echo e($tenant_details->house_no); ?>,<?php echo e($tenant_details->floor); ?></p>
              </div>
            </div>
             <hr>
               <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Vehicle Name</p>
              </div>
              <div class="col-sm-9">
                <?php $hobbies = json_decode($tenant_details->vehicle_name)?>
                <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-muted mb-0"><?php echo e($hobby); ?>,</p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <hr>
             <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Vehicle number</p>
              </div>
              <div class="col-sm-9">
                <?php $hobbies = json_decode($tenant_details->vehicle_number)?>
                <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-muted mb-0"><?php echo e($hobby); ?>,</p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <hr>
             <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Vehicle Type</p>
              </div>
              <div class="col-sm-9">
                <?php $hobbies = json_decode($tenant_details->vehicle_type)?>
                <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-muted mb-0"><?php echo e($hobby); ?>,</p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            <hr>
               <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Status</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($tenant_details->status); ?></p>
              </div>
            </div>
            <hr>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/tenant/tenant_profile_view.blade.php ENDPATH**/ ?>