
<?php $__env->startSection('css'); ?>
	<style>
    body
    {
    	color: #000000;
    }
    label.error 
	{
    	color: #dc3545;
    	font-size: 14px;
    }

	input[type="file"] {
	  /*display: block;*/
	}
	.imageThumb {
	  max-height: 75px;
	  border: 2px solid;
	  padding: 1px;
	  cursor: pointer;
	  margin: 10px 5px 0 0;
	  width: 100px;

	}
	.pip {
	  display: inline-block;
	  margin: 10px 5px 0 0;

	}
	.remove {
	  display: block;
	  background: #444;
	  border: 1px solid black;
	  color: white;
	  text-align: center;
	  cursor: pointer;
	  width: 100px;

	}
	.remove:hover {
	  background: white;
	  color: black;
	}

	textarea.form-control 
	{
	    min-height: calc(11.6em + 0.75rem + 2px);
	}
	</style>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="margin-top: 1%;">
		<?php if($message = Session::get('success')): ?>
 
	    <div class="alert alert-success alert-block">
	 
	        <button type="button" class="close" data-dismiss="alert">×</button>
	 
	            <strong><?php echo e($message); ?></strong>
	 
	    </div>
	    <br>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-10">
        	<!-- <h6 style="float: right; padding-top: 26px; padding-right: 14px;"><a href="<?php echo e(url('admin_sale_property')); ?>">View Rent data</a></h6> -->
        	<div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Rent Page</div>
            	<form action="<?php echo e(url('update_rent/'.$rent_datas->id)); ?>" method="post" enctype="multipart/form-data" id="rentform">
            		<?php echo csrf_field(); ?>
            		<!-- <?php echo method_field('PUT'); ?> -->
				  <div class="form-row" style="margin-top: 3%;">
				  	 <div class="form-group col-md-6">
				  	 	<label for="serial_no">Serial No.<span class="text-danger">*</span></label>
				      <input type="text" class="form-control" maxlength="50" name="serial_no" id="serial_no" value="<?php echo e($rent_datas['serial_no']); ?>">
				     </div>
				  	 <div class="form-group col-md-6">
				  	 	<label for="project_name">Project Name<span class="text-danger">*</span></label>
				      <input type="text" class="form-control" maxlength="50" name="project_name" id="project_name" value="<?php echo e($rent_datas['project_name']); ?>">
				     </div>
					<div class="form-group col-md-6">
				      <label for="property_type">Property Type<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="property_type" name="property_type">
				        <option selected><?php echo e($rent_datas['property_type']); ?></option>
				        <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->property_type); ?>"><?php echo e($value->property_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
					</div>
				     <div class="form-group col-md-6">
				      <label for="flat_type">Falt Type<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="flat_type" name="flat_type">
				        <option selected ><?php echo e($rent_datas['flat_type']); ?></option>
				      	 <?php $__currentLoopData = $flats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->flat_type); ?>"><?php echo e($value->flat_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
				    </div>
				     <div class="form-group col-md-6">
				  	 	<label for="price">Price<span class="text-danger">*</span></label>
				      <input type="text" class="form-control" maxlength="20" name="price" id="price" value="<?php echo e($rent_datas['price']); ?>">
				     </div>
				     <div class="form-group col-md-6">
				      <label for="status">Status<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="status" name="status">
				        <option selected><?php echo e($rent_datas['status']); ?></option>
				         <?php $__currentLoopData = $rent_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->rent_type); ?>"><?php echo e($value->rent_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
				    </div>
					<div class="form-group col-md-6">
					    <label for="overview">Overview<span class="text-danger">*</span></label>
					    <textarea class="form-control" maxlength="600" name="overview" id="overview" style="height:80px" ><?php echo e($rent_datas['overview']); ?></textarea>
					</div>
				    <div class="form-group col-md-6">
					    <label for="short_desc">Short Description<span class="text-danger">*</span></label>
					    <textarea class="form-control" maxlength="50" name="short_description" id="short_desc" style="height:80px"><?php echo e($rent_datas['short_description']); ?></textarea>
					</div>
					<div class="form-group col-md-4">
				      <label for="city">City<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="city" name="city">
				        <option selected><?php echo e($rent_datas['city']); ?></option>
				        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->city_name); ?>"><?php echo e($value->city_name); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
				    </div>
					<div class="form-group col-md-4">
				      <label for="flat_type">Parking<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="parking" name="parking">
				        <option selected><?php echo e($rent_datas['parking']); ?></option>
				         <?php $__currentLoopData = $parking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->parking_type); ?>"><?php echo e($value->parking_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
					</div>
					<div class="form-group col-md-4">
				      <label for="flat_type">Condition<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="condition" name="condition">
				        <option selected><?php echo e($rent_datas['condition']); ?></option>
				        <?php $__currentLoopData = $condition; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->condition_type); ?>"><?php echo e($value->condition_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
					</div>
					<div class="form-group col-md-4">
				      <label for="floor">Floor<span class="text-danger">*</span></label>
				      <select class="custom-select select3 mr-sm-2" id="floor" name="floor[]" multiple>
				        <?php $__currentLoopData = $floor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option selected><?php echo e($data); ?></option>
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        <?php $__currentLoopData = $floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->floor_type); ?>"><?php echo e($value->floor_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
					</div>
					<div class="form-group col-md-4">
				      <label for="maintenance">Maintenance<span class="text-danger">*</span></label>
				      <select class="custom-select mr-sm-2" id="maintenance" name="maintenance">
				        <option selected><?php echo e($rent_datas['maintenance']); ?></option>
				        <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->maintenance_type); ?>"><?php echo e($value->maintenance_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
					</div>
					<div class="form-group col-md-4">
					    <label for="area">Area (Sqft.)<span class="text-danger">*</span></label>
					     <input type="text" class="form-control" id="area" maxlength="15" name="area" value="<?php echo e($rent_datas['area']); ?>">
					</div>
					<div class="form-group col-md-4">
					    <label for="total_bedroom">Total Bedroom<span class="text-danger">*</span></label>
					     <input type="number" class="form-control" minlength="1" id="total_bedroom" name="total_bedroom" value="<?php echo e($rent_datas['total_bedroom']); ?>">
					</div>
					<div class="form-group col-md-4">
					    <label for="total_bathroom">Total Bathroom<span class="text-danger">*</span></label>
					     <input type="number" class="form-control" minlength="1" id="total_bathroom" name="total_bathroom" value="<?php echo e($rent_datas['total_bathroom']); ?>">
					</div>
					<div class="form-group col-md-4">
						
					</div>
					<div class="form-group col-md-4">
					    <label for="main_image">Main Image</label><span class="text-danger">*</span>
					    <input type="file" class="form-control" id="main-file-input" maxlength="50" name="main_image" value="<?php echo e($rent_datas['main_image']); ?>">
					    <img src="../<?php echo e($rent_datas->main_image); ?>" class="d-block w-100" style="width: 40% !important;" alt="...">
					    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
						<div id="main-thumb-output"></div>
					</div>
					<?php 
					    $x = explode ("|", $rent_datas->image);
					?>
					<div class="form-group col-md-4">
					    <label for="image">Images</label><span class="text-danger">*</span>
					    <input type="file" class="form-control" id="file-input" maxlength="500" name="image[]" multiple />
					    <?php $__currentLoopData = $x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    
					    <img src="<?php echo e(url('public/admin_image_upload_rent/'.$val)); ?>" class="d-block w-100" style="width: 40% !important; " alt="...">
					   
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
						<div id="thumb-output"></div>
					</div>
					<div class="form-group col-md-4">
				      <label for="amenity">Amenities<span class="text-danger">*</span></label>
				      <select class="custom-select select2 mr-sm-2" id="amenity" maxlength="255" name="amenity[]" multiple>
				        <?php $__currentLoopData = $amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $amen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option selected><?php echo e($amen); ?></option>
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        <?php $__currentLoopData = $amenity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <option value="<?php echo e($value->amenity_type); ?>"><?php echo e($value->amenity_type); ?></option>
				        <!-- <option value="unsold">Sold</option> -->
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				      </select>
				    </div>
					<div class="form-group col-md-12" style="text-align: center;">
				  		<button type="submit" class="btn btn-success">Submit</button>
				    </div>
				</form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
	<script>
		$(document).ready(function() {
            $('#rentform').validate({
                rules: {
                    serial_no: "required",
                    project_name: "required",
                    flat_type: "required",
                    price: "required",
                    status: "required",
                    short_desc: "required",
                    overview: "required",
                    city: "required",
                    parking: "required",
                    condition: "required",
                    property_type: "required",
                    area: "required",
                    total_bedroom: "required",
                    total_bathroom: "required",
                    amenity: "required",
                }
            });
           $('.select2').select2({
			    closeOnSelect: false
			});
           $('.select3').select2({
			    closeOnSelect: false
			});
			if (window.File && window.FileList && window.FileReader) {
		    $("#main-file-input").on("change", function(e) {
		      var files = e.target.files,
		        filesLength = files.length;
		      for (var i = 0; i < filesLength; i++) {
		        var f = files[i]
		        var fileReader = new FileReader();
		        fileReader.onload = (function(e) {
		          var file = e.target;
		          $("<span class=\"pip\">" +
		            "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
		            "<br/><span class=\"remove\">Remove</span>" +
		            "</span>").insertAfter("#main-file-input");
		          $(".remove").click(function(){
		            $(this).parent(".pip").remove();
		          });
		        });
		        fileReader.readAsDataURL(f);
		      }
		    });
			  } else {
			    alert("Your browser doesn't support to File API")
			  }
			 if (window.File && window.FileList && window.FileReader) {
			    $("#file-input").on("change", function(e) {
			      var files = e.target.files,
			        filesLength = files.length;
			      for (var i = 0; i < filesLength; i++) {
			        var f = files[i]
			        var fileReader = new FileReader();
			        fileReader.onload = (function(e) {
			          var file = e.target;
			          $("<span class=\"pip\">" +
			            "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
			            "<br/><span class=\"remove\">Remove</span>" +
			            "</span>").insertAfter("#file-input");
			          $(".remove").click(function(){
			            $(this).parent(".pip").remove();
			          });
			        });
			        fileReader.readAsDataURL(f);
			      }
			    });
			  } else {
			    alert("Your browser doesn't support to File API")
			  }
			        });
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin_app_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/edit_rent_data.blade.php ENDPATH**/ ?>