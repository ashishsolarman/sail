
<?php $__env->startSection('css'); ?>
  <style>
    body
    {
      color: #000000;
    }
    label.error 
  {
      color: #dc3545;
      font-size: 14px;
    }

  input[type="file"] {
    display: block;
  }
  .imageThumb {
    max-height: 75px;
    border: 2px solid;
    padding: 1px;
    cursor: pointer;
    margin: 10px 5px 0 0;
    width: 100px;

  }
  .pip {
    display: inline-block;
    margin: 10px 5px 0 0;
  }
  .remove {
    display: block;
    background: #444;
    border: 1px solid black;
    color: white;
    text-align: center;
    cursor: pointer;
    width: 100px;

  }
  .remove:hover {
    background: white;
    color: black;
  }

  textarea.form-control 
  {
      min-height: calc(11.6em + 0.75rem + 2px);
  }
  .pdf-page {
            margin: 0 auto;
            box-sizing: border-box;
            box-shadow: 0 5px 10px 0 rgba(0,0,0,.3);
            background-color: #fff;
            color: #333;
            position: relative;
        }
        .pdf-header {
            position: absolute;
            top: .5in;
            height: .6in;
            left: .5in;
            right: .5in;
            border-bottom: 1px solid #e5e5e5;
        }
        .invoice-number {
            padding-top: .17in;
            float: right;
        }
        .pdf-footer {
            position: absolute;
            bottom: .5in;
            height: .6in;
            left: .5in;
            right: .5in;
            padding-top: 10px;
            border-top: 1px solid #e5e5e5;
            text-align: left;
            color: #787878;
            font-size: 12px;
        }
        .pdf-body {
            position: absolute;
            top: 3.7in;
            bottom: 1.2in;
            left: .5in;
            right: .5in;
        }

        .size-a4 { width: 8.3in; height: 11.7in; }
        .size-letter { width: 8.5in; height: 11in; }
        .size-executive { width: 7.25in; height: 10.5in; }

        .company-logo {
            font-size: 30px;
            font-weight: bold;
            color: #3aabf0;
        }
        .for {
            position: absolute;
            top: 1.5in;
            left: .5in;
            width: 2.5in;
        }
        .from {
            position: absolute;
            top: 1.5in;
            right: .5in;
            width: 2.5in;
        }
        .from p, .for p {
            color: #787878;
        }
        .signature {
            padding-top: .5in;
        }
        

  </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container" style="margin-top: 1%;">
  <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
          <div class="card-header" style="text-align: center; padding-bottom: 3%; font-size: 26px; color: #000000">Visitor Profile</div>
      <section >

  <div class="pdf-page container-fluid" id="printableArea">
    <div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            <a download="<?php echo e($vendor->image); ?>" href="<?php echo e(asset('uploads/vendors_images')); ?>/<?php echo e($vendor->image); ?>">
            <img  src="<?php echo e(asset('uploads/vendors_images')); ?>/<?php echo e($vendor->image); ?>" alt="avatar"
              class="rounded-circle img-fluid" style="width: 150px;"></a>
            <h5 class="my-3"><?php echo e($vendor->name); ?></h5>
            <p class="text-muted mb-1"><?php echo e($vendor->profession); ?></p>
         
          </div>
        </div>
     
       
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($vendor->name); ?></p>
              </div>
            </div>
            <hr>
         
            
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Mobile</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($vendor->mobile_no); ?></p>
              </div>
            </div>
              <hr>
                 <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Document</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($vendor->id_type); ?></p>
              </div>
            </div>
              <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Document No.</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($vendor->id_no); ?></p>
              </div>
            </div>
         
      
          
            <hr>
              <div class="row">
              <div class="col-sm-3">
                <p class="mb-0"><?php echo e(_('Purpose')); ?></p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo e($vendor->purpose); ?></p>
              </div>
            </div>
            <hr>
          </div>
        </div>
     
       
        
        
      </div>
    </div>
  </div>
     <div class="row">
         <input type="button" class="btn btn-primary" onclick="printDiv('printableArea')" value="print Profile"/>

             <div class="box-col">
            
            <!-- <button class="export-pdf k-button btn btn-warning" onclick="getPDF('.pdf-page')">Export as pdf</button> -->
        </div>
          <div class="col-md-6"><a href="https://api.whatsapp.com/send?phone=+91-<?php echo e($vendor->mobile_no); ?>&amp;text=This is your profile" class="btn btn-success" target="_blank">Send Profile on Whatsapp</a></div>

        </div>
</section>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<script src="https://html2canvas.hertzen.com/dist/html2canvas.min.js"></script>
  <script>
setUpDownloadPageAsImage();
function setUpDownloadPageAsImage() {
  document.getElementById("download-page-as-image").addEventListener("click", function() {
    html2canvas(document.body).then(function(canvas) {
      console.log(canvas);
      simulateDownloadImageClick(canvas.toDataURL(), 'visitor_pass.png');
    });
  });
}

function simulateDownloadImageClick(uri, filename) {
  var link = document.createElement('a');
  if (typeof link.download !== 'string') {
    window.open(uri);
  } else {
    link.href = uri;
    link.download = filename;
    accountForFirefox(clickLink, link);
  }
}

function clickLink(link) {
  link.click();
}

function accountForFirefox(click) { // wrapper function
  let link = arguments[1];
  document.body.appendChild(link);
  click(link);
  document.body.removeChild(link);
}
  </script>


   <script src="https://kendo.cdn.telerik.com/2017.1.223/js/jquery.min.js"></script>
    <script src="https://kendo.cdn.telerik.com/2017.1.223/js/jszip.min.js"></script>
    <script src="https://kendo.cdn.telerik.com/2017.1.223/js/kendo.all.min.js"></script>
     <script>
        // Import DejaVu Sans font for embedding

        // NOTE: Only required if the Kendo UI stylesheets are loaded
        // from a different origin, e.g. cdn.kendostatic.com
        kendo.pdf.defineFont({
            "DejaVu Sans"             : "https://kendo.cdn.telerik.com/2016.2.607/styles/fonts/DejaVu/DejaVuSans.ttf",
            "DejaVu Sans|Bold"        : "https://kendo.cdn.telerik.com/2016.2.607/styles/fonts/DejaVu/DejaVuSans-Bold.ttf",
            "DejaVu Sans|Bold|Italic" : "https://kendo.cdn.telerik.com/2016.2.607/styles/fonts/DejaVu/DejaVuSans-Oblique.ttf",
            "DejaVu Sans|Italic"      : "https://kendo.cdn.telerik.com/2016.2.607/styles/fonts/DejaVu/DejaVuSans-Oblique.ttf"
        });
    </script>

    <!-- Load Pako ZLIB library to enable PDF compression -->
    <script src="../content/shared/js/pako.min.js"></script>

    <script>
      function getPDF(selector) {
        kendo.drawing.drawDOM($(selector)).then(function(group){
          kendo.drawing.pdf.saveAs(group, "Profile.pdf");
        });
      }

    $(document).ready(function() {
        var data = [
          { productName: "QUESO CABRALES", unitPrice: 21, qty: 5 },
          { productName: "ALICE MUTTON", unitPrice: 39, qty: 7 },
          { productName: "GENEN SHOUYU", unitPrice: 15.50, qty: 3 },
          { productName: "CHARTREUSE VERTE", unitPrice: 18, qty: 1 },
          { productName: "MASCARPONE FABIOLI", unitPrice: 32, qty: 2 },
          { productName: "VALKOINEN SUKLAA", unitPrice: 16.25, qty: 3 }
        ];
        var schema = {
          model: {
            productName: { type: "string" },
            unitPrice: { type: "number", editable: false },
            qty: { type: "number" }
          },
          parse: function (data) {
                $.each(data, function(){
                    this.total = this.qty * this.unitPrice;
                });
                return data;
          }
        };
        var aggregate = [
          { field: "qty", aggregate: "sum" },
          { field: "total", aggregate: "sum" }
        ];
        var columns = [
          { field: "productName", title: "Product", footerTemplate: "Total"},
          { field: "unitPrice", title: "Price", width: 120},
          { field: "qty", title: "Pcs.", width: 120, aggregates: ["sum"], footerTemplate: "#=sum#" },
          { field: "total", title: "Total", width: 120, aggregates: ["sum"], footerTemplate: "#=sum#" }
        ];
        var grid = $("#grid").kendoGrid({
          editable: false,
          sortable: true,
          dataSource: {
            data: data,
            aggregate: aggregate,
            schema: schema,
          },
          columns: columns
        });

        $("#paper").kendoDropDownList({
          change: function() {
            $(".pdf-page")
              .removeClass("size-a4")
              .removeClass("size-letter")
              .removeClass("size-executive")
              .addClass(this.value());
          }
        });
    });
    </script>
    <script>
      function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\society\resources\views/vendor/vendor_profile.blade.php ENDPATH**/ ?>