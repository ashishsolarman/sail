
<?php $__env->startSection('content'); ?>

<!-- about-banner -->
<section class="about-main d-flex flex-column align-items-center justify-content-center">
  <div class="text-center heading">
    <h1>Collaboration</h1>
  </div>
</section>
<!--about-banner -->

<!--about-content -->
<section class="about-content">
  <div class="container">
    <div class="row internal">
      <div class="col-lg-10 mx-auto collaboration">
        <h2 class="mb-3">Collaboration</h2>
        <div class="card-body"> 
          <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

            </div>
          <?php endif; ?>
        <form id="contactform" class="contact-form" name="contactform" action="<?php echo e(route('collaboration')); ?>" method="post" method="post" novalidate="novalidate">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <input type="text" class="form-control input-custom input-full" name="name" placeholder="Name" aria-required="true">
             <?php if($errors->has('name')): ?> 
                <span class="text-danger"><?php echo e($errors->first('name')); ?></span> 
            <?php endif; ?> 
          </div>

          <div class="form-group">
            <input type="email" class="form-control input-custom input-full" name="email" placeholder="Email" aria-required="true">
             <?php if($errors->has('email')): ?> 
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span> 
            <?php endif; ?> 
          </div>

          <div class="form-group">
            <input type="tel" class="form-control input-custom input-full" name="phone" placeholder="Phone Number" aria-required="true">
             <?php if($errors->has('phone')): ?> 
                <span class="text-danger"><?php echo e($errors->first('phone')); ?></span> 
            <?php endif; ?>
          </div>

          <div class="form-group">
            <input type="text" class="form-control input-custom input-full" name="expectation" placeholder="Expectation">
             <?php if($errors->has('expectation')): ?> 
                <span class="text-danger"><?php echo e($errors->first('expectation')); ?></span> 
            <?php endif; ?>
          </div>

          <div class="form-group">
            <input type="text" class="form-control input-custom input-full" name="asking_price" placeholder="Asking Price" aria-required="true">
             <?php if($errors->has('asking_price')): ?> 
                <span class="text-danger"><?php echo e($errors->first('asking_price')); ?></span> 
            <?php endif; ?>
          </div>

          <div class="form-group">
            <input type="text" class="form-control input-custom input-full" name="other_deatils" placeholder="Other Details">
             <?php if($errors->has('other_deatils')): ?> 
                <span class="text-danger"><?php echo e($errors->first('other_deatils')); ?></span> 
            <?php endif; ?>
          </div>

          <div class="form-group">
            <textarea class="form-control textarea-custom input-full" id="address" name="address" required="" rows="8" placeholder="Address" aria-required="true"></textarea>
             <?php if($errors->has('address')): ?> 
                <span class="text-danger"><?php echo e($errors->first('address')); ?></span> 
            <?php endif; ?>
          </div>

          <div class="form-group col-md-12" style="text-align: center;">
              <button type="submit" class="btn btn-success">Submit</button>
          </div>
</form>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_usr_header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/user/collaboration.blade.php ENDPATH**/ ?>