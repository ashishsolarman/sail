<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Nagpal Properties</title>

    <link rel="shortcut icon" href="<?php echo e(asset('public/img/fav.png')); ?>" type="image/x-icon">

    <!-- Scripts -->
    <script src="<?php echo e(asset('public/admin_login/js/jquery-3.3.1.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('public/admin_login/js/popper.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('public/admin_login/js/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('public/admin_login/js/main.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_login/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_login/fonts/icomoon/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_login/css/owl.carousel.min.css')); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin_login/css/bootstrap.min.css')); ?>">
</head>
<body>
    <div id="app">
       

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\nagpal_property\resources\views/layouts/app.blade.php ENDPATH**/ ?>