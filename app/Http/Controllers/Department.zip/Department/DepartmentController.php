<?php

namespace App\Http\Controllers\Department;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Department_level;
use App\Models\Department_type;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Crypt;

class DepartmentController extends Controller
{
    public function depart_level_show()
    {
        $data = Department_level::orderBy('id', 'DESC')->paginate(5);
        return view('department.depart_level',['data'=>$data]);
    }

    public function add_level_form()
    {
        return view('department.add_depart_level_form');
    }

    public function add_level_form_save(Request $request)
    {
     	$request->validate([
      		'level_name'=>'required|max:255',
      		'rank'=>'required|max:11'
      	]);

     	$depart_data= new Department_level;
     	$depart_data->level_name = $request->level_name;
     	$depart_data->rank = $request->rank;
     	$depart_data->save();

     	return redirect()->back()->withsuccess('Your Data has been successfully Uptated');

    }
    public function edit_depart_level($id)
    {
	    $id = Crypt::decrypt($id);
	   	$data = Department_level::find($id);

    	return view('department.edit_depart_level',['level'=>$data]);
	}

	public function update_depat_level(Request $request,$id)
	{
        $data = Department_level::find($id);
        $data->level_name = $request->level_name;
        $data->rank = $request->rank;
        $data->update();

        return redirect()->back()->withsuccess('Your Data has been successfully Uptated');
    }

	public function delete_level($id){
    	$data = Department_level::find($id);
    	$data->destroy($id);

    	return redirect()->back()->withsuccess('Your Data has been successfully Deleted');
	}

	public function depart_type_show()
    {
        $data = Department_type::orderBy('id', 'DESC')->paginate(5);
        return view('department.depart_type',['data'=>$data]);
    }

    public function add_type_form()
    {
        return view('department.add_depart_type_form');
    }

    public function add_type_form_save(Request $request)
    {
     	$request->validate([
      		'type_code'=>'required|max:20',
      		'description'=>'required|max:255'
      	]);

     	$depart_data= new Department_type;
     	$depart_data->type_code = $request->type_code;
     	$depart_data->description = $request->description;
     	$depart_data->save();

     	return redirect()->back()->withsuccess('Your Data has been successfully Uptated');

    }
    public function edit_depart_type($id)
    {
	    $id = Crypt::decrypt($id);
	   	$data = Department_type::find($id);

    	return view('department.edit_depart_type',['type'=>$data]);
	}

	public function update_depat_type(Request $request,$id)
	{
        $data = Department_type::find($id);
        $data->type_code = $request->type_code;
        $data->description = $request->description;
        $data->update();

        return redirect()->back()->withsuccess('Your Data has been successfully Uptated');
    }

	public function delete__depart_type($id){
    	$data = Department_type::find($id);
    	$data->destroy($id);

    	return redirect()->back()->withsuccess('Your Data has been successfully Deleted');
	}

  public function department_show()
    {
        // $data = Department_type::orderBy('id', 'DESC')->paginate(5);
      // ,['data'=>$data]
        return view('department.department');
    }
}
